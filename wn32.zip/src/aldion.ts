// ملف إعدادات العميل الآمن (Zero-Secret Client Configuration)
// تطبيقاً لأعلى معايير الأمان العالمية (Zero-Trust Architecture):
// الرموز السرية وقواعد البيانات لا يتم تضمينها إطلاقاً داخل كود العميل (Frontend / APK)
// لقطع الطريق نهائياً على أي محاولة فك تشفير أو استخراج للبيانات (Decompilation / Sniffing).

export const ALDION_CLIENT_CONFIG = {
  appName: "دفتر الديون الذكي",
  version: "3.5.0-shield",
  shieldProtocol: "v2-zero-exposure",
  apiEndpoint: "/api/turso",
};

export function normalizeTursoUrl(rawUrl: string): string {
  if (!rawUrl) return "";
  let clean = rawUrl.trim();
  if (clean.startsWith("libsql://")) {
    clean = "https://" + clean.slice("libsql://".length);
  } else if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
    clean = "https://" + clean;
  }
  clean = clean.replace(/\/+$/, "");
  if (!clean.endsWith("/v2/pipeline")) {
    clean = clean + "/v2/pipeline";
  }
  return clean;
}



