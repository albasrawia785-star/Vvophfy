import React, { useState } from 'react';
import { DatabaseAccount } from '../types';
import { testDatabaseConnection, syncDatabasesToCloud, deleteDatabaseFromCloud } from '../services/turso';
import { ALDION_DATABASE_CONFIG } from '../../aldion';
import { useI18n } from '../i18n/index.tsx';

interface DatabaseAccountsSectionProps {
  databases: DatabaseAccount[];
  onRefreshDatabases: () => Promise<void> | void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const DatabaseAccountsSection: React.FC<DatabaseAccountsSectionProps> = ({
  databases,
  onRefreshDatabases,
  onShowToast,
}) => {
  const { t, numberFormat } = useI18n();

  const [dbName, setDbName] = useState('');
  const [dbUrl, setDbUrl] = useState('');
  const [dbToken, setDbToken] = useState('');
  const [dbDesc, setDbDesc] = useState('');

  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string; latencyMs?: number } | null>(null);

  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // In-App Confirm Delete State
  const [dbToDelete, setDbToDelete] = useState<{ id: string; name: string } | null>(null);
  const [isDeletingDb, setIsDeletingDb] = useState(false);

  // Testing connection for form fields and bootstrapping schema
  const handleTestFormConnection = async () => {
    if (!dbUrl.trim() || !dbToken.trim()) {
      setTestResult({
        ok: false,
        message: 'يرجى كتابة رابط القاعدة ومفتاح التوكن أولاً لفحص الاتصال وتهيئتها',
      });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const result = await testDatabaseConnection(dbUrl, dbToken, true);
      setIsTesting(false);
      setTestResult(result);
    } catch (err: any) {
      setIsTesting(false);
      setTestResult({
        ok: false,
        message: err?.message || 'فشل الاتصال أو تهيئة القاعدة، يرجى التحقق من الرابط والتوكن',
      });
    }
  };

  // Add Database Account and ensure schema is ready
  const handleAddDatabase = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const name = dbName.trim();
    const url = dbUrl.trim();
    const token = dbToken.trim();

    if (!name || !url || !token) {
      setError('يرجى كتابة اسم القاعدة، رابط القاعدة (libsql://...)، ومفتاح التوكن (JWT)');
      return;
    }

    try {
      setIsSaving(true);

      // التأكد من فحص وتهيئة القاعدة أولاً لاستقبال البيانات
      const testRes = await testDatabaseConnection(url, token, true);
      if (!testRes.ok) {
        throw new Error(testRes.message || 'تعذر الاتصال بالقاعدة أو تهيئتها');
      }

      const newAcc: DatabaseAccount = {
        id: 'db_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        name,
        url,
        token,
        description: dbDesc.trim(),
        createdAt: new Date().toISOString(),
      };

      const updated = [...databases, newAcc];
      await syncDatabasesToCloud(updated);

      setDbName('');
      setDbUrl('');
      setDbToken('');
      setDbDesc('');
      setTestResult(null);

      if (onShowToast) {
        onShowToast('تم فحص وتهيئة وحفظ قاعدة البيانات بنجاح، وأصبحت جاهزة لاستقبال البيانات فوراً!', 'success');
      }

      await onRefreshDatabases();
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء حفظ قاعدة البيانات');
    } finally {
      setIsSaving(false);
    }
  };

  const promptDeleteDb = (id: string, name: string) => {
    setDbToDelete({ id, name });
  };

  const executeDeleteDb = async () => {
    if (!dbToDelete) return;
    try {
      setIsDeletingDb(true);
      await deleteDatabaseFromCloud(dbToDelete.id);
      if (onShowToast) {
        onShowToast(`تم حذف قاعدة البيانات "${dbToDelete.name}" بنجاح`, 'info');
      }
      setDbToDelete(null);
      await onRefreshDatabases();
    } catch (err: any) {
      if (onShowToast) {
        onShowToast('فشل حذف القاعدة: ' + (err?.message || 'حدث خطأ غير متوقع'), 'error');
      }
    } finally {
      setIsDeletingDb(false);
    }
  };

  const handleTestExistingDb = async (db: DatabaseAccount) => {
    if (onShowToast) {
      onShowToast(`جاري فحص وتهيئة الاتصال بالقاعدة: ${db.name}...`, 'info');
    }
    const res = await testDatabaseConnection(db.url, db.token, true);
    if (onShowToast) {
      onShowToast(`${db.name}: ${res.message}`, res.ok ? 'success' : 'error');
    }
  };

  return (
    <div className="space-y-4 text-start">
      {/* Intro Banner */}
      <div className="p-3.5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl border border-blue-800 shadow-xs space-y-1.5">
        <div className="flex items-center gap-2 font-black text-xs">
          <i className="fa-solid fa-server text-cyan-400"></i>
          <span>تعدد قواعد البيانات (Multi-Tenant Cloud DBs)</span>
        </div>
        <p className="text-[11px] text-blue-100/90 leading-relaxed">
          يمكنك إضافة وتخصيص قواعد بيانات متعددة وتوزيع المدراء والمدراء الفرعيين عليها. يتم حفظ كافة بيانات قواعد البيانات الأخرى مشفرة ومحفوظة آمنًا في القاعدة الرئيسية الحالية.
        </p>
      </div>

      {/* Form: Add New Database */}
      <form onSubmit={handleAddDatabase} className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-3">
        <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
          <h3 className="font-bold text-xs text-slate-800 flex items-center gap-2">
            <i className="fa-solid fa-plus-circle text-blue-600"></i>
            <span>إضافة قاعدة بيانات سحابية جديدة</span>
          </h3>
          <span className="text-[10px] text-slate-500 font-medium">Turso / LibSQL</span>
        </div>

        {error && (
          <div className="p-2.5 bg-red-50 text-red-800 border border-red-200 rounded-xl text-xs font-bold flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation text-red-600"></i>
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">اسم القاعدة / الفرع:</label>
            <input
              type="text"
              value={dbName}
              onChange={(e) => setDbName(e.target.value)}
              placeholder="مثال: قاعدة فرع النجف الأشرف"
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-blue-600"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">وصف القاعدة (اختياري):</label>
            <input
              type="text"
              value={dbDesc}
              onChange={(e) => setDbDesc(e.target.value)}
              placeholder="مثال: خاصة بديون وأقساط فرع النجف"
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-blue-600"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-700 mb-1">رابط القاعدة (Database URL):</label>
          <input
            type="text"
            value={dbUrl}
            onChange={(e) => setDbUrl(e.target.value)}
            placeholder="libsql://your-db-name-org.turso.io"
            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-800 outline-none focus:border-blue-600"
            dir="ltr"
          />
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-700 mb-1">مفتاح التوكن (Auth Token):</label>
          <textarea
            rows={2}
            value={dbToken}
            onChange={(e) => setDbToken(e.target.value)}
            placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-800 outline-none focus:border-blue-600 resize-none"
            dir="ltr"
          ></textarea>
        </div>

        {/* Test Result Feedback */}
        {testResult && (
          <div
            className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-between gap-2 ${
              testResult.ok
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <i className={`fa-solid ${testResult.ok ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-rose-600'}`}></i>
              <span>{testResult.message}</span>
            </div>
            {testResult.latencyMs !== undefined && (
              <span className="font-mono text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-300">
                {testResult.latencyMs}ms
              </span>
            )}
          </div>
        )}

        {/* Action Buttons: Test Connection & Save Database */}
        <div className="flex items-center gap-2 pt-1 flex-wrap sm:flex-nowrap">
          <button
            type="button"
            onClick={handleTestFormConnection}
            disabled={isTesting || !dbUrl.trim() || !dbToken.trim()}
            className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 disabled:opacity-50 text-slate-800 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
            title="فحص الاتصال وتجهيز كافة جداول الديون والأقساط"
          >
            {isTesting ? (
              <i className="fa-solid fa-spinner fa-spin text-blue-600"></i>
            ) : (
              <i className="fa-solid fa-wand-magic-sparkles text-blue-600"></i>
            )}
            <span>{isTesting ? 'جاري الفحص والتهيئة...' : 'فحص وتهيئة القاعدة'}</span>
          </button>

          <button
            type="submit"
            disabled={isSaving}
            className="flex-1 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            {isSaving ? (
              <i className="fa-solid fa-spinner fa-spin"></i>
            ) : (
              <i className="fa-solid fa-floppy-disk"></i>
            )}
            <span>{isSaving ? 'جاري التجهيز والحفظ...' : 'حفظ إضافة القاعدة'}</span>
          </button>
        </div>
      </form>

      {/* List of Configured Databases */}
      <div className="space-y-2 pt-2">
        <h4 className="font-bold text-xs text-slate-700 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <i className="fa-solid fa-database text-cyan-600"></i>
            <span>قواعد البيانات المسجلة بالنظام:</span>
          </span>
          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-lg">
            {databases.length + 1} قاعدة إجمالاً
          </span>
        </h4>

        {/* Default Main Database Card */}
        <div className="p-3.5 bg-cyan-50/60 border border-cyan-200 rounded-2xl flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-cyan-600 text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-xs">
              <i className="fa-solid fa-crown"></i>
            </div>
            <div className="truncate text-start">
              <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                <span>القاعدة الرئيسية (الافتراضية)</span>
                <span className="text-[9.5px] bg-cyan-100 text-cyan-800 font-extrabold px-2 py-0.2 rounded-full border border-cyan-300">
                  سجل القواعد والمستخدمين
                </span>
              </div>
              <p className="text-[10px] text-slate-500 truncate mt-0.5 font-mono">
                يتم حفظ كافة القواعد والم مدراء والاشتراكات عليها
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={async () => {
              if (onShowToast) onShowToast('جاري فحص الاتصال بالقاعدة الرئيسية...', 'info');
              try {
                const res = await testDatabaseConnection(
                  ALDION_DATABASE_CONFIG.url,
                  ALDION_DATABASE_CONFIG.token
                );
                if (onShowToast) onShowToast(res.message, res.ok ? 'success' : 'error');
              } catch (e: any) {
                if (onShowToast) onShowToast('فشل فحص القاعدة الرئيسية: ' + (e?.message || 'خطأ في الاتصال'), 'error');
              }
            }}
            className="px-3 py-1.5 bg-white hover:bg-cyan-100 text-cyan-900 border border-cyan-300 rounded-xl text-[11px] font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1"
          >
            <i className="fa-solid fa-bolt text-cyan-600"></i>
            <span>فحص القاعدة</span>
          </button>
        </div>

        {/* Custom Registered Databases */}
        {databases.map((db) => (
          <div
            key={db.id}
            className="p-3.5 bg-white border border-slate-200 rounded-2xl flex items-center justify-between gap-3 hover:border-slate-300 transition-all shadow-2xs"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 border border-slate-200 flex items-center justify-center font-bold text-sm shrink-0">
                <i className="fa-solid fa-database text-blue-600"></i>
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                  <span>{db.name}</span>
                  {db.description && (
                    <span className="text-[10px] text-slate-500 font-normal">({db.description})</span>
                  )}
                </div>
                <div className="text-[10px] text-slate-400 font-mono truncate mt-0.5" dir="ltr">
                  {db.url}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => handleTestExistingDb(db)}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1"
                title="فحص الاتصال بهذه القاعدة"
              >
                <i className="fa-solid fa-plug text-blue-600"></i>
                <span>فحص</span>
              </button>

              <button
                type="button"
                onClick={() => promptDeleteDb(db.id, db.name)}
                className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 active:scale-95"
                title="حذف هذه القاعدة"
              >
                <i className="fa-solid fa-trash-can text-rose-600"></i>
                <span>حذف</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Confirmation Modal for Deleting Database */}
      {dbToDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => !isDeletingDb && setDbToDelete(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-slate-200 text-start space-y-4 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
            dir="rtl"
          >
            {/* Modal Header */}
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center text-lg shrink-0 shadow-2xs">
                <i className="fa-solid fa-triangle-exclamation"></i>
              </div>
              <div className="min-w-0">
                <h3 className="font-extrabold text-sm text-slate-900">
                  تأكيد حذف قاعدة البيانات
                </h3>
                <p className="text-xs text-slate-500 truncate mt-0.5">
                  إزالة إعدادات الربط من النظام
                </p>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-3.5 bg-rose-50/70 border border-rose-200/80 rounded-2xl space-y-2 text-xs text-rose-950">
              <p className="font-bold">
                هل أنت متأكد من رغبتك في حذف قاعدة البيانات:
              </p>
              <div className="p-2.5 bg-white/90 rounded-xl font-black text-slate-900 border border-rose-200 text-xs flex items-center gap-2">
                <i className="fa-solid fa-database text-rose-600"></i>
                <span className="truncate">{dbToDelete.name}</span>
              </div>
              <p className="text-[11px] text-rose-700 leading-relaxed">
                ملاحظة: سيتم إزالة ربط القاعدة من التطبيق، ولن يتم حذف البيانات الفعلية الموجودة على سيرفر Turso السحابي.
              </p>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setDbToDelete(null)}
                disabled={isDeletingDb}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
              >
                إلغاء التراجع
              </button>

              <button
                type="button"
                onClick={executeDeleteDb}
                disabled={isDeletingDb}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-50 active:scale-95"
              >
                {isDeletingDb ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                    <span>جاري الحذف...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-trash-can text-xs"></i>
                    <span>نعم، تأكيد الحذف</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
