import React, { useState, useRef } from 'react';
import { AppSettings, Debtor, User, InstallmentRecord, Manager } from '../types';
import { formatNumber } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import {
  exportFullDatabasePackage,
  parseMigrationFile,
  executeDatabaseMigration,
  MigrationPreviewData,
  MigrationProgressStatus,
} from '../services/databaseMigration';

interface DatabaseMigrationSectionProps {
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  managers?: Manager[];
  settings: AppSettings;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
  onMigrationSuccess?: () => Promise<void> | void;
}

export const DatabaseMigrationSection: React.FC<DatabaseMigrationSectionProps> = ({
  currentUser,
  debtors,
  installments = [],
  managers = [],
  settings,
  onShowToast,
  onMigrationSuccess,
}) => {
  const { t, getCurrencySymbol } = useI18n();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // States
  const [isExporting, setIsExporting] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [preview, setPreview] = useState<MigrationPreviewData | null>(null);
  const [migrationMode, setMigrationMode] = useState<'replace' | 'merge'>('replace');
  const [isMigrating, setIsMigrating] = useState(false);
  const [progress, setProgress] = useState<MigrationProgressStatus | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<number | 'all'>('all');

  const numberFormat = settings.numberFormat || 'english';
  const currSym = getCurrencySymbol();

  // ----------------------------------------------------
  // 1. EXPORT FULL DATABASE PACKAGE
  // ----------------------------------------------------
  const handleExport = async () => {
    try {
      setIsExporting(true);
      const res = await exportFullDatabasePackage(
        currentUser,
        managers,
        debtors,
        installments,
        settings
      );
      onShowToast(
        `تم تجهيز وتنزيل حزمة الترحيل الشاملة بنجاح (${res.summary.totalManagers} مدراء • ${res.summary.totalDebtors} مدينين • ${res.summary.totalInstallments} أقساط)`,
        'success'
      );
    } catch (err: any) {
      onShowToast(err.message || 'فشل تجهيز حزمة الترحيل', 'error');
    } finally {
      setIsExporting(false);
    }
  };

  // ----------------------------------------------------
  // 2. UPLOAD & INSPECT MIGRATION FILE
  // ----------------------------------------------------
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.json')) {
      onShowToast('يرجى اختيار ملف بصيغة JSON صالحة', 'error');
      return;
    }

    setIsParsing(true);
    const reader = new FileReader();

    reader.onload = (evt) => {
      try {
        const text = evt.target?.result as string;
        const parsedData = parseMigrationFile(text, file.name, currentUser.id);
        setPreview(parsedData);
        onShowToast(
          `تم فحص ملف الترحيل بنجاح: تم كشف ${parsedData.totalManagersCount} مدير فرعي، ${parsedData.totalDebtorsCount} مدين، و${parsedData.totalInstallmentsCount} عقد قسط`,
          'info'
        );
      } catch (err: any) {
        onShowToast(err.message || 'فشل فحص وتحليل ملف الترحيل', 'error');
        setPreview(null);
      } finally {
        setIsParsing(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    reader.onerror = () => {
      setIsParsing(false);
      onShowToast('حدث خطأ أثناء قراءة الملف من الجهاز', 'error');
    };

    reader.readAsText(file);
  };

  // ----------------------------------------------------
  // 3. EXECUTE MIGRATION
  // ----------------------------------------------------
  const handleStartMigration = async () => {
    if (!preview) return;
    setShowConfirmModal(false);
    setIsMigrating(true);
    setProgress({
      step: 1,
      totalSteps: 5,
      title: 'بدء نقل وترحيل قاعدة البيانات',
      message: 'جاري تهيئة الاتصال وتجهيز الجداول...',
      percent: 10,
    });

    try {
      const res = await executeDatabaseMigration(
        preview,
        migrationMode,
        currentUser,
        managers,
        (status) => {
          setProgress(status);
        }
      );

      onShowToast(
        `اكتملت عملية الترحيل بنجاح! تم نقل ${res.managersCount} مدير فرعي و${res.debtorsCount} مدين و${res.installmentsCount} عقد قسط`,
        'success'
      );

      if (onMigrationSuccess) {
        await onMigrationSuccess();
      }
    } catch (err: any) {
      onShowToast(err.message || 'فشلت عملية ترحيل قاعدة البيانات', 'error');
    } finally {
      setIsMigrating(false);
    }
  };

  const handleResetPreview = () => {
    setPreview(null);
    setProgress(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-6 text-slate-800 animate-in fade-in duration-200">
      {/* Migration Notice Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 text-white rounded-3xl p-5 shadow-sm border border-indigo-800/40 relative overflow-hidden">
        <div className="flex items-start gap-4 relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-2xl text-indigo-300 shrink-0 border border-white/10">
            <i className="fa-solid fa-database"></i>
          </div>
          <div className="space-y-1.5 flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-base text-white">
                أداة نقل وترحيل قاعدة البيانات الشاملة
              </h3>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                قاعدة قديمة ➔ قاعدة جديدة
              </span>
            </div>
            <p className="text-xs text-indigo-200/90 leading-relaxed">
              هذه الأداة مخصصة لنقل <strong>كافة بيانات النظام بالكامل</strong> بما فيها حسابات المدراء الفرعيين وفروعهم وكلمات مرورهم وصلاحياتهم، وربط كل ديون وأقساط كل فرع بحسابه تلقائياً دون أي فقدان أو اختلاط.
            </p>
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------- */}
      {/* SECTION 1: EXPORT FULL MIGRATION PACKAGE */}
      {/* ---------------------------------------------------- */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-700 flex items-center justify-center text-lg font-bold shrink-0 border border-purple-100">
              <i className="fa-solid fa-file-export"></i>
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">
                1. تصدير حزمة الترحيل الشاملة (من القاعدة الحالية)
              </h4>
              <p className="text-xs text-slate-500">
                سحب وتجميع كافة بيانات المدراء والفروع والمدينين والأقساط في ملف JSON جاهز للترحيل
              </p>
            </div>
          </div>
        </div>

        {/* Current Database Summary Chips */}
        <div className="grid grid-cols-3 gap-2.5 bg-slate-50/80 border border-slate-200/60 rounded-2xl p-3 text-xs">
          <div className="space-y-1 text-center">
            <span className="text-[11px] text-slate-500 block">المدراء والفروع</span>
            <span className="font-extrabold font-mono text-purple-700 text-sm">
              {formatNumber(managers.length, numberFormat)}
            </span>
          </div>
          <div className="space-y-1 text-center border-x border-slate-200">
            <span className="text-[11px] text-slate-500 block">إجمالي المدينين</span>
            <span className="font-extrabold font-mono text-slate-800 text-sm">
              {formatNumber(debtors.length, numberFormat)}
            </span>
          </div>
          <div className="space-y-1 text-center">
            <span className="text-[11px] text-slate-500 block">عقود الأقساط</span>
            <span className="font-extrabold font-mono text-emerald-700 text-sm">
              {formatNumber(installments.length, numberFormat)}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleExport}
          disabled={isExporting}
          className="w-full bg-purple-700 hover:bg-purple-800 active:bg-purple-900 text-white py-3 px-4 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2.5 shadow-sm disabled:opacity-50 cursor-pointer"
        >
          {isExporting ? (
            <>
              <i className="fa-solid fa-circle-notch fa-spin"></i>
              <span>جاري استخراج وجمع كافة جداول القاعدة في حزمة الترحيل...</span>
            </>
          ) : (
            <>
              <i className="fa-solid fa-cloud-arrow-down text-sm"></i>
              <span>تصدير حزمة ترحيل قاعدة البيانات الشاملة (Full Migration JSON)</span>
            </>
          )}
        </button>
      </div>

      {/* ---------------------------------------------------- */}
      {/* SECTION 2: IMPORT & TRANSFER TO NEW DATABASE */}
      {/* ---------------------------------------------------- */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center text-lg font-bold shrink-0 border border-emerald-100">
            <i className="fa-solid fa-file-import"></i>
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-900">
              2. رفع واستيراد حزمة الترحيل (للقاعدة الجديدة)
            </h4>
            <p className="text-xs text-slate-500">
              ارفع ملف الترحيل المستخرج من القاعدة القديمة لزراعته بالكامل في هذه القاعدة
            </p>
          </div>
        </div>

        {/* Upload Drop Zone */}
        {!preview && (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-200 hover:border-purple-400 active:border-purple-600 bg-slate-50/50 hover:bg-purple-50/20 rounded-3xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2 group"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".json"
              className="hidden"
            />
            <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-purple-600 group-hover:scale-110 transition-transform shadow-xs">
              <i className="fa-solid fa-arrow-up-from-bracket text-lg"></i>
            </div>
            <div className="space-y-1 mt-1">
              <span className="font-bold text-xs text-slate-800 block">
                اضغط هنا لاختيار ملف الترحيل أو اسحبه وأفلته
              </span>
              <span className="text-[11px] text-slate-400 block">
                يدعم ملفات الترحيل الشاملة (aldion_full_database_migration.json) وملفات النسخ الاحتياطي السابقة
              </span>
            </div>
            {isParsing && (
              <div className="flex items-center gap-2 text-xs text-purple-700 font-bold mt-2">
                <i className="fa-solid fa-circle-notch fa-spin"></i>
                <span>جاري قراءة وتحليل بيانات الملف...</span>
              </div>
            )}
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* PREVIEW OF THE UPLOADED MIGRATION FILE */}
        {/* ---------------------------------------------------- */}
        {preview && (
          <div className="space-y-4 bg-slate-50/80 rounded-3xl p-4 border border-slate-200">
            {/* Header info */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200/60">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center text-sm font-bold">
                  <i className="fa-solid fa-file-lines"></i>
                </div>
                <div>
                  <h5 className="font-bold text-xs text-slate-900 truncate max-w-[200px] sm:max-w-xs">
                    {preview.fileName}
                  </h5>
                  <div className="text-[10px] text-slate-500">
                    {preview.exportDate
                      ? `تاريخ التصدير: ${new Date(preview.exportDate).toLocaleString('ar-IQ')}`
                      : 'ملف ترحيل متوافق'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleResetPreview}
                disabled={isMigrating}
                className="text-xs text-slate-500 hover:text-rose-600 px-2.5 py-1 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <i className="fa-solid fa-xmark me-1"></i>
                إلغاء
              </button>
            </div>

            {/* High-level Counters */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-white p-2.5 rounded-2xl border border-purple-100 shadow-2xs">
                <span className="text-[10px] text-slate-400 block mb-0.5">المدراء المكتشفون</span>
                <span className="font-extrabold font-mono text-purple-700 text-base">
                  {formatNumber(preview.totalManagersCount, numberFormat)}
                </span>
              </div>
              <div className="bg-white p-2.5 rounded-2xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] text-slate-400 block mb-0.5">المدينون الإجمالي</span>
                <span className="font-extrabold font-mono text-slate-900 text-base">
                  {formatNumber(preview.totalDebtorsCount, numberFormat)}
                </span>
              </div>
              <div className="bg-white p-2.5 rounded-2xl border border-emerald-100 shadow-2xs">
                <span className="text-[10px] text-slate-400 block mb-0.5">عقود الأقساط</span>
                <span className="font-extrabold font-mono text-emerald-700 text-base">
                  {formatNumber(preview.totalInstallmentsCount, numberFormat)}
                </span>
              </div>
            </div>

            {/* Total Debt Banner */}
            <div className="bg-white rounded-2xl p-3 border border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">إجمالي حجم الديون المحمولة في الملف:</span>
              <span className="font-extrabold font-mono text-rose-600">
                {formatNumber(preview.totalDebtAmount, numberFormat)} {currSym}
              </span>
            </div>

            {/* ------------------------------------------------ */}
            {/* Detailed Branch Breakdown List */}
            {/* ------------------------------------------------ */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-700 flex items-center gap-1.5">
                  <i className="fa-solid fa-users text-purple-600"></i>
                  <span>توزيع الحسابات والبيانات حسب كل مدير فرعي:</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {preview.branchBreakdown.length} فروع/حسابات
                </span>
              </div>

              <div className="max-h-56 overflow-y-auto space-y-2 pe-1">
                {preview.branchBreakdown.map((b) => (
                  <div
                    key={b.managerId}
                    className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-2xs space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="w-2 h-2 rounded-full bg-purple-600 shrink-0"></span>
                        <div className="truncate">
                          <span className="font-bold text-slate-900 block truncate">
                            {b.branchName}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono block truncate">
                            @{b.managerUsername}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                          {b.allowedModules === 'debts'
                            ? 'ديون فقط'
                            : b.allowedModules === 'installments'
                            ? 'أقساط فقط'
                            : 'ديون + أقساط'}
                        </span>
                        {b.hasPlainPassword ? (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200" title="كلمة المرور موجودة ومجهزة">
                            <i className="fa-solid fa-key me-0.5"></i> جاهزة
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200" title="كلمة المرور الافتراضية 123456">
                            افتراضية
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100 text-[11px]">
                      <div className="text-slate-600">
                        <span className="text-slate-400 me-1">المدينين:</span>
                        <strong className="font-mono text-slate-800">
                          {formatNumber(b.debtorsCount, numberFormat)}
                        </strong>
                        <span className="text-[10px] text-slate-400 ms-1">
                          ({formatNumber(b.totalDebt, numberFormat)})
                        </span>
                      </div>
                      <div className="text-slate-600 text-end">
                        <span className="text-slate-400 me-1">عقود الأقساط:</span>
                        <strong className="font-mono text-emerald-700">
                          {formatNumber(b.installmentsCount, numberFormat)}
                        </strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ------------------------------------------------ */}
            {/* Migration Mode Selection */}
            {/* ------------------------------------------------ */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <label className="block text-xs font-bold text-slate-700">
                اختر طريقة ترحيل البيانات إلى هذه القاعدة:
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setMigrationMode('replace')}
                  className={`p-3 rounded-2xl border text-start transition-all cursor-pointer ${
                    migrationMode === 'replace'
                      ? 'border-rose-500 bg-rose-50/50 ring-2 ring-rose-500/20'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        migrationMode === 'replace'
                          ? 'border-rose-600 bg-rose-600 text-white'
                          : 'border-slate-300'
                      }`}
                    >
                      {migrationMode === 'replace' && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                    </div>
                    <span className="font-bold text-xs text-rose-700">
                      استبدال شامل (قاعدة بيانات جديدة)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 ps-6">
                    مسح السجلات السابقة وزراعة كل حسابات المدراء والمدينين والأقساط القديمة بدقة 100%. (الأفضل للانتقال لقاعدة جديدة).
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setMigrationMode('merge')}
                  className={`p-3 rounded-2xl border text-start transition-all cursor-pointer ${
                    migrationMode === 'merge'
                      ? 'border-purple-600 bg-purple-50/50 ring-2 ring-purple-600/20'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        migrationMode === 'merge'
                          ? 'border-purple-600 bg-purple-600 text-white'
                          : 'border-slate-300'
                      }`}
                    >
                      {migrationMode === 'merge' && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                    </div>
                    <span className="font-bold text-xs text-purple-700">
                      دمج ترحيلي ذكي (Smart Merge)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 ps-6">
                    إبقاء البيانات الحالية وإضافة المدراء والمدينين والأقساط غير الموجودة دون حذف أي سجل موجود.
                  </p>
                </button>
              </div>
            </div>

            {/* Execute Button */}
            <button
              type="button"
              onClick={() => setShowConfirmModal(true)}
              disabled={isMigrating}
              className={`w-full py-3.5 px-4 rounded-2xl font-bold text-xs text-white transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer ${
                migrationMode === 'replace'
                  ? 'bg-rose-600 hover:bg-rose-700 active:bg-rose-800'
                  : 'bg-purple-700 hover:bg-purple-800 active:bg-purple-900'
              }`}
            >
              <i className="fa-solid fa-play"></i>
              <span>
                {migrationMode === 'replace'
                  ? 'بدء الاستبدال والترحيل الشامل إلى القاعدة الجديدة'
                  : 'بدء الدمج والترحيل الذكي إلى القاعدة الحالية'}
              </span>
            </button>
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* PROGRESS TRACKER */}
        {/* ---------------------------------------------------- */}
        {progress && (
          <div className="bg-white rounded-3xl p-5 border border-purple-200 shadow-sm space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-600 animate-pulse"></span>
                <strong className="text-slate-900 font-bold">{progress.title}</strong>
              </div>
              <span className="font-mono font-extrabold text-purple-700">
                {progress.percent}%
              </span>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-gradient-to-r from-purple-600 to-indigo-600 h-full rounded-full transition-all duration-300"
                style={{ width: `${progress.percent}%` }}
              ></div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {progress.message}
            </p>

            {progress.isFinished && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl p-3 text-xs flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <i className="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                  <strong>تم نقل وترحيل قاعدة البيانات بنجاح تام!</strong>
                </span>
                <button
                  type="button"
                  onClick={() => window.location.reload()}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded-xl cursor-pointer shadow-2xs"
                >
                  تحديث فوري
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ---------------------------------------------------- */}
      {/* CONFIRMATION MODAL */}
      {/* ---------------------------------------------------- */}
      {showConfirmModal && preview && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl border border-slate-100 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl mx-auto border border-amber-200">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>

            <div className="text-center space-y-1.5">
              <h4 className="font-extrabold text-sm text-slate-900">
                تأكيد تنفيذ ترحيل قاعدة البيانات
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                {migrationMode === 'replace'
                  ? `أنت على وشك استبدال محتويات قاعدة البيانات الحالية وزراعة ${preview.totalManagersCount} مدير فرعي و${preview.totalDebtorsCount} مدين و${preview.totalInstallmentsCount} عقد قسط.`
                  : `أنت على وشك دمج ${preview.totalManagersCount} مدير فرعي و${preview.totalDebtorsCount} مدين و${preview.totalInstallmentsCount} عقد قسط مع قاعدة البيانات الحالية.`}
              </p>
            </div>

            <div className="bg-slate-50 rounded-2xl p-3 text-xs space-y-1 text-slate-600 border border-slate-200">
              <div className="flex justify-between">
                <span>طريقة الترحيل:</span>
                <strong className={migrationMode === 'replace' ? 'text-rose-600' : 'text-purple-600'}>
                  {migrationMode === 'replace' ? 'استبدال شامل للقاعدة' : 'دمج ذكي مع القاعدة'}
                </strong>
              </div>
              <div className="flex justify-between">
                <span>عدد الفروع والمدراء:</span>
                <strong className="font-mono">{preview.totalManagersCount}</strong>
              </div>
              <div className="flex justify-between">
                <span>إجمالي المدينين:</span>
                <strong className="font-mono">{preview.totalDebtorsCount}</strong>
              </div>
              <div className="flex justify-between">
                <span>إجمالي عقود الأقساط:</span>
                <strong className="font-mono">{preview.totalInstallmentsCount}</strong>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="py-2.5 px-3 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                تراجع
              </button>
              <button
                type="button"
                onClick={handleStartMigration}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold text-white cursor-pointer shadow-sm ${
                  migrationMode === 'replace'
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-purple-700 hover:bg-purple-800'
                }`}
              >
                تأكيد وبدء الترحيل
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
