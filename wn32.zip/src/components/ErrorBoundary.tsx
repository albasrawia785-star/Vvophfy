import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  // @ts-ignore
  props: Props;
  // @ts-ignore
  state: State;

  constructor(props: Props) {
    super(props);
    this.props = props;
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught Error in App:', error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleClearCache = () => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {}
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#070e24] text-white flex items-center justify-center p-4 font-sans dir-rtl" dir="rtl">
          <div className="max-w-md w-full bg-[#0d162f] border border-slate-700/60 rounded-3xl p-6 shadow-2xl text-center space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto text-2xl">
              <i className="fa-solid fa-arrows-rotate animate-spin"></i>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white mb-1">
                تحديث واستعادة تشغيل النظام
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                حدث تحديث في ملفات التطبيق. يرجى الضغط على الزر أدناه لإعادة تحميل الواجهة بسلاسة.
              </p>
            </div>

            {this.state.error && (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 text-[11px] font-mono text-slate-400 text-start overflow-x-auto max-h-24">
                {this.state.error.toString()}
              </div>
            )}

            <div className="space-y-2.5 pt-2">
              <button
                type="button"
                onClick={this.handleReload}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-rotate-right"></i>
                <span>إعادة تشغيل النظام الآن</span>
              </button>

              <button
                type="button"
                onClick={this.handleClearCache}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 border border-slate-700/50"
              >
                <i className="fa-solid fa-broom"></i>
                <span>تنظيف الذاكرة المؤقتة وإعادة الفتح</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
