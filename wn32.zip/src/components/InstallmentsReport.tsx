import React, { useState, useMemo } from 'react';
import { InstallmentRecord } from '../types';
import { formatNumber, formatDateDigits } from '../utils/formatters';
import { formatDueDateBadge } from '../utils/installmentHelpers';
import { useI18n } from '../i18n/index.tsx';

interface InstallmentsReportProps {
  installments: InstallmentRecord[];
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const InstallmentsReport: React.FC<InstallmentsReportProps> = ({
  installments,
  onShowToast,
}) => {
  const { t, numberFormat, currency } = useI18n();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'due_and_overdue' | 'active' | 'completed'>('all');
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());

  const toggleExpand = (id: number) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Calculations
  const stats = useMemo(() => {
    let totalInstallmentValue = 0;
    let totalDownAndPaid = 0;
    let totalRemaining = 0;
    let completedCount = 0;
    let dueOrOverdueCount = 0;

    installments.forEach((inst) => {
      totalInstallmentValue += Number(inst.totalAmount) || 0;
      totalRemaining += Number(inst.remainingAmount) || 0;
      const paidForInst = (Number(inst.totalAmount) || 0) - (Number(inst.remainingAmount) || 0);
      totalDownAndPaid += paidForInst;

      if (inst.status === 'completed' || inst.remainingAmount <= 0) {
        completedCount++;
      } else if (inst.status === 'due' || inst.status === 'overdue') {
        dueOrOverdueCount++;
      }
    });

    return {
      totalInstallmentValue,
      totalDownAndPaid,
      totalRemaining,
      completedCount,
      dueOrOverdueCount,
      totalCount: installments.length,
    };
  }, [installments]);

  // Filtered List
  const filteredInstallments = useMemo(() => {
    return installments.filter((inst) => {
      if (statusFilter === 'completed' && inst.status !== 'completed' && inst.remainingAmount > 0) return false;
      if (statusFilter === 'active' && inst.status !== 'active') return false;
      if (statusFilter === 'due_and_overdue' && inst.status !== 'due' && inst.status !== 'overdue') return false;

      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase().trim();
        const matches =
          (inst.name || '').toLowerCase().includes(term) ||
          (inst.item || '').toLowerCase().includes(term) ||
          (inst.phone && inst.phone.includes(term));
        if (!matches) return false;
      }
      return true;
    });
  }, [installments, statusFilter, searchTerm]);

  return (
    <div className="space-y-3.5 animate-in fade-in duration-150">
      {/* 1. Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
        {/* Total Value */}
        <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-slate-500">{t('reports.totalInstallmentsValue', 'مجموع عقود الأقساط')}</span>
            <div className="w-7 h-7 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-xs font-bold">
              <i className="fa-solid fa-file-invoice-dollar"></i>
            </div>
          </div>
          <div className="font-mono text-base sm:text-xl font-black text-purple-700 tracking-tight">
            {formatNumber(stats.totalInstallmentValue, numberFormat)} <span className="text-xs font-bold">{currency}</span>
          </div>
          <div className="text-[10.5px] font-medium text-slate-400 mt-1">
            {formatNumber(stats.totalCount, numberFormat)} {t('reports.registeredContracts', 'معاملة مسجلة')}
          </div>
        </div>

        {/* Collected */}
        <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-slate-500">{t('reports.collectedInstallments', 'المحصل (مقدمات ودفعات)')}</span>
            <div className="w-7 h-7 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xs font-bold">
              <i className="fa-solid fa-hand-holding-dollar"></i>
            </div>
          </div>
          <div className="font-mono text-base sm:text-xl font-black text-emerald-600 tracking-tight">
            {formatNumber(stats.totalDownAndPaid, numberFormat)} <span className="text-xs font-bold">{currency}</span>
          </div>
          <div className="text-[10.5px] font-medium text-slate-400 mt-1">
            {t('reports.collectionRatio', 'نسبة التحصيل')}: {formatNumber(stats.totalInstallmentValue > 0 ? Math.round((stats.totalDownAndPaid / stats.totalInstallmentValue) * 100) : 0, numberFormat)}%
          </div>
        </div>

        {/* Remaining to Collect */}
        <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-slate-500">{t('reports.remainingToCollect', 'المتبقي المطلوب تحصيله')}</span>
            <div className="w-7 h-7 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xs font-bold">
              <i className="fa-solid fa-hourglass-half"></i>
            </div>
          </div>
          <div className="font-mono text-base sm:text-xl font-black text-amber-600 tracking-tight">
            {formatNumber(stats.totalRemaining, numberFormat)} <span className="text-xs font-bold">{currency}</span>
          </div>
          <div className="text-[10.5px] font-medium text-slate-400 mt-1">
            {formatNumber(stats.dueOrOverdueCount, numberFormat)} {t('reports.dueInstallmentsCount', 'أقساط مستحقة حالياً')}
          </div>
        </div>

        {/* Completed count */}
        <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-slate-500">{t('reports.completedContracts', 'المعاملات المكتملة')}</span>
            <div className="w-7 h-7 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold">
              <i className="fa-solid fa-circle-check"></i>
            </div>
          </div>
          <div className="font-mono text-base sm:text-xl font-black text-blue-600 tracking-tight">
            {formatNumber(stats.completedCount, numberFormat)} <span className="text-xs font-bold">{t('reports.contracts', 'معاملة')}</span>
          </div>
          <div className="text-[10.5px] font-medium text-slate-400 mt-1">
            {t('reports.fullySettled', 'مسددة بالكامل')}
          </div>
        </div>
      </div>

      {/* 2. Search and Status Filters */}
      <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
          {/* Search */}
          <div className="relative flex-1">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t('installments.searchPlaceholder', 'ابحث بالاسم أو السلعة أو رقم الهاتف...')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-9 text-xs outline-none focus:border-emerald-600 focus:bg-white transition-all font-medium text-slate-800"
            />
            <i className="fa-solid fa-magnifying-glass absolute start-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs pointer-events-none"></i>
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs p-1 cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            )}
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {[
              { id: 'all', label: t('reports.allInstallments', 'كافة الأقساط') },
              { id: 'due_and_overdue', label: t('reports.dueAndOverdue', 'المستحقة والمتأخرة') },
              { id: 'active', label: t('reports.active', 'النشطة') },
              { id: 'completed', label: t('reports.completed', 'المسددة بالكامل') },
            ].map((btn) => (
              <button
                key={btn.id}
                type="button"
                onClick={() => setStatusFilter(btn.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  statusFilter === btn.id
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>
        </div>

        {/* List of Installment Records Accordion */}
        <div className="space-y-2 pt-1">
          {filteredInstallments.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              {t('installments.noFilteredInstallments', 'لا توجد معاملات أقساط مطابقة للفلتر المحدد')}
            </div>
          ) : (
            filteredInstallments.map((inst) => {
              const isExpanded = expandedIds.has(inst.id);
              const payments = inst.payments || [];

              return (
                <div
                  key={inst.id}
                  className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden transition-all"
                >
                  {/* Summary Bar */}
                  <div
                    onClick={() => toggleExpand(inst.id)}
                    className="p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 cursor-pointer select-none transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center text-xs font-black shrink-0 border border-emerald-100">
                        <i className="fa-solid fa-receipt"></i>
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-xs sm:text-sm text-slate-900 break-words leading-snug">
                            {inst.name}
                          </span>
                          <span className="text-[10px] font-bold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-100 shrink-0">
                            {inst.item}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5 font-mono flex-wrap">
                          <span>{inst.phone ? formatDateDigits(inst.phone, numberFormat) : t('debtors.noPhone', 'بدون هاتف')}</span>
                          <span>•</span>
                          <span>{t('installments.regDate', 'التسجيل')}: {formatDateDigits(inst.registrationDate, numberFormat)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 text-end">
                      <div>
                        <div className="text-xs sm:text-sm font-black text-rose-600 font-mono">
                          {formatNumber(inst.remainingAmount, numberFormat)} {currency}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {t('reports.outOf', 'من أصل')} {formatNumber(inst.totalAmount, numberFormat)}
                        </div>
                      </div>

                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-slate-400 transition-transform ${
                        isExpanded ? 'rotate-180 bg-slate-100 text-slate-700' : ''
                      }`}>
                        <i className="fa-solid fa-chevron-down text-xs"></i>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Details & Payments */}
                  {isExpanded && (
                    <div className="p-4 bg-slate-50/70 border-t border-slate-100 space-y-3 animate-in fade-in duration-150">
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-[10px] text-slate-400 block font-medium">{t('installments.totalAmount', 'المبلغ الإجمالي')}</span>
                          <span className="font-bold font-mono text-slate-800">{formatNumber(inst.totalAmount, numberFormat)} {currency}</span>
                        </div>
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-[10px] text-slate-400 block font-medium">{t('installments.downPayment', 'الدفعة المقدمة')}</span>
                          <span className="font-bold font-mono text-emerald-600">{formatNumber(inst.downPayment, numberFormat)} {currency}</span>
                        </div>
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-[10px] text-slate-400 block font-medium">{t('installments.remaining', 'المتبقي للتحصيل')}</span>
                          <span className="font-bold font-mono text-rose-600">{formatNumber(inst.remainingAmount, numberFormat)} {currency}</span>
                        </div>
                        <div className="bg-white p-2.5 rounded-xl border border-slate-200/60">
                          <span className="text-[10px] text-slate-400 block font-medium">{t('installments.dueDate', 'الاستحقاق القادم')}</span>
                          <span className="font-bold font-mono text-slate-800">{formatDateDigits(inst.nextDueDate, numberFormat)}</span>
                        </div>
                      </div>

                      {/* Payment History */}
                      <div className="space-y-1.5 pt-1">
                        <div className="text-[11px] font-bold text-slate-600 px-1">
                          {t('reports.paymentsHistory', 'سجل الدفعات والتسديدات')} ({formatNumber(payments.length, numberFormat)}):
                        </div>
                        {payments.length === 0 ? (
                          <div className="text-[11px] text-slate-400 bg-white p-3 rounded-xl text-center border border-slate-100">
                            {t('reports.noPaymentsYet', 'لا توجد دفعات مسددة بعد')}
                          </div>
                        ) : (
                          <div className="bg-white rounded-xl border border-slate-200/70 divide-y divide-slate-100 overflow-hidden">
                            {payments.map((p, idx) => (
                              <div key={p.id || idx} className="p-2.5 flex items-center justify-between text-xs">
                                <div className="flex items-center gap-2">
                                  <div className="w-6 h-6 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center text-[10px]">
                                    <i className="fa-solid fa-arrow-down"></i>
                                  </div>
                                  <div>
                                    <span className="font-bold text-emerald-700">{t('installments.payInstallment', 'تسديد دفعة')}</span>
                                    <span className="text-slate-400 text-[10px] font-mono mx-2">{formatDateDigits(p.date, numberFormat)}</span>
                                    {p.notes && <span className="text-slate-500 text-[10px] block">{p.notes}</span>}
                                  </div>
                                </div>
                                <div className="text-end font-mono">
                                  <span className="font-bold text-emerald-600">+{formatNumber(p.amount, numberFormat)} {currency}</span>
                                  <span className="text-[10px] text-slate-400 block">{t('installments.remaining', 'المتبقي')}: {formatNumber(p.remainingAfter, numberFormat)} {currency}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

