import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { InstallmentFilterType, InstallmentRecord } from '../types';
import { formatNumber } from '../utils/formatters';
import { VirtualGrid } from './VirtualGrid';
import { InstallmentCard } from './InstallmentCard';
import { AddInstallmentModal } from './AddInstallmentModal';
import { SettleInstallmentPaymentModal } from './SettleInstallmentPaymentModal';
import { InstallmentDetailsModal } from './InstallmentDetailsModal';
import { EditInstallmentModal } from './EditInstallmentModal';
import { useI18n } from '../i18n/index.tsx';

interface InstallmentsTabProps {
  installments: InstallmentRecord[];
  onAddInstallment: (inst: Omit<InstallmentRecord, 'id'>) => Promise<void>;
  onUpdateInstallment: (inst: InstallmentRecord) => Promise<void>;
  onSettlePayment: (installmentId: number, amount: number, date: string, notes?: string) => Promise<void>;
  onDeleteInstallment: (id: number) => Promise<void>;
  userId: number;
  isTrialMode?: boolean;
  onTrialLimitReached?: () => void;
  numberFormat?: 'english' | 'arabic';
}

export const InstallmentsTab: React.FC<InstallmentsTabProps> = React.memo(({
  installments,
  onAddInstallment,
  onUpdateInstallment,
  onSettlePayment,
  onDeleteInstallment,
  userId,
  isTrialMode = false,
  onTrialLimitReached,
  numberFormat: propsNumFormat,
}) => {
  const { t, numberFormat: ctxNumFormat } = useI18n();
  const numberFormat = propsNumFormat || ctxNumFormat;

  const [inputSearchTerm, setInputSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [filter, setFilter] = useState<InstallmentFilterType>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedForDetails, setSelectedForDetails] = useState<InstallmentRecord | null>(null);
  const [selectedForSettle, setSelectedForSettle] = useState<InstallmentRecord | null>(null);
  const [selectedForEdit, setSelectedForEdit] = useState<InstallmentRecord | null>(null);

  const debounceTimerRef = useRef<any>(null);

  const handleSearchChange = (val: string) => {
    setInputSearchTerm(val);
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      setDebouncedSearchTerm(val);
    }, 180);
  };

  const handleClearSearch = () => {
    setInputSearchTerm('');
    setDebouncedSearchTerm('');
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
  };

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, []);

  const handleOpenAddModal = useCallback(() => {
    if (isTrialMode && installments.length >= 2) {
      if (onTrialLimitReached) {
        onTrialLimitReached();
      }
      return;
    }
    setIsAddModalOpen(true);
  }, [isTrialMode, installments.length, onTrialLimitReached]);

  // Statistics - ultra-fast single loop
  const stats = useMemo(() => {
    let totalInstallmentValue = 0;
    let totalRemaining = 0;
    let totalDownAndPaid = 0;
    let dueCount = 0;
    let overdueCount = 0;
    let completedCount = 0;
    const len = installments.length;

    for (let i = 0; i < len; i++) {
      const inst = installments[i];
      if (!inst) continue;
      const tot = Number(inst.totalAmount) || 0;
      const rem = Number(inst.remainingAmount) || 0;
      totalInstallmentValue += tot;
      totalRemaining += rem;
      totalDownAndPaid += tot - rem;

      const st = inst.status;
      if (st === 'due') dueCount++;
      else if (st === 'overdue') overdueCount++;
      else if (st === 'completed') completedCount++;
    }

    return {
      totalCount: installments.length,
      totalInstallmentValue,
      totalRemaining,
      totalDownAndPaid,
      dueCount,
      overdueCount,
      dueAndOverdueCount: dueCount + overdueCount,
      completedCount,
    };
  }, [installments]);

  // Filter & Search - instantaneous bypass and capped search results
  const filteredInstallments = useMemo(() => {
    const search = debouncedSearchTerm.trim().toLowerCase();
    const isFilterAll = filter === 'all';

    if (!search && isFilterAll) {
      return installments;
    }

    const results: InstallmentRecord[] = [];
    const len = installments.length;
    const maxResults = 5000;

    for (let i = 0; i < len; i++) {
      const inst = installments[i];
      if (!inst) continue;

      // 1. Status filter
      if (filter === 'due_and_overdue' && inst.status !== 'due' && inst.status !== 'overdue') continue;
      if (filter === 'due' && inst.status !== 'due') continue;
      if (filter === 'overdue' && inst.status !== 'overdue') continue;
      if (filter === 'active' && inst.status !== 'active') continue;
      if (filter === 'completed' && inst.status !== 'completed') continue;

      // 2. Search filter
      if (search) {
        const name = (inst.name || '').toLowerCase();
        const item = (inst.item || '').toLowerCase();
        const phone = inst.phone ? String(inst.phone) : '';
        if (!name.includes(search) && !item.includes(search) && !phone.includes(search)) {
          continue;
        }
      }

      results.push(inst);
      if (results.length >= maxResults) break;
    }

    return results;
  }, [installments, debouncedSearchTerm, filter]);

  const handleOpenDetailsCallback = useCallback((item: InstallmentRecord) => {
    setSelectedForDetails(item);
  }, []);

  const handleOpenSettleCallback = useCallback((item: InstallmentRecord) => {
    setSelectedForSettle(item);
  }, []);

  const handleOpenEditCallback = useCallback((item: InstallmentRecord) => {
    setSelectedForEdit(item);
  }, []);

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-200">
      {/* Sticky Top Controls & Filters */}
      <div className="shrink-0 space-y-2.5 pb-2.5 bg-slate-50 z-20">
        {/* Search Bar */}
        <div className="relative">
          <input
            type="text"
            value={inputSearchTerm}
            onChange={(e) => handleSearchChange(e.target.value)}
            placeholder={t('installments.searchPlaceholder', 'بحث بالاسم، نوع السلعة، أو رقم الهاتف...')}
            className="w-full pl-9 pr-9 py-2.5 bg-white hover:bg-slate-50 focus:bg-white text-slate-800 placeholder:text-slate-400 rounded-2xl text-xs font-semibold border border-slate-200/80 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 shadow-2xs outline-none transition-all"
          />
          <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs">
            <i className="fa-solid fa-magnifying-glass"></i>
          </span>
          {inputSearchTerm && (
            <button
              type="button"
              onClick={handleClearSearch}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer p-1"
              title={t('common.clear', 'مسح')}
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 pt-0.5">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
              filter === 'all'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
            }`}
          >
            <span>{t('common.all', 'الكل')}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${filter === 'all' ? 'bg-white/20' : 'bg-slate-100'}`}>
              {formatNumber(stats.totalCount, numberFormat)}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setFilter('due_and_overdue')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
              filter === 'due_and_overdue'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
            }`}
          >
            <i className="fa-solid fa-triangle-exclamation text-[10px]"></i>
            <span>{t('installments.dueOrOverdueFilter', 'المستحق والمتأخر')}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${filter === 'due_and_overdue' ? 'bg-white/20' : 'bg-slate-100 text-rose-600 font-bold'}`}>
              {formatNumber(stats.dueAndOverdueCount, numberFormat)}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setFilter('active')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
              filter === 'active'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
            }`}
          >
            <span>{t('installments.activeFilter', 'جارية')}</span>
          </button>

          <button
            type="button"
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
              filter === 'completed'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
            }`}
          >
            <i className="fa-solid fa-check text-[10px]"></i>
            <span>{t('installments.completedFilter', 'مكتملة')}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${filter === 'completed' ? 'bg-white/20' : 'bg-slate-100'}`}>
              {formatNumber(stats.completedCount, numberFormat)}
            </span>
          </button>
        </div>
      </div>

      {/* Installments List */}
      <div className="flex-1 overflow-y-auto overscroll-contain pb-32 sm:pb-36 pt-1 focus:outline-none" id="installmentsListScrollContainer">
        {filteredInstallments.length > 0 ? (
          <VirtualGrid<InstallmentRecord>
            items={filteredInstallments}
            itemHeight={240}
            gap={10}
            columns={{ default: 1, md: 2 }}
            overscan={3}
            keyExtractor={(inst: InstallmentRecord) => inst.id}
            renderItem={(inst: InstallmentRecord) => (
              <InstallmentCard
                installment={inst}
                onOpenDetails={handleOpenDetailsCallback}
                onOpenSettleModal={handleOpenSettleCallback}
                onOpenEditModal={handleOpenEditCallback}
                onDelete={onDeleteInstallment}
                numberFormat={numberFormat}
              />
            )}
          />
        ) : (
          <div className="p-8 rounded-3xl bg-white border border-dashed border-slate-200 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl">
              <i className="fa-solid fa-clock-rotate-left"></i>
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-800">
                {debouncedSearchTerm ? t('installments.noSearchResults', 'لم يتم العثور على أي قسط يطابق بحثك') : t('installments.emptyNoInstallments', 'لا توجد معاملات أقساط مسجلة بعد')}
              </h3>
              <p className="text-xs text-slate-400">
                {debouncedSearchTerm
                  ? t('installments.noSearchResultsDesc', 'جرّب البحث باسم آخر أو إزالة التصفية')
                  : t('installments.emptyNoInstallmentsDesc', 'يمكنك البدء بتسجيل معاملات الأقساط الشهرية لسلعك من الزر أعلاه أو زر (+) بالأسفل')}
              </p>
            </div>
            {!debouncedSearchTerm && (
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5"
              >
                <i className="fa-solid fa-plus text-xs"></i>
                <span>{t('installments.addFirstInstallment', 'تسجيل أول معاملة قسط')}</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      <AddInstallmentModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={onAddInstallment}
        userId={userId}
      />

      {selectedForEdit && (
        <EditInstallmentModal
          isOpen={!!selectedForEdit}
          onClose={() => setSelectedForEdit(null)}
          installment={selectedForEdit}
          onSave={onUpdateInstallment}
        />
      )}

      {selectedForSettle && (
        <SettleInstallmentPaymentModal
          isOpen={!!selectedForSettle}
          onClose={() => setSelectedForSettle(null)}
          installment={selectedForSettle}
          onSettle={onSettlePayment}
        />
      )}

      {selectedForDetails && (
        <InstallmentDetailsModal
          isOpen={!!selectedForDetails}
          onClose={() => setSelectedForDetails(null)}
          installment={selectedForDetails}
          onOpenSettleModal={handleOpenSettleCallback}
          onOpenEditModal={handleOpenEditCallback}
          onDelete={onDeleteInstallment}
        />
      )}
    </div>
  );
});

InstallmentsTab.displayName = 'InstallmentsTab';
