import React, { useState, useEffect } from 'react';
import bcrypt from 'bcryptjs';
import { AppSettings, DebtStats, Debtor, Manager, SubscriptionType, User, InstallmentRecord, ManagerModuleAccess, Language, Currency, NumberFormat, DatabaseAccount, AppLayoutTheme } from '../types';
import { formatNumber, formatDateDigits, formatDateArabic, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';
import { getUserBranchDisplayName, getUserDisplayName, getUserRoleDisplayName } from '../utils/userUtils';
import { queryTurso, setLocalSession } from '../services/turso';
import { ManagersTab } from './ManagersTab';
import { BackupRestoreSection } from './BackupRestoreSection';
import { DatabaseMigrationSection } from './DatabaseMigrationSection';
import { DatabaseAccountsSection } from './DatabaseAccountsSection';
import { ThemeSettingsSection } from './ThemeSettingsSection';
import { ConfirmModal } from './ConfirmModal';
import { getLayoutThemeMeta } from '../utils/layoutThemes';
import { useI18n } from '../i18n/index.tsx';

interface SettingsTabProps {
  currentUser: User;
  managers: Manager[];
  databases?: DatabaseAccount[];
  stats?: DebtStats;
  currentDebts?: number;
  onUpdateStats?: (newStats: DebtStats) => void;
  onCreateManager: (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType,
    subscriptionMonths?: number,
    allowedModules?: ManagerModuleAccess,
    databaseId?: string | null,
    layoutTheme?: AppLayoutTheme
  ) => Promise<void>;
  onToggleManagerStatus: (id: number, currentActive: boolean) => Promise<void>;
  onRenewSubscription: (id: number, months?: number) => Promise<void>;
  onChangeSubscriptionType?: (id: number, newType: SubscriptionType, months?: number) => Promise<void>;
  onChangeManagerModules?: (id: number, newAllowedModules: ManagerModuleAccess) => Promise<void>;
  onChangeManagerDatabase?: (id: number, databaseId: string | null) => Promise<void>;
  onChangeManagerTheme?: (id: number, newTheme: AppLayoutTheme) => Promise<void>;
  onDeleteManager: (id: number) => void;
  onRefreshDatabases?: () => Promise<void> | void;
  onRefreshCloud?: () => void;
  onLogout: () => void;
  isSyncing?: boolean;
  isManagersLoading: boolean;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  totalDebtorsCount: number;
  highDebtorsCount: number;
  alertTriggeredCount: number;
  allDebtors?: Debtor[];
  installments?: InstallmentRecord[];
  onImportBackup?: (
    importedDebtors: Debtor[],
    importedInstallments: InstallmentRecord[],
    mode: 'merge' | 'replace',
    importedManagers?: Manager[]
  ) => Promise<void>;
  onImportDebtors?: (importedDebtors: Debtor[], mode: 'merge' | 'replace') => Promise<void>;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
  onAddDemoDebtors?: () => void;
  onAddMillionDemoDebtors?: () => void;
  onAddBillionDemoDebtors?: () => void;
  isBillionDemoActive?: boolean;
  onClearDemoDebtors?: () => void;
  demoDebtorsCount?: number;
  onAddDemoInstallments?: () => void;
  onClearDemoInstallments?: () => void;
  demoInstallmentsCount?: number;
  onUpdateManagerPassword?: (id: number, newPass: string) => Promise<void>;
  onUpgradeNewRegistration?: (
    id: number,
    subscriptionType: SubscriptionType,
    months?: number,
    allowedModules?: ManagerModuleAccess,
    databaseId?: string | null,
    layoutTheme?: AppLayoutTheme
  ) => Promise<void>;
  onRefreshManagers?: () => Promise<void> | void;
  onFullMigrationSuccess?: () => Promise<void> | void;
}

export const SettingsTab: React.FC<SettingsTabProps> = React.memo(({
  currentUser,
  managers,
  databases = [],
  onCreateManager,
  onToggleManagerStatus,
  onRenewSubscription,
  onChangeSubscriptionType,
  onChangeManagerModules,
  onChangeManagerDatabase,
  onChangeManagerTheme,
  onDeleteManager,
  onRefreshDatabases,
  onLogout,
  isManagersLoading,
  settings,
  onUpdateSettings,
  totalDebtorsCount,
  highDebtorsCount,
  alertTriggeredCount,
  allDebtors = [],
  installments = [],
  onImportBackup,
  onImportDebtors,
  onShowToast,
  onAddDemoDebtors,
  onAddMillionDemoDebtors,
  onAddBillionDemoDebtors,
  isBillionDemoActive = false,
  onClearDemoDebtors,
  demoDebtorsCount = 0,
  onAddDemoInstallments,
  onClearDemoInstallments,
  demoInstallmentsCount = 0,
  onUpdateManagerPassword,
  onUpgradeNewRegistration,
  onRefreshManagers,
  onFullMigrationSuccess,
}) => {
  const isAdmin = currentUser.role === 'admin';
  const { language, setLanguage, currency, setCurrency, numberFormat, setNumberFormat, t, formatMoney, getCurrencySymbol, dir } = useI18n();

  // Accordion Sections Open/Close State (Organized Dropdowns - all collapsed by default)
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    languageCurrency: false,
    profile: false,
    theme: false,
    alerts: false,
    highDebt: false,
    migration: false,
    backup: false,
    managers: false,
    database: false,
    demo: false,
  });

  const toggleSection = (key: string) => {
    setOpenSections((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Settings State
  const [enableAlerts, setEnableAlerts] = useState(settings.enableDebtAlerts);
  const [alertDays, setAlertDays] = useState(settings.alertDaysThreshold);
  const [highDebtThreshold, setHighDebtThreshold] = useState(settings.highDebtThreshold);
  const [isSettingsSaved, setIsSettingsSaved] = useState(false);

  // Sub-manager Profile state & handlers (Username, Phone/Email, Password)
  const [userPassword, setUserPassword] = useState<string>(() => {
    return (
      currentUser.password ||
      localStorage.getItem(`user_pwd_${currentUser.id}`) ||
      localStorage.getItem(`user_pwd_${currentUser.username}`) ||
      ''
    );
  });
  const [showUserPassword, setShowUserPassword] = useState(false);
  const [copiedPassword, setCopiedPassword] = useState(false);

  // Full Profile Edit Mode & Confirmation Modal State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [showProfileConfirmModal, setShowProfileConfirmModal] = useState(false);
  const [editUsername, setEditUsername] = useState(currentUser.username || '');
  const [editPhoneOrEmail, setEditPhoneOrEmail] = useState(currentUser.phoneOrEmail || '');
  const [editPasswordInput, setEditPasswordInput] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [profileMessage, setProfileMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Sync profile when currentUser changes
  useEffect(() => {
    const pwd =
      currentUser.password ||
      localStorage.getItem(`user_pwd_${currentUser.id}`) ||
      localStorage.getItem(`user_pwd_${currentUser.username}`) ||
      '';
    if (pwd) {
      setUserPassword(pwd);
    }
    setEditUsername(currentUser.username || '');
    setEditPhoneOrEmail(currentUser.phoneOrEmail || '');
  }, [currentUser]);

  const handleCopyPassword = () => {
    if (!userPassword) return;
    navigator.clipboard.writeText(userPassword);
    setCopiedPassword(true);
    if (onShowToast) {
      onShowToast(t('common.copiedToClipboard', 'تم نسخ كلمة المرور إلى الحافظة بنجاح'), 'success');
    }
    setTimeout(() => setCopiedPassword(false), 2000);
  };

  const handleRequestSaveProfile = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmedUser = editUsername.trim();
    const trimmedContact = editPhoneOrEmail.trim();
    const trimmedPass = editPasswordInput.trim();

    if (!trimmedUser) {
      setProfileMessage({ text: 'يرجى إدخال اسم المستخدم', type: 'error' });
      return;
    }
    if (!trimmedContact) {
      setProfileMessage({ text: 'يرجى إدخال رقم الهاتف', type: 'error' });
      return;
    }
    if (trimmedPass && trimmedPass.length < 3) {
      setProfileMessage({ text: 'كلمة المرور يجب ألا تقل عن 3 خانات', type: 'error' });
      return;
    }

    setShowProfileConfirmModal(true);
  };

  const executeSaveProfile = async () => {
    setShowProfileConfirmModal(false);
    const trimmedUser = editUsername.trim();
    const trimmedContact = editPhoneOrEmail.trim();
    const trimmedPass = editPasswordInput.trim();

    try {
      setIsSavingProfile(true);
      setProfileMessage(null);

      let hashed: string | undefined = undefined;
      if (trimmedPass) {
        const salt = bcrypt.genSaltSync(10);
        hashed = bcrypt.hashSync(trimmedPass, salt);
      }

      if (hashed) {
        try {
          await queryTurso(
            'UPDATE users SET username = ?, phone_or_email = ?, password = ?, plain_password = ? WHERE id = ?;',
            [trimmedUser, trimmedContact, hashed, trimmedPass, currentUser.id]
          );
        } catch {
          await queryTurso('ALTER TABLE users ADD COLUMN phone_or_email TEXT;').catch(() => {});
          await queryTurso('ALTER TABLE users ADD COLUMN plain_password TEXT;').catch(() => {});
          await queryTurso(
            'UPDATE users SET username = ?, phone_or_email = ?, password = ?, plain_password = ? WHERE id = ?;',
            [trimmedUser, trimmedContact, hashed, trimmedPass, currentUser.id]
          );
        }

        try {
          await queryTurso(
            'UPDATE managers SET phone_or_email = ?, phone_number = ?, password = ?, plain_password = ? WHERE id = ? OR user = ? OR username = ?;',
            [trimmedContact, trimmedContact, hashed, trimmedPass, currentUser.id, currentUser.username, currentUser.username]
          ).catch(() => {});
        } catch {}

        setUserPassword(trimmedPass);
        currentUser.password = trimmedPass;
        localStorage.setItem(`user_pwd_${currentUser.id}`, trimmedPass);
        localStorage.setItem(`user_pwd_${trimmedUser}`, trimmedPass);
      } else {
        try {
          await queryTurso(
            'UPDATE users SET username = ?, phone_or_email = ? WHERE id = ?;',
            [trimmedUser, trimmedContact, currentUser.id]
          );
        } catch {
          await queryTurso('ALTER TABLE users ADD COLUMN phone_or_email TEXT;').catch(() => {});
          await queryTurso(
            'UPDATE users SET username = ?, phone_or_email = ? WHERE id = ?;',
            [trimmedUser, trimmedContact, currentUser.id]
          );
        }

        try {
          await queryTurso(
            'UPDATE managers SET phone_or_email = ?, phone_number = ? WHERE id = ? OR user = ? OR username = ?;',
            [trimmedContact, trimmedContact, currentUser.id, currentUser.username, currentUser.username]
          ).catch(() => {});
        } catch {}
      }

      currentUser.username = trimmedUser;
      currentUser.phoneOrEmail = trimmedContact;
      setLocalSession(currentUser);

      // Update local cache
      const cachedMgrs = localStorage.getItem("local_managers_list");
      if (cachedMgrs) {
        try {
          const list = JSON.parse(cachedMgrs);
          const updated = list.map((m: any) =>
            m.id === currentUser.id || m.username === currentUser.username
              ? {
                  ...m,
                  username: trimmedUser,
                  phoneOrEmail: trimmedContact,
                  phoneNumber: trimmedContact,
                  ...(trimmedPass ? { plainPassword: trimmedPass } : {}),
                }
              : m
          );
          localStorage.setItem("local_managers_list", JSON.stringify(updated));
        } catch {}
      }

      // Refresh managers list on cloud so General Manager (Admin) sees the new phone/password immediately
      if (onRefreshManagers) {
        try {
          await onRefreshManagers();
        } catch {}
      }

      setIsEditingProfile(false);
      setEditPasswordInput('');
      setProfileMessage({ text: 'تم تحديث رقم الهاتف وكلمة المرور وتوثيقها لدى المدير العام بنجاح!', type: 'success' });
      if (onShowToast) {
        onShowToast('تم تحديث رقم الهاتف وكلمة المرور وتوثيقها لدى الإدارة بنجاح!', 'success');
      }
    } catch (err: any) {
      setProfileMessage({ text: err.message || 'فشل حفظ التعديلات في الخادم', type: 'error' });
    } finally {
      setIsSavingProfile(false);
    }
  };

  // Database Connection Test State (Only for Admin)
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionTestResult, setConnectionTestResult] = useState<{
    success: boolean;
    message: string;
    host?: string;
    responseTimeMs?: number;
  } | null>(null);

  const handleTestDatabaseConnection = async () => {
    setIsTestingConnection(true);
    setConnectionTestResult(null);
    try {
      const startTime = Date.now();
      await queryTurso("SELECT 1 as test_val;");
      const responseTime = Date.now() - startTime;
      setConnectionTestResult({
        success: true,
        message: t('settings.cloudConnectionSuccess', 'الاتصال بقاعدة البيانات السحابية ناجح ومستقر!'),
        host: 'Turso Cloud',
        responseTimeMs: responseTime,
      });
    } catch (err: any) {
      setConnectionTestResult({
        success: false,
        message: `${t('settings.cloudConnectionFailed', 'تعذر الاتصال بالسحابة')}: ${err?.message || ''}`,
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  useEffect(() => {
    setEnableAlerts(settings.enableDebtAlerts);
    setAlertDays(settings.alertDaysThreshold);
    setHighDebtThreshold(settings.highDebtThreshold);
  }, [settings]);

  const handleSaveAppSettings = (
    newEnableAlerts = enableAlerts,
    newDays = alertDays,
    newThreshold = highDebtThreshold
  ) => {
    const updated: AppSettings = {
      ...settings,
      language,
      currency,
      numberFormat,
      enableDebtAlerts: newEnableAlerts,
      alertDaysThreshold: Math.max(1, Number(newDays) || 1),
      highDebtThreshold: Math.max(0, Number(newThreshold) || 0),
    };
    onUpdateSettings(updated);
    setIsSettingsSaved(true);
    setTimeout(() => setIsSettingsSaved(false), 2500);
  };

  const dayPresets = [
    { label: t('settings.day1', 'يوم واحد (1)'), value: 1 },
    { label: t('settings.day2', 'يومان (2)'), value: 2 },
    { label: t('settings.day3', '3 أيام'), value: 3 },
    { label: t('settings.day7', '7 أيام'), value: 7 },
    { label: t('settings.day14', '14 يوماً'), value: 14 },
    { label: t('settings.day30', '30 يوماً'), value: 30 },
  ];

  const highDebtPresets = [
    { label: `10,000 ${getCurrencySymbol()}`, value: 10000 },
    { label: `25,000 ${getCurrencySymbol()}`, value: 25000 },
    { label: `50,000 ${getCurrencySymbol()}`, value: 50000 },
    { label: `100,000 ${getCurrencySymbol()}`, value: 100000 },
    { label: `250,000 ${getCurrencySymbol()}`, value: 250000 },
  ];

  return (
    <div id="tab-settings" className="pb-40 space-y-3 animate-in fade-in duration-150 text-start" dir={dir}>
      {/* Header - Sticky */}
      <div className="sticky top-0 z-30 bg-slate-50 px-4 safe-top pb-2.5 border-b border-slate-200 text-start gpu-layer">
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">{t('settings.title', 'الإعدادات')}</h1>
        <p className="text-xs font-medium text-slate-500 mt-0.5">
          {t('settings.subtitle', 'إدارة تنبيهات الديون، سقف المبالغ، الحساب، والفروع')}
        </p>
      </div>

      <div className="px-4 space-y-3">


        {/* ---------------------------------------------------- */}
        {/* 0. قائمة منسدلة: اللغة والعملة وتنسيق الأرقام */}
        {/* ---------------------------------------------------- */}
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('languageCurrency')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-language"></i>
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>{t('settings.languageAndCurrency', 'اللغة والعملة وتنسيق الأرقام')}</span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {language === 'ku' ? t('settings.kurdishShort', 'کوردی') : t('settings.arabicShort', 'العربية')} • {t('settings.currencyIQD', 'دينار عراقي')} • {numberFormat === 'arabic' ? '١٢٣' : '123'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-xl border bg-indigo-50 text-indigo-700 border-indigo-100">
                {language === 'ku' ? t('settings.kurdishShort', 'کوردی') : t('settings.arabicShort', 'العربية')} | {getCurrencySymbol()}
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.languageCurrency ? 'bg-indigo-50 text-indigo-600 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.languageCurrency && (
            <div className="p-5 pt-3 border-t border-slate-100 space-y-5 animate-in fade-in duration-200 text-start">
              {/* Language Selection */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <i className="fa-solid fa-globe text-indigo-600"></i>
                    <span>{t('settings.language', 'لغة التطبيق')}</span>
                  </label>
                  <span className="text-[11px] text-slate-400">{t('settings.languageDesc', 'اختر لغة الواجهة')}</span>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setLanguage('ar');
                      onUpdateSettings({ ...settings, language: 'ar' });
                    }}
                    className={`p-3.5 rounded-2xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                      language === 'ar'
                        ? 'bg-indigo-50/80 border-indigo-500 text-indigo-900 ring-2 ring-indigo-500/20 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-sm font-black">ع</span>
                    <span className="text-sm">العربية</span>
                    {language === 'ar' && (
                      <span className="text-[10px] text-indigo-600 font-semibold flex items-center gap-1">
                        <i className="fa-solid fa-circle-check text-[10px]"></i> {t('common.active', 'مفعل')}
                      </span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setLanguage('ku');
                      onUpdateSettings({ ...settings, language: 'ku' });
                    }}
                    className={`p-3.5 rounded-2xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                      language === 'ku'
                        ? 'bg-indigo-50/80 border-indigo-500 text-indigo-900 ring-2 ring-indigo-500/20 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center text-sm font-black">ک</span>
                    <span className="text-sm">کوردی</span>
                    {language === 'ku' && (
                      <span className="text-[10px] text-indigo-600 font-semibold flex items-center gap-1">
                        <i className="fa-solid fa-circle-check text-[10px]"></i> {t('common.active', 'چالاکە')}
                      </span>
                    )}
                  </button>
                </div>
              </div>

              {/* Currency Selection */}
              <div className="space-y-2 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <i className="fa-solid fa-coins text-amber-500"></i>
                    <span>{t('settings.currency', 'العملة المعتمدة')}</span>
                  </label>
                  <span className="text-[11px] text-slate-400">{t('settings.currencyDesc', 'العملة الافتراضية')}</span>
                </div>
                <div className="w-full">
                  <div className="p-3.5 rounded-2xl border bg-amber-50/80 border-amber-500 text-amber-900 ring-2 ring-amber-500/20 shadow-xs flex items-center justify-between">
                    <div className="flex items-center gap-2.5 text-start">
                      <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-xs">
                        {getCurrencySymbol()}
                      </div>
                      <div>
                        <div className="font-black text-slate-900 text-sm">{t('settings.currencyIQD', 'دينار عراقي')}</div>
                        <div className="text-[10px] text-slate-500">IQD • د.ع</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200/80 px-2.5 py-1 rounded-xl flex items-center gap-1.5">
                      <i className="fa-solid fa-circle-check text-emerald-600"></i>
                      <span>{t('common.active', 'مفعل')}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Number Format Selection */}
              <div className="space-y-2 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <i className="fa-solid fa-arrow-down-1-9 text-blue-500"></i>
                    <span>{t('settings.numberFormat', 'تنسيق كتابة الأرقام')}</span>
                  </label>
                  <span className="text-[11px] text-slate-400">{t('settings.numberFormatDesc', 'اختر صيغة ظهور الأرقام')}</span>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setNumberFormat('english');
                      onUpdateSettings({ ...settings, numberFormat: 'english' });
                    }}
                    className={`p-3 rounded-2xl border text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                      numberFormat === 'english'
                        ? 'bg-blue-50/80 border-blue-500 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="text-start">
                      <div className="font-bold text-slate-900">{t('settings.englishDigits', 'أرقام إنجليزية')}</div>
                      <div className="text-[11px] font-mono text-slate-500">123,456 • 2026/09/13</div>
                    </div>
                    {numberFormat === 'english' && (
                      <i className="fa-solid fa-circle-check text-blue-600"></i>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setNumberFormat('arabic');
                      onUpdateSettings({ ...settings, numberFormat: 'arabic' });
                    }}
                    className={`p-3 rounded-2xl border text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                      numberFormat === 'arabic'
                        ? 'bg-blue-50/80 border-blue-500 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="text-start">
                      <div className="font-bold text-slate-900">{t('settings.arabicDigits', 'أرقام عربية')}</div>
                      <div className="text-[11px] font-mono text-slate-500">١٢٣,٤٥٦ • ٢٠٢٦/٠٩/١٣</div>
                    </div>
                    {numberFormat === 'arabic' && (
                      <i className="fa-solid fa-circle-check text-blue-600"></i>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ---------------------------------------------------- */}
        {/* 1. قائمة منسدلة: الملف الشخصي والفرع */}
        {/* ---------------------------------------------------- */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
        <button
          type="button"
          onClick={() => toggleSection('profile')}
          className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
              <i className="fa-solid fa-store"></i>
            </div>
            <div className="truncate text-start">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <span>{t('settings.profileAndBranch', 'الملف الشخصي والفرع')}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  currentUser.role === 'trial' || currentUser.subscriptionType === 'trial'
                    ? 'bg-amber-50 text-amber-700 border-amber-200'
                    : 'bg-blue-50 text-blue-700 border-blue-100'
                }`}>
                  {getUserRoleDisplayName(currentUser, t)}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 truncate mt-0.5">
                {getUserBranchDisplayName(currentUser, t)} • {t('settings.userLabel', 'المستخدم')}: {getUserDisplayName(currentUser, t)}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {!isAdmin && (
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-xl border bg-slate-50 text-slate-700 border-slate-200 hidden sm:inline-block">
                {(currentUser.role === 'trial' || currentUser.subscriptionType === 'trial')
                  ? t('settings.trialBadgeShort', 'تجريبي ({count} مدينين)', { count: formatNumber(2, numberFormat) })
                  : currentUser.subscriptionType === 'permanent'
                  ? t('settings.permanentBadgeShort', 'دائم')
                  : t('settings.subscriptionDaysRemaining', 'متبقي {days} يوم', { days: formatNumber(getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt), numberFormat) })}
              </span>
            )}
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                openSections.profile ? 'bg-blue-50 text-blue-600 rotate-180' : 'bg-slate-100 text-slate-400'
              }`}
            >
              <i className="fa-solid fa-chevron-down text-xs"></i>
            </div>
          </div>
        </button>

        {openSections.profile && (
          <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
            {/* Account Details & Credentials Section */}
            <div className="bg-slate-50 border border-slate-200/70 rounded-2xl p-4 space-y-3">
              {/* Header */}
              <div className="flex items-center justify-between gap-2 border-b border-slate-200/60 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7.5 h-7.5 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold">
                    <i className="fa-solid fa-id-badge"></i>
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-800">
                      بيانات الحساب والاعتماد
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      تعديل رقم الهاتف وكلمة المرور الخاصة بالفرع
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="px-2.5 py-1 rounded-xl text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200/60">
                    {getUserBranchDisplayName(currentUser, t)}
                  </span>
                </div>
              </div>

              {/* Account Info Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200/60">
                  <span className="text-slate-500 font-medium flex items-center gap-1.5">
                    <i className="fa-solid fa-user text-blue-600 text-xs"></i>
                    <span>اسم المستخدم:</span>
                  </span>
                  <span className="font-mono font-bold text-slate-900">{getUserDisplayName(currentUser, t)}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200/60">
                  <span className="text-slate-500 font-medium flex items-center gap-1.5">
                    <i className="fa-solid fa-shield text-blue-600 text-xs"></i>
                    <span>نوع الصلاحية:</span>
                  </span>
                  <span className="font-bold text-blue-700">
                    {currentUser.role === 'admin'
                      ? t('settings.adminSystemRole', 'مدير عام للنظام')
                      : (currentUser.role === 'trial' || currentUser.subscriptionType === 'trial')
                      ? t('settings.trialLocalAccount', 'حساب تجريبي (محلي)')
                      : t('settings.branchManagerRole', 'مدير فرع فرعي')}
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-white rounded-xl border border-slate-200/60 sm:col-span-2 gap-2">
                  <span className="text-slate-500 font-medium flex items-center gap-1.5">
                    <i className="fa-solid fa-clock text-blue-600 text-xs"></i>
                    <span>تفاصيل الاشتراك:</span>
                  </span>
                  {isAdmin ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-bold text-xs border border-emerald-200/60 self-start sm:self-auto">
                      <i className="fa-solid fa-shield-check text-emerald-600 text-xs"></i>
                      <span>{t('settings.permanentMainAccount', 'دائم (حساب رئيسي)')}</span>
                    </span>
                  ) : (currentUser.role === 'trial' || currentUser.subscriptionType === 'trial') ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-50 text-amber-700 font-bold text-xs border border-amber-200/60">
                      <i className="fa-solid fa-flask text-amber-600 text-xs"></i>
                      <span>{t('settings.trialModeLimit', 'وضع تجريبي (حد 2 مدينين - حفظ محلي)')}</span>
                    </span>
                  ) : currentUser.subscriptionType === 'permanent' ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-bold text-xs border border-emerald-200/60 self-start sm:self-auto">
                      <i className="fa-solid fa-cloud-check text-emerald-600 text-xs"></i>
                      <span>حساب دائم (سحابي + محلي)</span>
                    </span>
                  ) : (
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-50 text-purple-700 font-bold text-xs border border-purple-200/60">
                        <i className="fa-solid fa-calendar-days text-purple-600 text-xs"></i>
                        <span>اشتراك شهري</span>
                      </span>
                      <span className="text-slate-600 font-semibold text-xs font-mono" dir="ltr">
                        ينتهي: {formatDateDigits(currentUser.subscriptionExpiresAt)}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Organized Credentials Form (Phone Number & Password) */}
              <form
                onSubmit={handleRequestSaveProfile}
                className="space-y-3 pt-2 border-t border-slate-200/60"
              >
                {/* Field 1: Phone Number */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <i className="fa-solid fa-phone text-blue-600"></i>
                      <span>رقم الهاتف <span className="text-red-500">*</span></span>
                    </span>
                    <span className="text-[10.5px] font-normal text-slate-500">
                      (الاعتماد الأول لتسجيل الدخول)
                    </span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={editPhoneOrEmail}
                      onChange={(e) => setEditPhoneOrEmail(e.target.value)}
                      placeholder="أدخل رقم الهاتف..."
                      className="w-full bg-white border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-xs font-bold px-3 py-2.5 rounded-xl outline-none text-slate-900 text-start font-mono"
                      dir="ltr"
                      required
                    />
                  </div>
                </div>

                {/* Field 2: Password (directly under Phone Number) */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <i className="fa-solid fa-key text-blue-600"></i>
                      <span>كلمة المرور</span>
                    </span>
                    <span className="text-[10.5px] font-normal text-slate-500">
                      (اتركها كما هي أو أدخل كلمة جديدة)
                    </span>
                  </label>
                  <div className="relative flex items-center">
                    <input
                      type={showUserPassword ? "text" : "password"}
                      value={editPasswordInput || userPassword}
                      onChange={(e) => setEditPasswordInput(e.target.value)}
                      placeholder="كلمة المرور..."
                      className="w-full bg-white border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-xs font-mono font-bold px-3 py-2.5 pl-20 rounded-xl outline-none text-slate-900"
                      dir="ltr"
                    />
                    <div className="absolute left-2 flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setShowUserPassword(!showUserPassword)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 text-xs cursor-pointer"
                        title={showUserPassword ? "إخفاء" : "إظهار"}
                      >
                        <i className={`fa-solid ${showUserPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                      </button>
                      <button
                        type="button"
                        onClick={handleCopyPassword}
                        className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 text-xs cursor-pointer"
                        title="نسخ كلمة المرور"
                      >
                        <i className={`fa-solid ${copiedPassword ? 'fa-check text-emerald-600' : 'fa-copy'}`}></i>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Action Save Button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSavingProfile}
                    className="w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white py-2.5 px-4 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isSavingProfile ? (
                      <i className="fa-solid fa-spinner fa-spin text-sm"></i>
                    ) : (
                      <i className="fa-solid fa-floppy-disk text-sm"></i>
                    )}
                    <span>حفظ وتحديث بيانات الحساب</span>
                  </button>
                </div>
              </form>

              {profileMessage && (
                <div
                  className={`text-xs font-bold p-3 rounded-xl flex items-center gap-2 ${
                    profileMessage.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  <i className={`fa-solid ${profileMessage.type === 'success' ? 'fa-circle-check text-emerald-600' : 'fa-circle-exclamation text-rose-600'}`}></i>
                  <span>{profileMessage.text}</span>
                </div>
              )}
            </div>

              {/* Trial Upgrade Banner inside Profile if Trial */}
              {(currentUser.role === 'trial' || currentUser.subscriptionType === 'trial') && (
                <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-bold text-xs">
                      <i className="fa-solid fa-lock text-amber-600"></i>
                      <span>{t('settings.trialNoticeTitle', 'أنت تستخدم النسخة التجريبية')}</span>
                    </div>
                    <span className="text-[10px] bg-amber-200/70 text-amber-800 font-bold px-2 py-0.5 rounded-md">
                      {t('settings.trialLocalOnly', 'تخزين محلي فقط')}
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed">
                    {t('settings.trialNoticeDesc', 'يسمح لك الوضع التجريبي بتسجيل حتى (2) مدينين فقط. للاشتراك في النسخة الكاملة بدون حدود مع التخزين السحابي:')}
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      const msg = encodeURIComponent("السلام عليكم، أود تفعيل النسخة الكاملة من تطبيق دفتر الديون لفتح عدد غير محدود من المدينين والمزامنة السحابية.");
                      window.open(`https://wa.me/9647810936407?text=${msg}`, '_blank');
                    }}
                    className="w-full py-2.5 px-3 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <i className="fa-brands fa-whatsapp text-sm"></i>
                    <span>{t('settings.contactAdminUpgrade', 'مراسلة الإدارة للاشتراك في النسخة الكاملة')}</span>
                  </button>
                </div>
              )}

              {!isAdmin && currentUser.subscriptionType === 'monthly' && (
                <div
                  className={`p-3 rounded-xl text-xs font-bold border flex items-center justify-between gap-2 ${
                    isSubscriptionExpired('monthly', currentUser.subscriptionExpiresAt)
                      ? 'bg-rose-50 text-rose-800 border-rose-200'
                      : getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) <= 3
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : 'bg-purple-50 text-purple-800 border-purple-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <i className="fa-solid fa-clock-rotate-left"></i>
                    <span>{t('settings.subscriptionExpiryDate', 'تاريخ انتهاء الصلاحية')}: {formatDateDigits(formatDateArabic(currentUser.subscriptionExpiresAt), numberFormat)}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-white/80 border border-current">
                    {isSubscriptionExpired('monthly', currentUser.subscriptionExpiresAt)
                      ? t('settings.subscriptionExpired', 'منتهي')
                      : t('settings.subscriptionDaysRemaining', 'متبقي {days} يوم', { days: formatNumber(getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt), numberFormat) })}
                  </span>
                </div>
              )}

              {/* Logout Action */}
              <button
                type="button"
                onClick={onLogout}
                className="w-full bg-rose-50 hover:bg-rose-100 text-rose-600 py-3 rounded-2xl font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer border border-rose-200/80"
              >
                <i className="fa-solid fa-arrow-right-from-bracket"></i>
                <span>{t('settings.logoutAccount', 'تسجيل الخروج من الحساب')}</span>
              </button>
            </div>
          )}
        </div>

      {/* ---------------------------------------------------- */}
      {/* 2 & 3. إعدادات الديون: تنبيهات مدة الدين وسقف الدين المرتفع (تخفى في حال كان المدير مخصصاً للأقساط فقط) */}
      {/* ---------------------------------------------------- */}
      {currentUser.allowedModules !== 'installments' && (
        <>
          {/* 2. قائمة منسدلة: نظام تنبيهات مدة الدين */}
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
            <button
              type="button"
              onClick={() => toggleSection('alerts')}
              className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                  <i className="fa-solid fa-bell"></i>
                </div>
                <div className="truncate text-start">
                  <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <span>{t('settings.alertsSystem', 'نظام تنبيهات مدة الدين')}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        enableAlerts
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : 'bg-slate-100 text-slate-500 border-slate-200'
                      }`}
                    >
                      {enableAlerts ? t('settings.enabled', 'مفعل') : t('settings.disabled', 'معطل')}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    {t('settings.alertsTagDesc', 'إظهار وسم «متأخر عن دفع» بعد تجاوز المدة المحددة')}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {enableAlerts && (
                  <span className="text-[11px] font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-xl border border-rose-100 hidden sm:inline-block">
                    {formatNumber(alertDays, numberFormat)} {alertDays === 1 ? t('settings.day', 'يوم') : t('settings.days', 'أيام')}
                  </span>
                )}
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                    openSections.alerts ? 'bg-rose-50 text-rose-600 rotate-180' : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  <i className="fa-solid fa-chevron-down text-xs"></i>
                </div>
              </div>
            </button>

            {openSections.alerts && (
              <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
                {/* Toggle Row */}
                <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200/60">
                  <div>
                    <div className="font-bold text-xs text-slate-900">{t('settings.enableAlertsLabel', 'تفعيل تنبيهات التأخر في السداد')}</div>
                    <div className="text-[11px] text-slate-500">{t('settings.enableAlertsSub', 'إظهار شارة باللون الأحمر للزبائن المتأخرين')}</div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    <input
                      type="checkbox"
                      id="toggleDebtAlerts"
                      checked={enableAlerts}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setEnableAlerts(checked);
                        handleSaveAppSettings(checked, alertDays, highDebtThreshold);
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
                  </label>
                </div>

                {enableAlerts && (
                  <div className="space-y-3 pt-1">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-bold text-slate-700">
                        {t('settings.alertDurationLabel', 'مدة اعتبار الزبون متأخراً (بالأيام):')}
                      </label>
                      <span className="text-xs font-extrabold text-rose-600 font-mono bg-rose-50 px-2.5 py-0.5 rounded-lg border border-rose-100">
                        {formatNumber(alertDays, numberFormat)} {alertDays === 1 ? t('settings.oneDay', 'يوم واحد') : alertDays === 2 ? t('settings.twoDays', 'يومان') : t('settings.days', 'أيام')}
                      </span>
                    </div>

                    {/* Day Presets */}
                    <div className="flex flex-wrap gap-1.5">
                      {dayPresets.map((preset) => (
                        <button
                          key={preset.value}
                          type="button"
                          onClick={() => {
                            setAlertDays(preset.value);
                            handleSaveAppSettings(enableAlerts, preset.value, highDebtThreshold);
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            alertDays === preset.value
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>

                    {/* Custom Input */}
                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-xs text-slate-500 font-medium shrink-0">{t('settings.orCustomDays', 'أو حدد أياماً مخصصة:')}</span>
                      <input
                        type="number"
                        min="1"
                        max="365"
                        value={alertDays}
                        onChange={(e) => {
                          const val = Math.max(1, parseInt(e.target.value) || 1);
                          setAlertDays(val);
                        }}
                        className="w-24 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-center outline-none focus:border-rose-600"
                      />
                      <span className="text-xs text-slate-400">{t('settings.day', 'يوماً')}</span>
                    </div>

                    {/* Impact Info */}
                    <div className="bg-rose-50/70 border border-rose-100 rounded-2xl p-3 flex items-center gap-2 text-xs text-rose-900">
                      <i className="fa-solid fa-triangle-exclamation text-rose-600 text-sm shrink-0"></i>
                      <div>
                        {t('settings.overdueBadgeNote', 'تظهر عبارة (متأخر عن دفع) حالياً على {count} مدين', { count: formatNumber(alertTriggeredCount, numberFormat) })}
                      </div>
                    </div>

                    {/* Save Button */}
                    <button
                      type="button"
                      onClick={() => handleSaveAppSettings()}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    >
                      {isSettingsSaved ? (
                        <>
                          <i className="fa-solid fa-check text-emerald-400"></i>
                          <span>{t('settings.alertsSavedSuccess', 'تم حفظ التنبيهات بنجاح!')}</span>
                        </>
                      ) : (
                        <span>{t('settings.saveAlertsBtn', 'تطبيق وحفظ إعدادات التنبيهات')}</span>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* 3. قائمة منسدلة: سقف وقيمة الدين المرتفع */}
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
            <button
              type="button"
              onClick={() => toggleSection('highDebt')}
              className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                  <i className="fa-solid fa-arrow-trend-up"></i>
                </div>
                <div className="truncate text-start">
                  <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <span>{t('settings.highDebtSystem', 'سقف وقيمة الدين المرتفع')}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                      {t('settings.highDebtSmartClass', 'تصنيف ذكي')}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    {t('settings.highDebtBadgeDesc', 'تمييز الزبائن ذوي الديون المرتفعة بشارة خاصة')}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] font-mono font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-xl border border-amber-200 hidden sm:inline-block">
                  {formatNumber(highDebtThreshold, numberFormat)} {getCurrencySymbol()}
                </span>
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                    openSections.highDebt ? 'bg-amber-50 text-amber-600 rotate-180' : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  <i className="fa-solid fa-chevron-down text-xs"></i>
                </div>
              </div>
            </button>

            {openSections.highDebt && (
              <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="text-xs font-bold text-slate-700">
                      {t('settings.highDebtMinLabel', 'الحد الأدنى لاعتبار الدين مرتفعاً (د.ع):')}
                    </label>
                    <span className="text-xs font-extrabold text-amber-800 font-mono bg-amber-50 px-2.5 py-0.5 rounded-lg border border-amber-200">
                      {formatNumber(highDebtThreshold, numberFormat)} {getCurrencySymbol()}
                    </span>
                  </div>

                  {/* Presets */}
                  <div className="flex flex-wrap gap-1.5 mb-2.5">
                    {highDebtPresets.map((preset) => (
                      <button
                        key={preset.value}
                        type="button"
                        onClick={() => {
                          setHighDebtThreshold(preset.value);
                          handleSaveAppSettings(enableAlerts, alertDays, preset.value);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          highDebtThreshold === preset.value
                            ? 'bg-amber-600 text-white shadow-xs'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        {formatNumber(preset.value, numberFormat)} {getCurrencySymbol()}
                      </button>
                    ))}
                  </div>

                  {/* Custom Input */}
                  <div className="relative">
                    <input
                      type="number"
                      step="1000"
                      min="0"
                      value={highDebtThreshold}
                      onChange={(e) => {
                        const val = Math.max(0, parseFloat(e.target.value) || 0);
                        setHighDebtThreshold(val);
                      }}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono outline-none focus:border-amber-600"
                      placeholder={t('settings.enterCustomThreshold', 'أدخل مبلغ السقف المخصص')}
                    />
                    <span className="absolute end-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold pointer-events-none">
                      {getCurrencySymbol()}
                    </span>
                  </div>
                </div>

                {/* Impact info */}
                <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-3 flex items-center gap-2 text-xs text-amber-900">
                  <i className="fa-solid fa-circle-info text-amber-600 text-sm shrink-0"></i>
                  <div>
                    {t('settings.highDebtorsStatNote', 'يوجد حالياً {count} مدين من أصل {total} يصنف دينهم كـ مرتفع (أكبر من أو يساوي {limit}).', {
                      count: formatNumber(highDebtorsCount, numberFormat),
                      total: formatNumber(totalDebtorsCount, numberFormat),
                      limit: `${formatNumber(highDebtThreshold, numberFormat)} ${getCurrencySymbol()}`
                    })}
                  </div>
                </div>

                {/* Save Button */}
                <button
                  type="button"
                  onClick={() => handleSaveAppSettings()}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  {isSettingsSaved ? (
                    <>
                      <i className="fa-solid fa-check text-emerald-400"></i>
                      <span>{t('settings.highDebtSavedSuccess', 'تم حفظ سقف الدين بنجاح!')}</span>
                    </>
                  ) : (
                    <span>{t('settings.saveHighDebtBtn', 'تطبيق وحفظ سقف الدين المرتفع')}</span>
                  )}
                </button>
              </div>
            )}
          </div>
        </>
      )}

      {/* ---------------------------------------------------- */}
      {/* 4. قائمة منسدلة: أداة نقل وترحيل قاعدة البيانات (خاص بالمدير العام فقط) */}
      {/* ---------------------------------------------------- */}
      {isAdmin && onShowToast && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('migration')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-700 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs border border-indigo-100">
                <i className="fa-solid fa-server"></i>
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>{t('settings.databaseMigrationTitle', 'أداة نقل وترحيل قاعدة البيانات')}</span>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                    {t('settings.fullMigrationBadge', 'ترحيل شامل')}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {t('settings.databaseMigrationSubtitle', 'رفع ملف النسخ (JSON) واستبدال أو دمج القاعدة بالكامل مع نقل كافة المدراء والبيانات')}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-xl border border-indigo-100 hidden sm:inline-block">
                قاعدة قديمة ➔ جديدة
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.migration ? 'bg-indigo-50 text-indigo-700 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.migration && (
            <div className="p-5 pt-3 border-t border-slate-100 animate-in fade-in duration-200">
              <DatabaseMigrationSection
                currentUser={currentUser}
                debtors={allDebtors}
                installments={installments}
                managers={managers}
                settings={settings}
                onShowToast={onShowToast}
                onMigrationSuccess={onFullMigrationSuccess || onRefreshManagers}
              />
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 5. قائمة منسدلة: النسخ الاحتياطي واسترجاع البيانات (المدير العام والمدراء الفرعيين) */}
      {/* ---------------------------------------------------- */}
      {(onImportBackup || onImportDebtors) && onShowToast && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('backup')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-lg font-bold shrink-0 shadow-xs ${
                isAdmin ? 'bg-cyan-50 text-cyan-600' : 'bg-emerald-50 text-emerald-600'
              }`}>
                <i className="fa-solid fa-cloud-arrow-down"></i>
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>
                    {isAdmin
                      ? t('settings.backupAndImport', 'النسخ الاحتياطي الشامل بالنظام')
                      : 'النسخ الاحتياطي المحلي واسترجاع البيانات'}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isAdmin
                      ? 'bg-purple-100 text-purple-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {isAdmin
                      ? t('settings.adminOnlyBadge', 'المدير العام فقط')
                      : 'خاص بالفرع'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {isAdmin
                    ? 'تصدير واسترجاع ملف شامل لجميع بيانات المدراء والفروع، والمدينين، وعقود الأقساط'
                    : 'تصدير نسخة احتياطية محلية (JSON) لسجلات مديني الفرع وعقود الأقساط واسترجاعها بأمان'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-xl border border-slate-200 hidden sm:inline-block">
                {isAdmin
                  ? `${formatNumber(managers.length, numberFormat)} ${t('settings.branchUnit', 'فرع')} • ${formatNumber(allDebtors.length, numberFormat)} ${t('settings.debtorUnit', 'مدين')} • ${formatNumber(installments.length, numberFormat)} ${t('settings.installmentUnit', 'قسط')}`
                  : `${formatNumber(allDebtors.length, numberFormat)} ${t('settings.debtorUnit', 'مدين')} • ${formatNumber(installments.length, numberFormat)} ${t('settings.installmentUnit', 'قسط')}`}
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.backup
                    ? isAdmin
                      ? 'bg-cyan-50 text-cyan-600 rotate-180'
                      : 'bg-emerald-50 text-emerald-600 rotate-180'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.backup && (
            <div className="p-5 pt-3 border-t border-slate-100 animate-in fade-in duration-200">
              <BackupRestoreSection
                currentUser={currentUser}
                debtors={allDebtors}
                installments={installments}
                managers={managers}
                settings={settings}
                onImportBackup={onImportBackup}
                onImportDebtors={onImportDebtors}
                onShowToast={onShowToast}
                flat={true}
              />
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 5. قائمة منسدلة: إدارة الفروع والمدراء (خاص بالمدير العام) */}
      {/* ---------------------------------------------------- */}
      {isAdmin && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('managers')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-users-gear"></i>
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>{t('settings.managersManagement', 'إدارة الفروع والمدراء')}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">
                    {t('settings.adminOnlyBadge', 'المدير العام فقط')}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {t('settings.managersSubtitle', 'إنشاء فروع جديدة، تحديد نوع الاشتراك (شهري / دائم)، وتجديده')}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-xl border border-purple-100 hidden sm:inline-block">
                {formatNumber(managers.length, numberFormat)} {t('settings.branchUnit', 'فرع')}
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.managers ? 'bg-purple-50 text-purple-600 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.managers && (
            <div className="p-5 pt-3 border-t border-slate-100 animate-in fade-in duration-200">
              <ManagersTab
                managers={managers}
                databases={databases}
                onCreateManager={onCreateManager}
                onToggleManagerStatus={onToggleManagerStatus}
                onRenewSubscription={onRenewSubscription}
                onChangeSubscriptionType={onChangeSubscriptionType}
                onChangeManagerModules={onChangeManagerModules}
                onChangeManagerDatabase={onChangeManagerDatabase}
                onChangeManagerTheme={onChangeManagerTheme}
                onDeleteManager={onDeleteManager}
                onUpdateManagerPassword={onUpdateManagerPassword}
                onUpgradeNewRegistration={onUpgradeNewRegistration}
                onRefreshManagers={onRefreshManagers}
                isLoading={isManagersLoading}
              />
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 6. قائمة منسدلة: قاعدة البيانات السحابية وفحص الاتصال (خاص بالمدير العام) */}
      {/* ---------------------------------------------------- */}
      {isAdmin && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('database')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-database"></i>
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>{t('settings.cloudDbTitle', 'قاعدة البيانات السحابية (Turso)')}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                    {t('settings.adminBadge', 'المدير العام')}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {t('settings.cloudDbSubtitle', 'فحص الاتصال والتحقق من الربط مع خادم aldion.ts')}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-xl border border-slate-200 hidden sm:inline-block">
                aldion.ts
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.database ? 'bg-slate-100 text-slate-900 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.database && (
            <div className="p-5 pt-3 border-t border-slate-100 animate-in fade-in duration-200">
              <DatabaseAccountsSection
                databases={databases}
                onRefreshDatabases={onRefreshDatabases || (() => {})}
                onShowToast={onShowToast}
              />
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 7. قائمة منسدلة: البيانات التجريبية للاختبار (خاص بالمدير العام) */}
      {/* ---------------------------------------------------- */}
      {isAdmin && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('demo')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-flask-vial"></i>
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>{t('settings.demoTitle', 'البيانات التجريبية للاختبار')}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                    {t('settings.adminBadge', 'المدير العام')}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {t('settings.demoSubtitle', 'توليد بيانات تجريبية للديون والأقساط محلياً لاختبار الأداء')}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {(demoDebtorsCount > 0 || demoInstallmentsCount > 0) ? (
                <span className="text-[11px] font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-xl border border-indigo-200">
                  {formatNumber(demoDebtorsCount + demoInstallmentsCount, numberFormat)} {t('settings.demoUnit', 'تجريبي')}
                </span>
              ) : (
                <span className="text-[11px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-xl border border-slate-200 hidden sm:inline-block">
                  {t('settings.demoNotActive', 'غير مفعل')}
                </span>
              )}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.demo ? 'bg-indigo-50 text-indigo-600 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.demo && (
            <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
              {/* Demo Installments Card (20 أقساط بمجموع 17 مليون) */}
              {onAddDemoInstallments && onClearDemoInstallments && (
                <div className="bg-emerald-50/50 border border-emerald-100/90 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs">
                        <i className="fa-solid fa-file-invoice-dollar"></i>
                      </div>
                      <span className="font-bold text-xs text-emerald-950">بيانات الأقساط التجريبية (20 عقد قسط)</span>
                    </div>
                    <span className="font-mono text-[11px] font-bold px-2 py-0.5 rounded-lg bg-emerald-100/80 text-emerald-800">
                      المتبقي: 17,000,000 د.ع
                    </span>
                  </div>

                  <p className="text-[11px] text-emerald-900/80 leading-relaxed">
                    إضافة 20 عقد قسط متنوع السلع (أجهزة كهربائية، موبايلات، أثاث) بمتبقي إجمالي قدره 17 مليون دينار عراقي مع حالات استحقاق متباينة لاختبار نظام الأقساط.
                  </p>

                  <div className="pt-1">
                    {demoInstallmentsCount === 0 ? (
                      <button
                        type="button"
                        onClick={onAddDemoInstallments}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                      >
                        <i className="fa-solid fa-plus text-xs"></i>
                        <span>إضافة 20 قسط تجريبي (المتبقي 17 مليون)</span>
                      </button>
                    ) : (
                      <div className="space-y-1.5">
                        <button
                          type="button"
                          onClick={onClearDemoInstallments}
                          className="w-full bg-rose-600 hover:bg-rose-700 active:scale-[0.99] text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                        >
                          <i className="fa-solid fa-trash-can text-xs"></i>
                          <span>حذف الأقساط التجريبية ({formatNumber(demoInstallmentsCount, numberFormat)} قسط)</span>
                        </button>
                        <p className="text-center text-[10px] text-slate-400">
                          سيتم حذف عقود الأقساط التجريبية فقط، وتظل بيانات الأقساط الحقيقية محفوظة.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Demo Debtors Card (100 مدين) */}
              {onAddDemoDebtors && onClearDemoDebtors && (
                <div className="bg-indigo-50/50 border border-indigo-100/90 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-xs">
                        <i className="fa-solid fa-users"></i>
                      </div>
                      <span className="font-bold text-xs text-indigo-950">{t('settings.demoTitle', 'بيانات الديون التجريبية (100 مدين)')}</span>
                    </div>
                    <span className="font-mono text-[11px] font-bold px-2 py-0.5 rounded-lg bg-indigo-100/80 text-indigo-800">
                      077********
                    </span>
                  </div>

                  <p className="text-[11px] text-indigo-900/80 leading-relaxed">
                    {t('settings.demoDesc', 'توليد 100 مدين بأسماء واقعية، وأرقام هواتف تبدأ بـ 077، ومبالغ ديون وتواريخ متباينة لاختبار سرعة البحث وتنبيهات المتأخرين.')}
                  </p>

                    <div className="pt-1">
                    {demoDebtorsCount === 0 ? (
                      <div className="space-y-2">
                        {onAddBillionDemoDebtors && (
                          <button
                            type="button"
                            onClick={onAddBillionDemoDebtors}
                            className="w-full bg-gradient-to-r from-amber-500 via-orange-600 to-rose-600 hover:from-amber-600 hover:to-rose-700 active:scale-[0.99] text-white py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2.5 cursor-pointer shadow-md border border-amber-300/40 relative overflow-hidden"
                          >
                            <div className="w-6 h-6 rounded-lg bg-white/20 flex items-center justify-center text-xs">
                              <i className="fa-solid fa-gauge-high text-yellow-200"></i>
                            </div>
                            <span className="text-sm">⚡ تفعيل محاكي المليار عميل الافتراضي (1,000,000,000)</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={onAddDemoDebtors}
                          className="w-full bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                        >
                          <i className="fa-solid fa-users-viewfinder text-xs"></i>
                          <span>{t('settings.addDemoDebtorsBtn', 'إضافة 100 مدين تجريبي للاختبار')}</span>
                        </button>

                        {onAddMillionDemoDebtors && (
                          <button
                            type="button"
                            onClick={onAddMillionDemoDebtors}
                            className="w-full bg-gradient-to-r from-violet-700 to-indigo-800 hover:from-violet-800 hover:to-indigo-900 active:scale-[0.99] text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs border border-violet-400/30"
                          >
                            <i className="fa-solid fa-bolt text-amber-300 text-xs"></i>
                            <span>إضافة 10,000 عميل تجريبي (لاختبار السرعة محلياً)</span>
                          </button>
                        )}
                        <p className="text-[10.5px] text-indigo-900/70 text-center">
                          * المحاكي الافتراضي يعمل بتقنية المعالجة الرياضية الفورية بذاكرة 0 بايت وبسرعة فائقة (60 FPS).
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {isBillionDemoActive && (
                          <div className="p-3 bg-amber-500/10 border border-amber-300 rounded-xl flex items-center justify-between text-xs text-amber-900 font-bold">
                            <span className="flex items-center gap-2">
                              <i className="fa-solid fa-bolt text-amber-600"></i>
                              <span>محاكي المليار عميل نشط حالياً</span>
                            </span>
                            <span className="font-mono bg-amber-200/80 px-2 py-0.5 rounded-lg text-[11px]">
                              1,000,000,000 عميل
                            </span>
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={onClearDemoDebtors}
                          className="w-full bg-rose-600 hover:bg-rose-700 active:scale-[0.99] text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                        >
                          <i className="fa-solid fa-trash-can text-xs"></i>
                          <span>{t('settings.clearDemoDebtorsBtn', 'حذف كافة المدينين التجريبيين ({count} مدين)', { count: formatNumber(demoDebtorsCount, numberFormat) })}</span>
                        </button>
                        <p className="text-center text-[10px] text-slate-400">
                          {t('settings.clearDemoNote', 'سيتم حذف السجلات التجريبية الـ {count} فقط، وتبقى سجلاتك الحقيقية سليمة ومحفوظة.', { count: formatNumber(demoDebtorsCount, numberFormat) })}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
      {/* Confirmation Modal for Profile Update */}
      <ConfirmModal
        isOpen={showProfileConfirmModal}
        title="تأكيد تحديث بيانات الحساب"
        message="هل أنت متأكد من حفظ وتغيير رقم الهاتف أو كلمة المرور الخاصة بحسابك؟ سيتطلب ذلك استخدام البيانات الجديدة للدخول، وستنعكس التغييرات فورياً لدى المدير العام والإدارة."
        confirmText="نعم، تأكيد وتحديث"
        cancelText="إلغاء"
        onConfirm={executeSaveProfile}
        onCancel={() => setShowProfileConfirmModal(false)}
        isLoading={isSavingProfile}
      />
      </div>
    </div>
  );
});

SettingsTab.displayName = 'SettingsTab';
