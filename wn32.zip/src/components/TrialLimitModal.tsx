import React from 'react';
import { motion } from 'motion/react';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';

interface TrialLimitModalProps {
  isOpen: boolean;
  onClose: () => void;
  debtorsCount?: number;
  mode?: 'debts' | 'installments';
}

export const TrialLimitModal: React.FC<TrialLimitModalProps> = ({
  isOpen,
  onClose,
  debtorsCount = 2,
  mode = 'debts',
}) => {
  const { t, numberFormat, dir } = useI18n();
  if (!isOpen) return null;

  const isInstallments = mode === 'installments';

  const handleContactAdmin = () => {
    // Open WhatsApp to contact administration
    const messageText = isInstallments
      ? "السلام عليكم، أود تفعيل النسخة الكاملة من نظام الأقساط ودفتر الديون لفتح عدد غير محدود من أصحاب الأقساط والمدينين والمزامنة السحابية."
      : "السلام عليكم، أود تفعيل النسخة الكاملة من تطبيق دفتر الديون لفتح عدد غير محدود من المدينين والمزامنة السحابية.";
    const message = encodeURIComponent(messageText);
    window.open(`https://wa.me/9647810936407?text=${message}`, '_blank');
  };

  const formattedLimitNum = formatNumber(2, numberFormat);

  return (
    <div
      id="trialLimitModalOverlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md bg-white rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-100 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Amber Ambient Ribbon */}
        <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-amber-400 via-orange-500 to-amber-500" />

        {/* Icon Header */}
        <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto mb-4 text-2xl shadow-xs">
          <i className="fa-solid fa-lock text-amber-500"></i>
        </div>

        {/* Title */}
        <h3 className="text-xl font-bold text-slate-900 text-center mb-1">
          {t('modals.trialLimitTitle', 'تنبيه النسخة التجريبية')}
        </h3>

        {/* Subtitle / Limit Notice */}
        <p className="text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200/80 rounded-xl py-2 px-3 text-center mb-4">
          {isInstallments
            ? t('modals.trialLimitInstallmentsMessage', `تم الوصول للحد الأقصى للنسخة التجريبية (${formattedLimitNum} من أصحاب الأقساط فقط)`)
            : t('modals.trialLimitDebtsMessage', `تم الوصول للحد الأقصى للنسخة التجريبية (${formattedLimitNum} مدينين فقط)`)}
        </p>

        {/* Body Description */}
        <div className="text-xs text-slate-600 space-y-2.5 leading-relaxed mb-6 bg-slate-50/80 rounded-2xl p-4 border border-slate-100">
          <p className="font-semibold text-slate-800">
            {t('modals.trialBenefitsHeader', 'يرجى الاشتراك في النسخة الكاملة من خلال مراسلة الإدارة للاستفادة من:')}
          </p>
          <ul className="space-y-1.5 px-1">
            <li className="flex items-center gap-2 text-slate-700">
              <i className="fa-solid fa-circle-check text-emerald-500 text-xs shrink-0"></i>
              <span>{isInstallments ? t('modals.trialBenefit1Installments', 'تسجيل عدد غير محدود من أصحاب الأقساط والعمليات') : t('modals.trialBenefit1Debts', 'تسجيل عدد غير محدود من المدينين والعمليات')}</span>
            </li>
            <li className="flex items-center gap-2 text-slate-700">
              <i className="fa-solid fa-circle-check text-emerald-500 text-xs shrink-0"></i>
              <span>{t('modals.trialBenefit2', 'مزامنة سحابية مشفرة وفورية لحماية بياناتك')}</span>
            </li>
            <li className="flex items-center gap-2 text-slate-700">
              <i className="fa-solid fa-circle-check text-emerald-500 text-xs shrink-0"></i>
              <span>{t('modals.trialBenefit3', 'نسخ احتياطي واسترجاع متقدم وكشوفات حساب مفصلة')}</span>
            </li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            id="btnContactAdminFromTrial"
            onClick={handleContactAdmin}
            className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-lg shadow-emerald-500/25 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className="fa-brands fa-whatsapp text-lg"></i>
            <span>{t('modals.upgradeToFullVersion', 'مراسلة الإدارة للاشتراك في النسخة الكاملة')}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl font-medium text-xs text-slate-500 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            {t('modals.continueTrial', 'إغلاق ومتابعة التجربة')}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

