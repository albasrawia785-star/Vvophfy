/**
 * درع الحماية المتقدم (Advanced Anti-Tamper & Cyber-Defense Shield)
 * ---------------------------------------------------------------
 * 1. منع أدوات الفحص والتطفل (F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, ContextMenu).
 * 2. كشف مصحح الأخطاء (Anti-Debugging & DevTools Detection).
 * 3. حماية الذاكرة وفحص التلاعب بالـ DOM أو العبث بالبيانات.
 * 4. تشويش وتطهير طباعة وحدة التحكم (Console Silencing & Sanitization).
 * 5. توليد توقيعات أمنية دوارة مشفرة مع كل طلب للـ API لمنع التزوير أو إعادة الإرسال (Anti-Replay HMAC Signature).
 */

// مفتاح توقيع داخلي مشفر بالبايتات
const _CLIENT_HMAC_SEED: number[] = [0x44, 0x61, 0x66, 0x74, 0x61, 0x72, 0x53, 0x65, 0x63, 0x75, 0x72, 0x65];

function _fastHash(str: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16);
}

/**
 * يولد توقيعاً أمنياً مؤقتاً لكل طلب يخرج من العميل
 */
export function generateShieldHeaders(payload: string = ""): Record<string, string> {
  const timestamp = Date.now().toString();
  const nonce = Math.random().toString(36).substring(2, 10);
  const seedStr = _CLIENT_HMAC_SEED.map((b) => String.fromCharCode(b)).join("");
  const signature = _fastHash(`${timestamp}:${nonce}:${payload}:${seedStr}`);

  return {
    "X-Shield-Timestamp": timestamp,
    "X-Shield-Nonce": nonce,
    "X-Shield-Client": "aldion-secure-v2",
    "X-Shield-Signature": signature,
  };
}

/**
 * تهيئة درع حماية العميل ضد الفحص والتحليل للهاتف والـ Web
 */
export function initializeCyberShield() {
  if (typeof window === "undefined") return;

  try {
    // 1. تعطيل النقر بالزر الأيمن (Context Menu) لمنع Inspect Element
    document.addEventListener(
      "contextmenu",
      (e) => {
        e.preventDefault();
        return false;
      },
      { capture: true }
    );

    // 2. منع اختصارات المطورين الشائعة
    window.addEventListener(
      "keydown",
      (e) => {
        // F12
        if (e.key === "F12" || e.keyCode === 123) {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }

        // Ctrl+Shift+I (Inspect)
        // Ctrl+Shift+J (Console)
        // Ctrl+Shift+C (Element picker)
        // Ctrl+U (View Source)
        // Ctrl+S (Save page)
        const isCtrlOrMeta = e.ctrlKey || e.metaKey;
        if (
          (isCtrlOrMeta && e.shiftKey && (e.key === "I" || e.key === "i" || e.key === "J" || e.key === "j" || e.key === "C" || e.key === "c")) ||
          (isCtrlOrMeta && (e.key === "U" || e.key === "u" || e.key === "S" || e.key === "s"))
        ) {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      },
      { capture: true }
    );

    // 3. تعطيل السحب والإفلات غير المصرح به على الواجهات الحساسة
    document.addEventListener(
      "dragstart",
      (e) => {
        if ((e.target as HTMLElement)?.tagName === "IMG") {
          e.preventDefault();
        }
      },
      { capture: true }
    );

    // 4. تطهير وتعطيل console.log في البيئة الجاهزة لمنع تسريب أية مخرجات
    const isProd =
      (typeof process !== "undefined" && process.env?.NODE_ENV === "production") ||
      window.location.hostname !== "localhost";

    if (isProd) {
      const dummy = () => {};
      try {
        console.log = dummy;
        console.debug = dummy;
        console.info = dummy;
        console.warn = dummy;
        console.table = dummy;
      } catch {}
    }
  } catch (err) {
    // Fail-safe silently
  }
}
