import { User } from '../types';

/**
 * Returns a dynamically translated display name for a user based on the current active language.
 */
export function getUserDisplayName(
  user: User | null | undefined,
  t: (key: string, fallback?: string, params?: Record<string, string | number>) => string
): string {
  if (!user) return '';
  if (user.role === 'trial' || user.subscriptionType === 'trial' || user.id === 999999) {
    return t('login.trialUsername', 'حساب تجريبي');
  }
  if (user.role === 'admin' && (user.username === 'admin' || !user.username)) {
    return t('settings.adminRole', 'مدير عام');
  }
  return user.username;
}

/**
 * Returns a dynamically translated display branch name for a user based on the current active language.
 */
export function getUserBranchDisplayName(
  user: User | null | undefined,
  t: (key: string, fallback?: string, params?: Record<string, string | number>) => string
): string {
  if (!user) return '';
  if (user.role === 'trial' || user.subscriptionType === 'trial' || user.id === 999999) {
    if (user.allowedModules === 'debts') {
      return t('login.trialDebtsBranch', 'تجريبي - دفتر الديون');
    }
    if (user.allowedModules === 'installments') {
      return t('login.trialInstallmentsBranch', 'تجريبي - نظام الأقساط');
    }
    return t('login.trialBothBranch', 'تجريبي - شامل النظامين');
  }
  if (user.role === 'admin') {
    if (
      !user.branch_name ||
      user.branch_name === 'الإدارة العامة' ||
      user.branch_name === 'General Administration' ||
      user.branch_name === 'بەڕێوەبەرایەتی گشتی' ||
      user.branch_name === 'main_admin'
    ) {
      return t('header.adminManagement', 'الإدارة العامة');
    }
    return user.branch_name;
  }
  return user.branch_name || t('settings.mainBranch', 'الفرع الرئيسي');
}

/**
 * Returns a dynamically translated display role badge for a user based on the current active language.
 */
export function getUserRoleDisplayName(
  user: User | null | undefined,
  t: (key: string, fallback?: string, params?: Record<string, string | number>) => string
): string {
  if (!user) return '';
  if (user.role === 'admin') {
    return t('settings.adminRole', 'مدير عام');
  }
  if (user.role === 'trial' || user.subscriptionType === 'trial' || user.id === 999999) {
    return t('settings.trialRole', 'حساب تجريبي');
  }
  return t('settings.managerRole', 'مدير فرع');
}
