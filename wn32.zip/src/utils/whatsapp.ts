import { Debtor, InstallmentRecord } from '../types';

/**
 * Formats a phone number for WhatsApp URL.
 * Handles Iraqi phone numbers (07xxxxxxxxx -> 9647xxxxxxxxx)
 * and cleans up any spaces, dashes, or non-numeric characters.
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^\d+]/g, '');

  // Handle + prefix
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // If starts with 07... (11 digits Iraq), convert to 9647...
  if (cleaned.startsWith('07') && cleaned.length === 11) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.startsWith('7') && cleaned.length === 10) {
    cleaned = '964' + cleaned;
  }

  return cleaned;
}

/**
 * Generates the full WhatsApp API URL for sending a message
 */
export function getWhatsAppUrl(phone: string, message: string): string {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone);
  const encodedText = encodeURIComponent(message);
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * Directly opens WhatsApp without any intermediate UI
 */
export function openWhatsAppDirect(phone: string, message: string): boolean {
  try {
    const formattedPhone = formatPhoneNumberForWhatsApp(phone);
    if (!formattedPhone) return false;
    const url = getWhatsAppUrl(phone, message);

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 200);
    return true;
  } catch (err) {
    console.warn('Could not open WhatsApp directly:', err);
    try {
      const url = getWhatsAppUrl(phone, message);
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch {
      return false;
    }
  }
}

export interface WhatsAppNotificationData {
  customerName: string;
  phone: string;
  title: string;
  message: string;
  url: string;
}

/**
 * 1. عند إضافة عميل جديد (New Debtor)
 * القالب:
 * تم تسجيل دين
 * اسم الزبون :
 * المبلغ :
 * التاريخ :
 * الملاحظات : لا توجد ملاحظات
 * مبلغ الدين السابق :
 * مبلغ الدين الكلي :
 */
export function createNewDebtorWhatsAppNotice(
  debtor: Debtor,
  currencySymbol: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAmount = Number(debtor.amount || 0).toLocaleString('en-US');
  const dateStr = debtor.createdAt
    ? debtor.createdAt.split('T')[0]
    : new Date().toISOString().split('T')[0];
  const notesStr = debtor.notes && debtor.notes.trim() ? debtor.notes.trim() : 'لا توجد ملاحظات';

  const message = `تم تسجيل دين
اسم الزبون : ${debtor.name}
المبلغ : ${formattedAmount} ${currencySymbol}
التاريخ : ${dateStr}
الملاحظات : ${notesStr}
مبلغ الدين السابق : 0 ${currencySymbol}
مبلغ الدين الكلي : ${formattedAmount} ${currencySymbol}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'تسجيل دين جديد',
    message,
    url,
  };
}

/**
 * 2. عند إضافة دين لعميل موجود (Add Debt)
 * القالب:
 * تم تسجيل دين
 * اسم الزبون :
 * المبلغ :
 * التاريخ :
 * الملاحظات : لا توجد ملاحظات
 * مبلغ الدين السابق :
 * مبلغ الدين الكلي :
 */
export function createAddDebtWhatsAppNotice(
  debtor: Debtor,
  addedAmount: number,
  newTotalAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAdded = addedAmount.toLocaleString('en-US');
  const formattedPrev = Number(debtor.amount || 0).toLocaleString('en-US');
  const formattedTotal = newTotalAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];
  const notesStr = notes && notes.trim() ? notes.trim() : 'لا توجد ملاحظات';

  const message = `تم تسجيل دين
اسم الزبون : ${debtor.name}
المبلغ : ${formattedAdded} ${currencySymbol}
التاريخ : ${dateStr}
الملاحظات : ${notesStr}
مبلغ الدين السابق : ${formattedPrev} ${currencySymbol}
مبلغ الدين الكلي : ${formattedTotal} ${currencySymbol}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار إضافة دين',
    message,
    url,
  };
}

/**
 * 3. عند تسديد دين (Pay Debt)
 * القالب:
 * تم تسديد مبلغ 
 * اسم الزبون : 
 * المبلغ : 
 * التاريخ : 
 * الملاحظات :   
 * مبلغ الدين السابق : 
 * مبلغ الدين المتبقي : 
 */
export function createPayDebtWhatsAppNotice(
  debtor: Debtor,
  paidAmount: number,
  remainingAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedPrev = Number(debtor.amount || 0).toLocaleString('en-US');
  const formattedRemaining = remainingAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];
  const notesStr = notes && notes.trim() ? notes.trim() : 'لا توجد ملاحظات';

  const message = `تم تسديد مبلغ 
اسم الزبون : ${debtor.name}
المبلغ : ${formattedPaid} ${currencySymbol}
التاريخ : ${dateStr}
الملاحظات : ${notesStr}
مبلغ الدين السابق : ${formattedPrev} ${currencySymbol}
مبلغ الدين المتبقي : ${formattedRemaining} ${currencySymbol}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إيصال تسديد دين',
    message,
    url,
  };
}

/**
 * 4. عند إضافة عقد قسط جديد (New Installment)
 */
export function createNewInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  currencySymbol: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedTotal = Number(inst.totalAmount || 0).toLocaleString('en-US');
  const formattedDown = Number(inst.downPayment || 0).toLocaleString('en-US');
  const formattedRemaining = Number(inst.remainingAmount || 0).toLocaleString('en-US');

  const message = `مرحباً ${inst.name}
تم تسجيل معاملة قسط جديدة لكم لدى (${storeName}):

السلعة: ${inst.item}
إجمالي قيمة الأقساط: ${formattedTotal} ${currencySymbol}
الدفعة المقدمة: ${formattedDown} ${currencySymbol}
المبلغ المتبقي: ${formattedRemaining} ${currencySymbol}
تاريخ القسط القادم: ${inst.nextDueDate}
${inst.notes ? `ملاحظات: ${inst.notes}\n` : ''}
شكراً لثقتكم بنا.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'تسجيل معاملة قسط جديدة',
    message,
    url,
  };
}

/**
 * 5. عند تسديد قسط (Pay Installment)
 */
export function createPayInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  paidAmount: number,
  newRemaining: number,
  nextDueDate: string,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemaining.toLocaleString('en-US');
  const dateStr = payDate ? payDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const isCompleted = newRemaining <= 0;
  const statusLine = isCompleted
    ? 'تم تسديد كامل الأقساط بنجاح واكتمل العقد بالكامل.'
    : `المتبقي الكلي: ${formattedRemaining} ${currencySymbol}\nموعد القسط القادم: ${nextDueDate}`;

  const message = `مرحباً ${inst.name}
إيصال تسديد قسط لدى (${storeName}):

السلعة: ${inst.item}
المبلغ المسدد: ${formattedPaid} ${currencySymbol}
تاريخ الدفع: ${dateStr}
${statusLine}
${notes ? `ملاحظات: ${notes}\n` : ''}
شكراً لالتزامكم بالتسديد.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'إيصال تسديد قسط',
    message,
    url,
  };
}
