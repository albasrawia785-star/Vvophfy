// Service Worker for Developer Installments App Notifications

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Event listener for notification click
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  // Focus or open the app window
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      if (clientList.length > 0) {
        let client = clientList[0];
        for (let i = 0; i < clientList.length; i++) {
          if (clientList[i].focused) {
            client = clientList[i];
            break;
          }
        }
        return client.focus();
      }
      return self.clients.openWindow('/');
    })
  );
});

// Listen for push notifications if any external trigger is integrated in future,
// or handle background message requests from the main application.
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'TRIGGER_INSTALLMENT_NOTIFICATION') {
    const { title, body, icon } = event.data;
    event.waitUntil(
      self.registration.showNotification(title, {
        body: body,
        icon: icon || '/favicon.ico',
        badge: icon || '/favicon.ico',
        tag: 'installment-reminder',
        requireInteraction: true,
        vibrate: [300, 100, 300, 100, 400]
      })
    );
  }
});
