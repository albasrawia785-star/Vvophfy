import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  User,
  Users,
  PlusCircle,
  Search,
  MessageCircle,
  Trash2,
  Camera,
  Check,
  FileText,
  Phone,
  DollarSign,
  TrendingUp,
  Calendar,
  ArrowLeft,
  ArrowRight,
  AlertCircle,
  Clock,
  CheckCircle2,
  Image as ImageIcon,
  UserPlus,
  X,
  Lock,
  LogIn,
  LogOut,
  Bell,
  BellOff,
  Settings,
  Eye,
  EyeOff,
  ChevronLeft,
  ChevronDown,
  CreditCard,
  Wallet,
  Sparkles,
  SquarePen,
  ShieldAlert,
  ShieldCheck,
  Sun,
  MapPin,
  Briefcase,
  ShoppingBag,
  Coins,
  Hash,
  Heart,
  Navigation,
  ClipboardList,
  Barcode,
  Info,
  Printer,
  Share2,
  Rocket,
  Bluetooth
} from "lucide-react";
import {
  subscribeToCustomers,
  saveCustomer,
  deleteCustomerFromDb,
  Customer,
  Payment,
  CustomerImages,
  Guarantor,
  GuarantorImages,
  subscribeToSystemCredentials,
  saveSystemCredentials,
  SystemCredentials,
  getCustomerById,
  clearAllLocalDatabaseData
} from "./firebase";
import { CREDENTIALS } from "./password";
import SettingsScreen from "./components/SettingsScreen";
import { PrintTemplate, DEFAULT_TEMPLATES } from "./types";
import {
  TopCard,
  CompletionProgressBar,
  CustomerCard,
  GuarantorCard,
  ProductCard,
  InstallmentCard,
  AttachmentsCard
} from "./components/AddInstallmentCards";
import branding from "./branding.json";

const basraNightBg = "/basra_night_bg.jpg";

// --- CUSTOM APP BRANDING & DATE HELPER ---

const AlAqsatLogo = () => (
  <div className="flex flex-col items-center justify-center">
    <svg className="w-10 h-9" viewBox="0 0 60 45" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 38 L30 10" stroke="white" strokeWidth="5.5" strokeLinecap="round" />
      <path d="M28 10 L42 38" stroke="white" strokeWidth="5.5" strokeLinecap="round" />
      <path d="M12 28 Q30 20 48 16" stroke="#C29E6B" strokeWidth="4" strokeLinecap="round" />
    </svg>
    <span className="text-[10px] text-white font-black tracking-wider -mt-1 font-sans">Al-Aqsat</span>
  </div>
);

const getArabicDateString = () => {
  const days = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  const months = [
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
  ];
  const d = new Date();
  const dayName = days[d.getDay()];
  const dayNum = d.getDate();
  const monthName = months[d.getMonth()];
  const year = d.getFullYear();
  return `${dayName} ${dayNum} ${monthName} ${year}`;
};

// --- CUSTOM SEARCHABLE DROPDOWN & COMPACT UPLOADER COMPONENTS ---

const IRAQ_GOVERNORATES = [
  "بغداد",
  "نينوى",
  "البصرة",
  "ذي قار",
  "بابل",
  "الأنبار",
  "أربيل",
  "النجف",
  "كربلاء",
  "القادسية",
  "واسط",
  "صلاح الدين",
  "السليمانية",
  "ديالى",
  "كركوك",
  "ميسان",
  "المثنى",
  "دهوك",
  "حلبجة"
];

interface GovernorateDropdownProps {
  value: string;
  onChange: (val: string) => void;
  label?: string;
  required?: boolean;
}

export function SearchableGovernorateDropdown({ value, onChange, label, required = false }: GovernorateDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    return IRAQ_GOVERNORATES.filter((gov) =>
      gov.includes(search.trim())
    );
  }, [search]);

  return (
    <div className="relative text-right flex-1" dir="rtl">
      {label && <label className="text-xs font-black text-slate-700 block mb-1">{label} {required && "*"}</label>}
      
      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-4.5 py-4 rounded-2xl border border-slate-200 bg-slate-50/30 hover:bg-slate-50/50 focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-xs font-semibold text-slate-800 text-right flex items-center justify-between"
      >
        <span>{value || "اختر المحافظة..."}</span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {/* Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop click closer */}
            <div className="fixed inset-0 z-[45]" onClick={() => setIsOpen(false)} />
            
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute left-0 right-0 mt-1.5 bg-white border border-slate-150 rounded-2xl shadow-xl z-[50] overflow-hidden max-h-60 flex flex-col"
            >
              {/* Search input inside dropdown */}
              <div className="p-2 border-b border-slate-100 flex items-center gap-2 bg-slate-50/50">
                <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-transparent text-xs font-bold outline-none text-slate-800 text-right"
                />
                {search && (
                  <button type="button" onClick={() => setSearch("")} className="text-slate-400 hover:text-slate-600">
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Items List */}
              <div className="overflow-y-auto flex-1 py-1 max-h-44 scrollbar-thin">
                {filtered.length > 0 ? (
                  filtered.map((gov) => {
                    const isSelected = value === gov;
                    return (
                      <button
                        key={gov}
                        type="button"
                        onClick={() => {
                          onChange(gov);
                          setIsOpen(false);
                          setSearch("");
                        }}
                        className={`w-full px-4.5 py-2.5 text-xs font-bold text-right transition-colors flex items-center justify-between hover:bg-slate-50 ${
                          isSelected ? "bg-[#0B1F3A]/5 text-[#0B1F3A]" : "text-slate-700"
                        }`}
                      >
                        <span>{gov}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#D4A44B]" />}
                      </button>
                    );
                  })
                ) : (
                  <div className="px-4.5 py-3 text-xs text-slate-400 font-bold text-center">لا توجد نتائج</div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

interface DocUploaderProps {
  type: "customer" | "guarantor";
  images: CustomerImages | GuarantorImages;
  onUploadClick: (docKey: "personal" | "idFront" | "idBack" | "resFront" | "resBack", file: File) => void;
  onRemoveClick: (docKey: "personal" | "idFront" | "idBack" | "resFront" | "resBack") => void;
  onPreviewClick: (src: string) => void;
  compressingKeys: string[];
}

export function CompactDocumentRow({ type, images, onUploadClick, onRemoveClick, onPreviewClick, compressingKeys }: DocUploaderProps) {
  const docTypes = [
    { key: "personal", label: "الصورة الشخصية" },
    { key: "idFront", label: "بطاقة الهوية (الوجه)" },
    { key: "idBack", label: "بطاقة الهوية (الظهر)" },
    { key: "resFront", label: "بطاقة السكن (الوجه)" },
    { key: "resBack", label: "بطاقة السكن (الظهر)" }
  ] as const;

  const handleInputFileChange = (key: "personal" | "idFront" | "idBack" | "resFront" | "resBack", e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadClick(key, file);
    }
  };

  return (
    <div className="space-y-2 mt-2" dir="rtl">
      {docTypes.map((item) => {
        const isUploaded = !!images[item.key];
        const isCompressing = compressingKeys.includes(`${type}_${item.key}`);

        return (
          <div
            key={item.key}
            className="flex items-center justify-between p-2.5 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50/80 transition-all text-xs"
          >
            {/* Right Side: Document Title */}
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4A44B]" />
              <span className="font-bold text-slate-700">{item.label}</span>
            </div>

            {/* Left Side: Actions or Status */}
            <div className="flex items-center gap-2">
              {isCompressing ? (
                <div className="flex items-center gap-1.5 py-1 px-2.5 bg-slate-100 text-slate-500 rounded-lg text-[10px] font-black">
                  <div className="w-3.5 h-3.5 border-2 border-[#0B1F3A] border-t-transparent rounded-full animate-spin" />
                  <span>جاري الضغط...</span>
                </div>
              ) : isUploaded ? (
                <div className="flex items-center gap-2">
                  {/* Success State Badge */}
                  <span className="flex items-center gap-1 bg-emerald-50 text-emerald-700 px-2 py-1 rounded-lg text-[10px] font-black border border-emerald-100/80">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>تم الرفع</span>
                  </span>

                  {/* Preview Button */}
                  <button
                    type="button"
                    onClick={() => onPreviewClick(images[item.key] as string)}
                    className="flex items-center gap-1 bg-slate-100 text-slate-600 hover:text-[#D4A44B] px-2 py-1 rounded-lg text-[10px] font-semibold border border-slate-200 transition-colors cursor-pointer"
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-slate-500" />
                    <span>عرض</span>
                  </button>

                  {/* Delete Button */}
                  <button
                    type="button"
                    onClick={() => onRemoveClick(item.key)}
                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                    title="حذف المستند"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  {/* Camera Icon (for live photo) */}
                  <label className="flex items-center justify-center w-8 h-8 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-[#0B1F3A] hover:border-slate-300 hover:bg-slate-50 transition-all cursor-pointer shadow-sm active:scale-95">
                    <Camera className="w-4 h-4" />
                    <input
                      type="file"
                      accept="image/*"
                      capture={item.key === "personal" ? "user" : "environment"}
                      onChange={(e) => handleInputFileChange(item.key, e)}
                      className="hidden"
                    />
                  </label>

                  {/* Gallery Icon (choosing from studio) */}
                  <label className="flex items-center justify-center w-8 h-8 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-[#D4A44B] hover:border-[#D4A44B]/30 hover:bg-slate-50 transition-all cursor-pointer shadow-sm active:scale-95">
                    <ImageIcon className="w-4 h-4" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleInputFileChange(item.key, e)}
                      className="hidden"
                    />
                  </label>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// --- SAFE NEXT DUE DATE CALCULATION UTILITIES ---

function getSafeDate(year: number, month: number, targetDay: number): Date {
  const lastDayOfTargetMonth = new Date(year, month + 1, 0).getDate();
  const safeDay = Math.min(targetDay, lastDayOfTargetMonth);
  return new Date(year, month, safeDay);
}

function parseCustomerDateAdded(dateAddedStr: string): { year: number; month: number; day: number } {
  const cleanStr = (dateAddedStr || "").replace(/\//g, "-");
  const parts = cleanStr.split("-");
  const year = parseInt(parts[0], 10) || 2026;
  const month = (parseInt(parts[1], 10) || 7) - 1; // 0-indexed month
  const day = parseInt(parts[2], 10) || 6;
  return { year, month, day };
}

function getCustomerNextDueDate(customer: Customer): Date {
  const { year: regYear, month: regMonth } = parseCustomerDateAdded(customer.dateAdded);
  
  // Total paid installments amount:
  const totalPaidInstallmentsAmount = (customer.totalAmount - customer.upfront) - customer.remainingAmount;
  // Number of paid installments:
  const paidCount = Math.floor(totalPaidInstallmentsAmount / customer.monthlyAmount);
  
  // Next due date is (paidCount + 1) months after registration month
  const targetYear = regYear;
  const targetMonth = regMonth + (paidCount + 1);
  const targetDay = customer.dueDay || 1;
  
  return getSafeDate(targetYear, targetMonth, targetDay);
}

function formatNextDueDate(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}/${month}/${day}`;
}

function isCustomerDue(customer: Customer): boolean {
  if (customer.status !== "active") return false;
  
  const nextDueDate = getCustomerNextDueDate(customer);
  
  // Get today's date set to midnight
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Set nextDueDate to midnight to compare only dates
  const nextDueMidnight = new Date(nextDueDate);
  nextDueMidnight.setHours(0, 0, 0, 0);
  
  // Due if today is greater than or equal to nextDueMidnight
  return today.getTime() >= nextDueMidnight.getTime();
}

interface CustomerAlertInfo {
  nextDueDate: Date;
  daysRemaining: number;
  status: "approaching" | "due_today" | "overdue" | "not_due";
  statusText: string;
}

function getCustomerAlertInfo(customer: Customer): CustomerAlertInfo {
  const nextDueDate = getCustomerNextDueDate(customer);
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const nextDueMidnight = new Date(nextDueDate);
  nextDueMidnight.setHours(0, 0, 0, 0);
  
  const diffTime = nextDueMidnight.getTime() - today.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
  
  if (customer.status !== "active" || customer.remainingAmount <= 0) {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "not_due",
      statusText: "مكتمل السداد"
    };
  }
  
  if (diffDays < 0) {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "overdue",
      statusText: "متأخر عن السداد"
    };
  } else if (diffDays === 0) {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "due_today",
      statusText: "مستحق اليوم"
    };
  } else if (diffDays === 1 || diffDays === 2 || diffDays === 3) {
    const remainingText = diffDays === 1 ? "يوم واحد" : diffDays === 2 ? "يومان" : "3 أيام";
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "approaching",
      statusText: `يقترب موعد السداد (متبقي ${remainingText})`
    };
  } else {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "not_due",
      statusText: `متبقي ${diffDays} يوم`
    };
  }
}

export default function App() {
  // Track initial layout height & keyboard state to prevent layout jumping when keyboard appears
  const [initialHeight, setInitialHeight] = useState<number>(() => window.innerHeight);
  const [isKeyboardActive, setIsKeyboardActive] = useState(false);

  useEffect(() => {
    // Lock initial height on mount
    setInitialHeight(window.innerHeight);

    // Update initial height if screen orientation/width changes
    let lastWidth = window.innerWidth;
    const handleResize = () => {
      if (window.innerWidth !== lastWidth) {
        setInitialHeight(window.innerHeight);
        lastWidth = window.innerWidth;
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    if (!window.visualViewport) return;

    const handleVisualViewportResize = () => {
      const vv = window.visualViewport;
      if (!vv) return;
      
      // If the visible height is significantly smaller than the total layout height, the soft keyboard is open.
      const isKeyboard = vv.height < window.innerHeight * 0.85;
      setIsKeyboardActive(isKeyboard);
    };

    window.visualViewport.addEventListener("resize", handleVisualViewportResize);
    // Initial check
    handleVisualViewportResize();

    return () => {
      window.visualViewport?.removeEventListener("resize", handleVisualViewportResize);
    };
  }, []);

  // Smooth scroll to focused inputs when keyboard is active
  useEffect(() => {
    const handleFocus = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT")) {
        setTimeout(() => {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 150);
      }
    };

    document.addEventListener("focusin", handleFocus);
    return () => document.removeEventListener("focusin", handleFocus);
  }, []);

  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem("isLoggedIn") === "true";
  });
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  // Demo Trial States
  const [isDemoActive, setIsDemoActive] = useState(() => {
    return localStorage.getItem("demo_active") === "true";
  });
  const [demoStartTime, setDemoStartTime] = useState<number | null>(() => {
    const saved = localStorage.getItem("demo_start_time");
    return saved ? Number(saved) : null;
  });
  const [demoUsed, setDemoUsed] = useState<boolean>(() => {
    return localStorage.getItem("demo_used") === "true";
  });
  const [showDemoExpiredModal, setShowDemoExpiredModal] = useState(false);
  const [showDemoLimitReachedModal, setShowDemoLimitReachedModal] = useState(false);
  const [demoTimeLeftText, setDemoTimeLeftText] = useState("");

  const [systemCredentials, setSystemCredentials] = useState<SystemCredentials | null>(() => {
    const cached = localStorage.getItem("cached_system_credentials");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error("Error parsing cached credentials:", e);
      }
    }
    return null;
  });

  // Helper to wipe all data when guest period expires
  const wipeAllData = () => {
    localStorage.clear();
    // Re-set demo_used so they cannot sign in again
    localStorage.setItem("demo_used", "true");
    
    // Clear IndexedDB completely
    clearAllLocalDatabaseData().catch(err => {
      console.error("Error clearing local IndexedDB database:", err);
    });

    setCustomers([]);
    setIsLoggedIn(false);
    setSelectedCustomerId(null);
    setActiveFullCustomer(null);
    
    // Clear form fields
    setCustName("");
    setCustPhone("");
    setCustNationalId("");
    setCustGovernorate("");
    setCustNearestLandmark("");
    setCustProfession("");
    
    setProdName("");
    setProdSerial("");
    setProdDetails("");
    
    setCustCashPrice("");
    setCustTotalAmount("");
    setCustUpfront("");
    setCustMonthly("");
    setCustInstallmentCount("12");
    setCustDueDay(new Date().getDate().toString());
    
    setImages({
      personal: "",
      resFront: "",
      resBack: "",
      idFront: "",
      idBack: ""
    });
    
    setHasGuarantor(false);
    setGuarantorName("");
    setGuarantorPhone("");
    setGuarantorAddress("");
    setGuarantorGovernorate("");
    setGuarantorNearestLandmark("");
    setGuarantorNationalId("");
    setGuarantorProfession("");
    setGuarantorRelationship("");
    setGuarantorImages({
      personal: "",
      idFront: "",
      idBack: "",
      resFront: "",
      resBack: ""
    });
    setFormStep(1);
  };

  // Demo Trial Countdown Timer Effect
  useEffect(() => {
    if (!isDemoActive || !demoStartTime) return;

    const checkAndCalculate = () => {
      const duration = 2 * 60 * 60 * 1000; // 2 hours
      const elapsed = Date.now() - demoStartTime;
      const remaining = duration - elapsed;

      if (remaining <= 0) {
        wipeAllData();
        localStorage.removeItem("demo_active");
        localStorage.removeItem("demo_start_time");
        localStorage.setItem("demo_used", "true");
        setIsDemoActive(false);
        setDemoStartTime(null);
        setDemoUsed(true);
        setIsLoggedIn(false);
        setShowDemoExpiredModal(true);
      } else {
        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((remaining % (1000 * 60)) / 1000);
        
        const hStr = String(hours).padStart(2, '0');
        const mStr = String(minutes).padStart(2, '0');
        const sStr = String(seconds).padStart(2, '0');
        
        setDemoTimeLeftText(`${hStr}:${mStr}:${sStr}`);
      }
    };

    checkAndCalculate();
    const timer = setInterval(checkAndCalculate, 1000);
    return () => clearInterval(timer);
  }, [isDemoActive, demoStartTime]);

  // Initial check on mount in case the demo elapsed while offline/away
  useEffect(() => {
    if (isDemoActive && demoStartTime) {
      const duration = 2 * 60 * 60 * 1000;
      const elapsed = Date.now() - demoStartTime;
      if (elapsed >= duration) {
        wipeAllData();
        localStorage.removeItem("demo_active");
        localStorage.removeItem("demo_start_time");
        localStorage.setItem("demo_used", "true");
        setIsDemoActive(false);
        setDemoStartTime(null);
        setDemoUsed(true);
        setIsLoggedIn(false);
        setShowDemoExpiredModal(true);
      }
    }
  }, []);

  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);

  // Notification states
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      return Notification.permission;
    }
    return "default";
  });

  // Navigation & State - with persistence to handle browser camera memory-reload suspends
  const [currentScreen, setCurrentScreen] = useState<"add" | "list" | "detail" | "alerts" | "settings">(() => {
    const saved = localStorage.getItem("app_currentScreen");
    if (saved === "home" || !saved) return "list";
    return (saved as any);
  });
  const [showBalance, setShowBalance] = useState<boolean>(() => {
    return localStorage.getItem("app_showBalance") !== "false";
  });
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(() => {
    return localStorage.getItem("app_selectedCustomerId") || null;
  });
  const [activeFullCustomer, setActiveFullCustomer] = useState<Customer | null>(null);

  // Thermal Receipt State & Export Statement State
  const [thermalReceiptData, setThermalReceiptData] = useState<{
    title: string;
    customerName: string;
    customerPhone: string;
    productName: string;
    totalAmount: number;
    upfront?: number;
    paidAmount?: number;
    remainingAmount: number;
    monthlyAmount?: number;
    dueDay?: number;
    date: string;
    nextDueDate?: string;
  } | null>(null);

  const [statementExportCustomer, setStatementExportCustomer] = useState<Customer | null>(null);

  const [cairoFontReady, setCairoFontReady] = useState<boolean>(false);

  useEffect(() => {
    if (typeof document !== "undefined" && document.fonts) {
      document.fonts.load("bold 21px 'Cairo'")
        .then(() => {
          setCairoFontReady(true);
        })
        .catch((err) => {
          console.warn("Cairo font preloading failed:", err);
          setCairoFontReady(true); // set ready anyway to continue gracefully
        });
    } else {
      setCairoFontReady(true);
    }
  }, []);

  // Web Bluetooth Printer State
  const [bluetoothDevice, setBluetoothDevice] = useState<{
    device: any;
    server: any;
    characteristic: any;
    name: string;
  } | null>(null);
  const [isBluetoothConnecting, setIsBluetoothConnecting] = useState(false);
  const [bluetoothPermissionError, setBluetoothPermissionError] = useState(false);
  const [printerPaperSize, setPrinterPaperSize] = useState<"58mm" | "80mm" | string>(() => {
    return localStorage.getItem("printer_paper_size") || "58mm";
  });
  const [printerThreshold, setPrinterThreshold] = useState<number>(() => {
    const cached = localStorage.getItem("printer_threshold");
    return cached ? Number(cached) : 215;
  });
  const [printerThickness, setPrinterThickness] = useState<number>(() => {
    const cached = localStorage.getItem("printer_thickness");
    return cached ? Number(cached) : 2;
  });
  const [activeTemplateId, setActiveTemplateId] = useState<string>(() => {
    return localStorage.getItem("active_print_template_id") || "standard";
  });
  const [customTemplates, setCustomTemplates] = useState<PrintTemplate[]>(() => {
    const cached = localStorage.getItem("custom_print_templates");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error("Error parsing custom templates:", e);
      }
    }
    return [];
  });
  const activeTemplate = useMemo(() => {
    const foundDefault = DEFAULT_TEMPLATES.find(t => t.id === activeTemplateId);
    if (foundDefault) return foundDefault;
    const foundCustom = customTemplates.find(t => t.id === activeTemplateId);
    if (foundCustom) return foundCustom;
    return DEFAULT_TEMPLATES[0]; // fallback
  }, [activeTemplateId, customTemplates]);
  const [filterBluetoothPrintersOnly, setFilterBluetoothPrintersOnly] = useState<boolean>(true);

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const cached = localStorage.getItem("cached_customers");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error("Error reading cached customers:", e);
      }
    }
    return [];
  });

  useEffect(() => {
    if (selectedCustomerId) {
      getCustomerById(selectedCustomerId)
        .then((fullCust) => {
          if (fullCust) {
            setActiveFullCustomer(fullCust);
          }
        })
        .catch((err) => {
          console.error("Error loading full customer on-demand:", err);
        });
    } else {
      setActiveFullCustomer(null);
    }
  }, [selectedCustomerId]);
  
  // Multi-step Form Active Step (1: Client Info, 2: Product Info, 3: Installments, 4: Guarantor, 5: Docs, "review": Final Review)
  const [formStep, setFormStep] = useState<number | "review">(() => {
    const saved = localStorage.getItem("draft_formStep");
    if (saved === "review") return "review";
    const num = Number(saved);
    if (num >= 1 && num <= 5) return num;
    return 1;
  });

  // Client-side Infinite Scroll / Lazy Loading limit
  const [visibleCount, setVisibleCount] = useState(10);
  
  // Search and Filter State
  const [searchText, setSearchText] = useState("");
  const [currentFilter, setCurrentFilter] = useState<"all" | "due">("all");
  const [alertFilter, setAlertFilter] = useState<"all" | "overdue" | "due_today" | "approaching">("all");

  // Form Fields State - recovered from draft persistence
  const [custName, setCustName] = useState(() => localStorage.getItem("draft_custName") || "");
  const [custPhone, setCustPhone] = useState(() => localStorage.getItem("draft_custPhone") || "");
  const [custNationalId, setCustNationalId] = useState(() => localStorage.getItem("draft_custNationalId") || "");
  const [custGovernorate, setCustGovernorate] = useState(() => localStorage.getItem("draft_custGovernorate") || "");
  const [custNearestLandmark, setCustNearestLandmark] = useState(() => localStorage.getItem("draft_custNearestLandmark") || "");
  const [custProfession, setCustProfession] = useState(() => localStorage.getItem("draft_custProfession") || "");
  const [prodName, setProdName] = useState(() => localStorage.getItem("draft_prodName") || "");
  const [prodSerial, setProdSerial] = useState(() => localStorage.getItem("draft_prodSerial") || "");
  const [prodDetails, setProdDetails] = useState(() => localStorage.getItem("draft_prodDetails") || "");
  
  const [custCashPrice, setCustCashPrice] = useState(() => localStorage.getItem("draft_custCashPrice") || "");
  const [custTotalAmount, setCustTotalAmount] = useState(() => localStorage.getItem("draft_custTotalAmount") || "");
  const [custUpfront, setCustUpfront] = useState(() => localStorage.getItem("draft_custUpfront") || "");
  const [custMonthly, setCustMonthly] = useState(() => localStorage.getItem("draft_custMonthly") || "");
  const [custInstallmentCount, setCustInstallmentCount] = useState(() => localStorage.getItem("draft_custInstallmentCount") || "12");
  const [firstInstallmentDate, setFirstInstallmentDate] = useState(() => {
    const saved = localStorage.getItem("draft_firstInstallmentDate");
    if (saved) return saved;
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });
  const [custDueDay, setCustDueDay] = useState(() => localStorage.getItem("draft_custDueDay") || new Date().getDate().toString());

  // Guarantor Fields State - recovered from draft persistence
  const [hasGuarantor, setHasGuarantor] = useState<boolean>(() => localStorage.getItem("draft_hasGuarantor") === "true");
  const [guarantorName, setGuarantorName] = useState(() => localStorage.getItem("draft_guarantorName") || "");
  const [guarantorPhone, setGuarantorPhone] = useState(() => localStorage.getItem("draft_guarantorPhone") || "");
  const [guarantorAddress, setGuarantorAddress] = useState(() => localStorage.getItem("draft_guarantorAddress") || "");
  const [guarantorGovernorate, setGuarantorGovernorate] = useState(() => {
    const saved = localStorage.getItem("draft_guarantorGovernorate");
    if (saved) return saved;
    const addr = localStorage.getItem("draft_guarantorAddress") || "";
    if (addr.includes(" - ")) return addr.split(" - ")[0];
    return "";
  });
  const [guarantorNearestLandmark, setGuarantorNearestLandmark] = useState(() => {
    const saved = localStorage.getItem("draft_guarantorNearestLandmark");
    if (saved) return saved;
    const addr = localStorage.getItem("draft_guarantorAddress") || "";
    if (addr.includes(" - ")) return addr.split(" - ").slice(1).join(" - ");
    return addr;
  });
  const [guarantorNationalId, setGuarantorNationalId] = useState(() => localStorage.getItem("draft_guarantorNationalId") || "");
  const [guarantorProfession, setGuarantorProfession] = useState(() => localStorage.getItem("draft_guarantorProfession") || "");
  const [guarantorRelationship, setGuarantorRelationship] = useState(() => localStorage.getItem("draft_guarantorRelationship") || "");
  const [guarantorImages, setGuarantorImages] = useState<GuarantorImages>(() => {
    const saved = localStorage.getItem("draft_guarantorImages");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error reading draft guarantor images:", e);
      }
    }
    return {
      personal: "",
      idFront: "",
      idBack: "",
      resFront: "",
      resBack: ""
    };
  });

  const [compressingKeys, setCompressingKeys] = useState<string[]>([]);

  // Registration/Sale & Payment Dates
  const [custDateAdded, setCustDateAdded] = useState<string>(() => {
    const saved = localStorage.getItem("draft_custDateAdded");
    if (saved) return saved;
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });
  const [payDateInput, setPayDateInput] = useState<string>(() => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });

  // Modal / Confirm States
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [showNoDocsConfirm, setShowNoDocsConfirm] = useState(false);
  const [showClearFieldsConfirm, setShowClearFieldsConfirm] = useState(false);
  
  // Image Upload State - recovered from draft persistence
  const [images, setImages] = useState<CustomerImages>(() => {
    const saved = localStorage.getItem("draft_images");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error reading draft images:", e);
      }
    }
    return {
      personal: "",
      resFront: "",
      resBack: "",
      idFront: "",
      idBack: ""
    };
  });

  // Page length optimizations - Document Upload Accordions and Floating Bottom Sheet
  const [guarantorDocsExpanded, setGuarantorDocsExpanded] = useState(false);
  const [customerDocsExpanded, setCustomerDocsExpanded] = useState(false);
  
  const [uploadTarget, setUploadTarget] = useState<{
    type: "customer" | "guarantor";
    docKey: "personal" | "idFront" | "idBack" | "resFront" | "resBack";
    label: string;
  } | null>(null);

  const cameraInputRef = React.useRef<HTMLInputElement | null>(null);
  const galleryInputRef = React.useRef<HTMLInputElement | null>(null);

  // Auto-expand effects based on form progression & existence of uploaded images
  useEffect(() => {
    const isGuarantorFilled = guarantorName.trim().length > 3 && guarantorPhone.trim().length > 7 && guarantorNationalId.trim().length > 5;
    const hasAnyGuarantorImage = Object.values(guarantorImages).some((val): val is string => typeof val === "string" && val.trim() !== "");
    if (isGuarantorFilled || hasAnyGuarantorImage) {
      setGuarantorDocsExpanded(true);
    }
  }, [guarantorName, guarantorPhone, guarantorNationalId, guarantorImages]);

  useEffect(() => {
    const isCustomerFilled = custName.trim().length > 3 && custPhone.trim().length > 7 && custNationalId.trim().length > 5;
    const hasAnyCustomerImage = Object.values(images).some((val): val is string => typeof val === "string" && val.trim() !== "");
    if (isCustomerFilled || hasAnyCustomerImage) {
      setCustomerDocsExpanded(true);
    }
  }, [custName, custPhone, custNationalId, images]);

  // Submission Guard State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPaying, setIsPaying] = useState(false);

  // Ready-made Message Templates Modal State
  const [templateModalCustomer, setTemplateModalCustomer] = useState<Customer | null>(null);

  // Custom Toast Alert state
  const [toast, setToast] = useState<{ message: string; type: "success" | "danger" | "info" } | null>(null);

  // Payment Recording State
  const [payAmountInput, setPayAmountInput] = useState("");

  // Fullscreen Image Preview Modal State
  const [previewImageSrc, setPreviewImageSrc] = useState<string | null>(null);

  // Sync state values back to localStorage drafts
  useEffect(() => {
    localStorage.setItem("app_currentScreen", currentScreen);
  }, [currentScreen]);

  useEffect(() => {
    if (selectedCustomerId) {
      localStorage.setItem("app_selectedCustomerId", selectedCustomerId);
    } else {
      localStorage.removeItem("app_selectedCustomerId");
    }
  }, [selectedCustomerId]);

  useEffect(() => {
    localStorage.setItem("draft_custName", custName);
  }, [custName]);

  useEffect(() => {
    localStorage.setItem("draft_custPhone", custPhone);
  }, [custPhone]);

  useEffect(() => {
    localStorage.setItem("draft_custNationalId", custNationalId);
  }, [custNationalId]);

  useEffect(() => {
    localStorage.setItem("draft_custGovernorate", custGovernorate);
  }, [custGovernorate]);

  useEffect(() => {
    localStorage.setItem("draft_custNearestLandmark", custNearestLandmark);
  }, [custNearestLandmark]);

  useEffect(() => {
    localStorage.setItem("draft_custProfession", custProfession);
  }, [custProfession]);

  useEffect(() => {
    localStorage.setItem("draft_prodName", prodName);
  }, [prodName]);

  useEffect(() => {
    localStorage.setItem("draft_prodSerial", prodSerial);
  }, [prodSerial]);

  useEffect(() => {
    localStorage.setItem("draft_prodDetails", prodDetails);
  }, [prodDetails]);

  useEffect(() => {
    localStorage.setItem("draft_custCashPrice", custCashPrice);
  }, [custCashPrice]);

  useEffect(() => {
    localStorage.setItem("draft_custTotalAmount", custTotalAmount);
  }, [custTotalAmount]);

  useEffect(() => {
    localStorage.setItem("draft_custUpfront", custUpfront);
  }, [custUpfront]);

  useEffect(() => {
    localStorage.setItem("draft_custMonthly", custMonthly);
  }, [custMonthly]);

  useEffect(() => {
    localStorage.setItem("draft_custInstallmentCount", custInstallmentCount);
  }, [custInstallmentCount]);

  useEffect(() => {
    localStorage.setItem("draft_firstInstallmentDate", firstInstallmentDate);
  }, [firstInstallmentDate]);

  useEffect(() => {
    localStorage.setItem("draft_custDueDay", custDueDay);
  }, [custDueDay]);

  useEffect(() => {
    localStorage.setItem("draft_custDateAdded", custDateAdded);
  }, [custDateAdded]);

  useEffect(() => {
    try {
      localStorage.setItem("draft_images", JSON.stringify(images));
    } catch (e) {
      console.warn("Could not save draft customer images to localStorage due to size limits:", e);
    }
  }, [images]);

  useEffect(() => {
    localStorage.setItem("draft_hasGuarantor", String(hasGuarantor));
  }, [hasGuarantor]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorName", guarantorName);
  }, [guarantorName]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorPhone", guarantorPhone);
  }, [guarantorPhone]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorGovernorate", guarantorGovernorate);
    localStorage.setItem("draft_guarantorNearestLandmark", guarantorNearestLandmark);
    const fullAddr = guarantorGovernorate ? `${guarantorGovernorate} - ${guarantorNearestLandmark}` : guarantorNearestLandmark;
    setGuarantorAddress(fullAddr);
    localStorage.setItem("draft_guarantorAddress", fullAddr);
  }, [guarantorGovernorate, guarantorNearestLandmark]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorNationalId", guarantorNationalId);
  }, [guarantorNationalId]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorProfession", guarantorProfession);
  }, [guarantorProfession]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorRelationship", guarantorRelationship);
  }, [guarantorRelationship]);

  useEffect(() => {
    try {
      localStorage.setItem("draft_guarantorImages", JSON.stringify(guarantorImages));
    } catch (e) {
      console.warn("Could not save draft guarantor images to localStorage due to size limits:", e);
    }
  }, [guarantorImages]);

  useEffect(() => {
    localStorage.setItem("draft_formStep", formStep.toString());
  }, [formStep]);

  // Client-side Infinite Scroll / Lazy Loading scroll handler
  useEffect(() => {
    if (currentScreen !== "list") return;

    let isThrottled = false;
    const handleScroll = () => {
      if (isThrottled) return;
      isThrottled = true;
      setTimeout(() => {
        isThrottled = false;
        
        // If we are within 150px of the bottom of the document, load 10 more records
        const threshold = 150;
        const totalHeight = document.documentElement.scrollHeight;
        const currentScrollPosition = window.innerHeight + window.scrollY;

        if (totalHeight - currentScrollPosition <= threshold) {
          setVisibleCount((prev) => {
            if (prev >= customers.length) return prev;
            return prev + 10;
          });
        }
      }, 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [currentScreen, customers.length]);

  // Reset infinite scroll limit when screen or filters change to keep memory usage & DOM clean
  useEffect(() => {
    setVisibleCount(10);
  }, [currentScreen, searchText, currentFilter]);

  // Helper function to clear drafts upon successful registration
  const clearFormDrafts = () => {
    localStorage.removeItem("draft_custName");
    localStorage.removeItem("draft_custPhone");
    localStorage.removeItem("draft_custNationalId");
    localStorage.removeItem("draft_custGovernorate");
    localStorage.removeItem("draft_custNearestLandmark");
    localStorage.removeItem("draft_custProfession");
    localStorage.removeItem("draft_prodName");
    localStorage.removeItem("draft_prodSerial");
    localStorage.removeItem("draft_prodDetails");
    localStorage.removeItem("draft_custCashPrice");
    localStorage.removeItem("draft_custTotalAmount");
    localStorage.removeItem("draft_custUpfront");
    localStorage.removeItem("draft_custMonthly");
    localStorage.removeItem("draft_custInstallmentCount");
    localStorage.removeItem("draft_firstInstallmentDate");
    localStorage.removeItem("draft_custDueDay");
    localStorage.removeItem("draft_custDateAdded");
    localStorage.removeItem("draft_images");
    localStorage.removeItem("draft_hasGuarantor");
    localStorage.removeItem("draft_guarantorName");
    localStorage.removeItem("draft_guarantorPhone");
    localStorage.removeItem("draft_guarantorAddress");
    localStorage.removeItem("draft_guarantorGovernorate");
    localStorage.removeItem("draft_guarantorNearestLandmark");
    localStorage.removeItem("draft_guarantorNationalId");
    localStorage.removeItem("draft_guarantorProfession");
    localStorage.removeItem("draft_guarantorRelationship");
    localStorage.removeItem("draft_guarantorImages");
    localStorage.removeItem("draft_formStep");
    
    setHasGuarantor(false);
    setCustName("");
    setCustPhone("");
    setCustNationalId("");
    setCustGovernorate("");
    setCustNearestLandmark("");
    setCustProfession("");
    setProdName("");
    setProdSerial("");
    setProdDetails("");
    setCustCashPrice("");
    setCustTotalAmount("");
    setCustUpfront("");
    setCustMonthly("");
    setCustInstallmentCount("12");
    setFirstInstallmentDate(() => {
      const d = new Date();
      d.setMonth(d.getMonth() + 1);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    });
    setCustDueDay(new Date().getDate().toString());
    setCustDateAdded(() => {
      const d = new Date();
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    });
    setImages({
      personal: "",
      idFront: "",
      idBack: "",
      resFront: "",
      resBack: ""
    });
    setGuarantorName("");
    setGuarantorPhone("");
    setGuarantorAddress("");
    setGuarantorGovernorate("");
    setGuarantorNearestLandmark("");
    setGuarantorNationalId("");
    setGuarantorProfession("");
    setGuarantorRelationship("");
    setGuarantorImages({
      personal: "",
      idFront: "",
      idBack: "",
      resFront: "",
      resBack: ""
    });
    setFormStep(1);
  };

  const handleResetFormWithConfirm = () => {
    setShowClearFieldsConfirm(true);
  };

  // Helper to safely cache a lightweight version of customers without heavy base64 strings
  const cacheLightweightCustomers = (customersList: Customer[]) => {
    try {
      const lightList = customersList.map(cust => {
        const lightCust = { ...cust };
        if (lightCust.images) {
          lightCust.images = {};
        }
        if (lightCust.guarantor) {
          lightCust.guarantor = { ...lightCust.guarantor };
          if (lightCust.guarantor.images) {
            lightCust.guarantor.images = {};
          }
        }
        return lightCust;
      });
      localStorage.setItem("cached_customers", JSON.stringify(lightList));
    } catch (err) {
      console.error("Failed to save lightweight customers cache to localStorage:", err);
    }
  };

  // Sync with Firebase Firestore and keep local cache updated
  useEffect(() => {
    if (!isLoggedIn) return;

    // Load from localStorage cache first for immediate UI responsiveness
    const cached = localStorage.getItem("cached_customers");
    if (cached) {
      try {
        setCustomers(JSON.parse(cached));
      } catch (e) {
        console.error("Error reading cached customers:", e);
      }
    }

    // Subscribe to real-time Firestore database updates
    const unsubscribe = subscribeToCustomers((firestoreCustomers) => {
      setCustomers(firestoreCustomers);
      cacheLightweightCustomers(firestoreCustomers);
    });

    return () => {
      unsubscribe();
    };
  }, [isLoggedIn]);

  // Subscribe to real-time system credentials changes
  useEffect(() => {
    const unsubscribe = subscribeToSystemCredentials((creds) => {
      if (creds) {
        setSystemCredentials(creds);
        localStorage.setItem("cached_system_credentials", JSON.stringify(creds));
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Register Service Worker for background capabilities
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js")
        .then((reg) => {
          console.log("Service Worker registered successfully!", reg);
        })
        .catch((err) => {
          console.error("Service Worker registration failed:", err);
        });
    }
  }, []);

  // دالة لمراقبة حالة التركيز على الحقول (إدخال أو نص) لإخفاء شريط التنقل السفلي عند فتح لوحة المفاتيح
  useEffect(() => {
    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) {
        setIsKeyboardOpen(true);
        // تمرير الحقل النشط بشكل سلس لمنتصف الشاشة لتفادي نزوله تحت لوحة المفاتيح (الكيبورد)
        setTimeout(() => {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 150);
      }
    };

    const handleFocusOut = (e: FocusEvent) => {
      setTimeout(() => {
        const activeEl = document.activeElement;
        if (!activeEl || (activeEl.tagName !== "INPUT" && activeEl.tagName !== "TEXTAREA")) {
          setIsKeyboardOpen(false);
        }
      }, 100);
    };

    document.addEventListener("focusin", handleFocusIn);
    document.addEventListener("focusout", handleFocusOut);

    // مراقبة حجم العرض المرئي (مفيد جداً على هواتف الأندرويد والآيفون عند فتح الكيبورد)
    const handleViewportResize = () => {
      if (window.visualViewport) {
        const isShrunk = window.visualViewport.height < window.innerHeight * 0.75;
        if (isShrunk) {
          setIsKeyboardOpen(true);
        } else {
          const activeEl = document.activeElement;
          if (!activeEl || (activeEl.tagName !== "INPUT" && activeEl.tagName !== "TEXTAREA")) {
            setIsKeyboardOpen(false);
          }
        }
      }
    };

    if (window.visualViewport) {
      window.visualViewport.addEventListener("resize", handleViewportResize);
    }

    return () => {
      document.removeEventListener("focusin", handleFocusIn);
      document.removeEventListener("focusout", handleFocusOut);
      if (window.visualViewport) {
        window.visualViewport.removeEventListener("resize", handleViewportResize);
      }
    };
  }, []);

  // Instant notification trigger helper
  const triggerInstantCheck = (list: Customer[]) => {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    
    const dueList = list.filter(c => isCustomerDue(c));
    
    if (dueList.length > 0) {
      const names = dueList.map(c => c.name).join("، ");
      const title = " تنبيه بالأقساط المستحقة!";
      const body = `لديك ${dueList.length} أقساط مستحقة لكل من: ${names}.`;
      
      if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: "TRIGGER_INSTALLMENT_NOTIFICATION",
          title,
          body
        });
      } else {
        new Notification(title, { body, requireInteraction: true });
      }
    } else {
      const title = " نظام التنبيهات نشط";
      const body = "لا توجد أقساط مستحقة للدفعة الحالية. سنقوم بتنبيهك تلقائياً فور استحقاق أي قسط!";
      
      if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: "TRIGGER_INSTALLMENT_NOTIFICATION",
          title,
          body
        });
      } else {
        new Notification(title, { body });
      }
    }
  };

  // Check and notify daily on customers reload or log in
  useEffect(() => {
    if (isLoggedIn && customers.length > 0 && notificationPermission === "granted") {
      const today = new Date();
      const todayString = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
      
      // Only notify automatically once per calendar day
      if (localStorage.getItem("lastNotifiedDay") !== todayString) {
        const dueList = customers.filter(c => isCustomerDue(c));
        
        if (dueList.length > 0) {
          const names = dueList.map(c => c.name).join("، ");
          const title = " تنبيه بالأقساط المستحقة!";
          const body = `لديك ${dueList.length} أقساط مستحقة لكل من: ${names}. يرجى مراجعة الجدول.`;
          
          if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
            navigator.serviceWorker.controller.postMessage({
              type: "TRIGGER_INSTALLMENT_NOTIFICATION",
              title,
              body
            });
          } else {
            new Notification(title, { body, requireInteraction: true });
          }
          localStorage.setItem("lastNotifiedDay", todayString);
        }
      }
    }
  }, [customers, isLoggedIn, notificationPermission]);

  // Request browser permission for notifications
  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) {
      showToast(" متصفحك لا يدعم الإشعارات البرمجية.", "danger");
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      if (permission === "granted") {
        showToast(" تم تفعيل نظام التنبيهات بنجاح!", "success");
        triggerInstantCheck(customers);
      } else if (permission === "denied") {
        showToast(" تم رفض استقبال الإشعارات. يرجى تعديل الإعدادات من شريط العنوان.", "danger");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Auto-set the installment day from the registration/sale date day
  useEffect(() => {
    if (custDateAdded) {
      const parts = custDateAdded.split("-");
      if (parts.length === 3) {
        const dayNum = parseInt(parts[2], 10);
        if (!isNaN(dayNum) && dayNum >= 1 && dayNum <= 31) {
          setCustDueDay(dayNum.toString());
        }
      }
    }
  }, [custDateAdded]);

  // Handle Account Recovery Submit
  // Handle Login submission
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    setIsAuthenticating(true);
    setLoginError("");

    setTimeout(() => {
      const configUsername = branding.login.username;
      const configPhone = branding.login.phone;
      const configPassword = branding.login.password;
      const allowPhone = branding.login.allowPhoneLogin;

      // Check if the input matches either the config username or the config phone (if allowed)
      const isUsernameCorrect = loginUsername.trim() === configUsername;
      const isPhoneCorrect = allowPhone && loginUsername.trim() === configPhone;
      const isPasswordCorrect = loginPassword === configPassword;

      if ((isUsernameCorrect || isPhoneCorrect) && isPasswordCorrect) {
        setIsLoggedIn(true);
        localStorage.setItem("isLoggedIn", "true");
        setLoginError("");
        setLoginUsername("");
        setLoginPassword("");
        showToast(" تم تسجيل الدخول بنجاح!", "success");
      } else {
        setLoginError(" عذراً، اسم المستخدم أو رقم الهاتف أو كلمة المرور غير صحيحة!");
        setLoginPassword("");
      }
      setIsAuthenticating(false);
    }, 1200);
  };

  // Show Toast helper
  const showToast = (message: string, type: "success" | "danger" | "info") => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 5000);
  };

  // دالة لمزامنة العمليات التي تمت بدون إنترنت تلقائياً عند عودة الاتصال (Disabled in offline-only)
  const syncOfflineQueue = async () => {};

  // تشغيل المزامنة التلقائية عند عودة الاتصال بالإنترنت أو بصفة دورية (Disabled in offline-only)
  useEffect(() => {
    // App is now completely offline-only
  }, [isLoggedIn]);

  // Utility to clean numbers from commas
  const cleanNumber = (val: string | number): number => {
    if (!val) return 0;
    return parseFloat(val.toString().replace(/,/g, "")) || 0;
  };

  // Utility to format numbers with thousands commas
  const formatNumber = (num: number): string => {
    if (num === undefined || num === null || isNaN(num)) return "0";
    return num.toLocaleString("en-US");
  };

  // Helper to format input value with commas on change
  const handleMoneyInputChange = (
    val: string,
    setter: React.Dispatch<React.SetStateAction<string>>
  ) => {
    const clean = val.replace(/,/g, "");
    if (!isNaN(parseFloat(clean)) && clean !== "") {
      setter(parseFloat(clean).toLocaleString("en-US"));
    } else if (clean === "") {
      setter("");
    }
  };

  // --- THERMAL PRINTING AND EXPORT HELPERS ---

  // Draws dynamic 80mm receipt as high-resolution PNG Data URL via Canvas
  const drawThermalReceipt = (data: {
    title: string;
    customerName: string;
    customerPhone: string;
    productName: string;
    totalAmount: number;
    upfront?: number;
    paidAmount?: number;
    remainingAmount: number;
    monthlyAmount?: number;
    dueDay?: number;
    date: string;
    nextDueDate?: string;
  }): string => {
    const is58mm = printerPaperSize === "58mm";
    const width = is58mm ? 384 : 576; // Dynamic printable width
    const scale = is58mm ? 0.82 : 1.15; // Enhanced scale sweet spot for superb readability without excessive length

    const tempCanvas = document.createElement("canvas");
    tempCanvas.width = width;
    tempCanvas.height = 2000; // Standard safe height ceiling
    const ctx = tempCanvas.getContext("2d");
    if (!ctx) return "";

    // Set white background
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);

    ctx.fillStyle = "#000000";
    ctx.strokeStyle = "#000000";
    ctx.direction = "rtl";
    
    let y = Math.round(40 * scale);

    // Thicker text utility to emulate physical boldness on older thermal print heads with optional color
    const drawText = (text: string, x: number, targetY: number, font: string, align: "center" | "left" | "right" = "center", color = "#000000") => {
      ctx.font = font;
      ctx.textAlign = align;
      ctx.fillStyle = color;
      ctx.fillText(text, x, targetY);
      
      if (printerThickness > 1 && color === "#000000") {
        ctx.strokeStyle = "#000000";
        const sizeMatch = font.match(/(\d+)px/);
        const fontSize = sizeMatch ? parseInt(sizeMatch[1], 10) : 20;
        ctx.lineWidth = (printerThickness - 1) * 0.35 * (fontSize / 24) * scale;
        ctx.strokeText(text, x, targetY);
      }
    };

    // Draw Header Store Name (Enlarged and outstanding)
    drawText(`${branding.shopName}`, width / 2, y, `bold ${Math.round(activeTemplate.fontSizes.shopName * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(activeTemplate.paddings.shopNameBottom * scale);

    drawText(`رقم الهاتف: ${branding.phone}`, width / 2, y, `bold ${Math.round(activeTemplate.fontSizes.shopPhone * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(activeTemplate.paddings.shopPhoneBottom * scale);

    // Draw separator line
    ctx.lineWidth = Math.round((2.5 + printerThickness * 0.5) * scale) || 1.5;
    ctx.beginPath();
    ctx.moveTo(Math.round(15 * scale), y);
    ctx.lineTo(width - Math.round(15 * scale), y);
    ctx.stroke();
    y += Math.round(30 * scale);

    // Draw Title of receipt (Enlarged)
    drawText(data.title, width / 2, y, `bold ${Math.round(activeTemplate.fontSizes.title * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(activeTemplate.paddings.titleBottom * scale);

    // Center-aligned beautifully highlighted Date
    const dateSize = Math.round(activeTemplate.fontSizes.customerName * 0.7 * scale);
    drawText(`📅 تاريخ الوصل: ${data.date}`, width / 2, y, `bold ${dateSize}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(42 * scale);
    
    y += Math.round(15 * scale);

    // Centered & Prominent Customer Data Card/Box (Dashed frame)
    ctx.lineWidth = Math.round(2 * scale);
    ctx.strokeStyle = "#000000";
    ctx.setLineDash([Math.round(6 * scale), Math.round(4 * scale)]);
    const boxHeight = Math.round((28 + 38 + activeTemplate.paddings.customerCardBottom + (activeTemplate.paddings.customerCardBottom * 0.9) + 20) * scale);
    ctx.strokeRect(Math.round(15 * scale), y - Math.round(10 * scale), width - Math.round(30 * scale), boxHeight);
    ctx.setLineDash([]); // Reset dashed line style
    
    y += Math.round(28 * scale);
    drawText("👤 بيانات الزبون والطلب 👤", width / 2, y, `bold ${Math.round(activeTemplate.fontSizes.financialLabel * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(38 * scale);
    
    drawText(data.customerName, width / 2, y, `bold ${Math.round(activeTemplate.fontSizes.customerName * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(activeTemplate.paddings.customerCardBottom * scale);
    
    // Large, highly readable Phone Number
    drawText(`رقم الهاتف: ${data.customerPhone}`, width / 2, y, `bold ${Math.round(activeTemplate.fontSizes.customerPhone * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(activeTemplate.paddings.customerCardBottom * 0.9 * scale);
    
    drawText(`المادة/الجهاز: ${data.productName}`, width / 2, y, `bold ${Math.round(activeTemplate.fontSizes.productName * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "center");
    y += Math.round(activeTemplate.paddings.productBottom * scale);

    // separator line
    ctx.beginPath();
    ctx.moveTo(Math.round(15 * scale), y);
    ctx.lineTo(width - Math.round(15 * scale), y);
    ctx.stroke();
    y += Math.round(38 * scale);

    // Financial info
    const drawRow = (label: string, value: string) => {
      const labelFont = `bold ${Math.round(activeTemplate.fontSizes.financialLabel * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`;
      const valueFont = `bold ${Math.round(activeTemplate.fontSizes.financialValue * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`; // Highlighted and enlarged values/numbers
      drawText(label, width - Math.round(20 * scale), y, labelFont, "right");
      drawText(value, Math.round(20 * scale), y, valueFont, "left");
      y += Math.round(activeTemplate.paddings.financialRowBottom * scale);
    };

    drawRow("مبلغ الجهاز الكلي:", `${formatNumber(data.totalAmount)} د.ع`);
    if (data.upfront !== undefined) {
      drawRow("المقدمة المدفوعة:", `${formatNumber(data.upfront)} د.ع`);
    }
    
    if (data.paidAmount !== undefined) {
      // Draw a neat box around paid amount
      const pValSize = activeTemplate.fontSizes.financialValue + 3;
      const boxH = Math.round((pValSize + 30) * scale);
      ctx.lineWidth = Math.round((2.5 + printerThickness * 0.5) * scale) || 1.5;
      ctx.strokeRect(Math.round(15 * scale), y - Math.round(10 * scale), width - Math.round(30 * scale), boxH);
      
      const pLabelFont = `bold ${Math.round(activeTemplate.fontSizes.financialLabel * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`;
      const pValueFont = `bold ${Math.round(pValSize * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`; // Enlarged paid amount
      
      drawText("المبلغ المسدد الحالي:", width - Math.round(25 * scale), y + Math.round((pValSize - 3) * scale), pLabelFont, "right");
      drawText(`${formatNumber(data.paidAmount)} د.ع`, Math.round(25 * scale), y + Math.round((pValSize - 3) * scale), pValueFont, "left");
      y += Math.round((pValSize + 40) * scale);
    }

    // Highlight Remaining Amount with an elegant, highly visible compact box
    const rValSize = activeTemplate.fontSizes.financialValue + 7;
    const rBoxH = Math.round((rValSize + 32) * scale);
    ctx.lineWidth = Math.round((3.5 + printerThickness * 0.5) * scale) || 2.5;
    ctx.strokeRect(Math.round(15 * scale), y - Math.round(10 * scale), width - Math.round(30 * scale), rBoxH);
    
    const remLabelFont = `bold ${Math.round((activeTemplate.fontSizes.financialLabel + 1) * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`;
    const remValueFont = `bold ${Math.round(rValSize * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`; // Magnified critical number
    
    drawText("المتبقي بذمة العميل:", width - Math.round(25 * scale), y + Math.round((rValSize - 1) * scale), remLabelFont, "right");
    drawText(`${formatNumber(data.remainingAmount)} د.ع`, Math.round(25 * scale), y + Math.round((rValSize - 1) * scale), remValueFont, "left");
    y += Math.round((rValSize + 44) * scale);
    
    if (data.nextDueDate) {
      y += Math.round(8 * scale);
      
      // Compact solid black background block for high visibility Next Due Date
      ctx.fillStyle = "#000000";
      const bannerHeight = Math.round(activeTemplate.paddings.dueBannerBottom * scale);
      ctx.fillRect(Math.round(15 * scale), y - Math.round(8 * scale), width - Math.round(30 * scale), bannerHeight);
      
      // Beautiful high-contrast white text on top of the black banner
      const textYOffset = Math.round((bannerHeight / 2 + 5) * scale);
      drawText("📅 الاستحقاق القادم:", width - Math.round(28 * scale), y + textYOffset, `bold ${Math.round(activeTemplate.fontSizes.dueBannerLabel * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "right", "#FFFFFF");
      drawText(data.nextDueDate, Math.round(28 * scale), y + textYOffset, `bold ${Math.round(activeTemplate.fontSizes.dueBannerValue * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`, "left", "#FFFFFF");
      
      y += bannerHeight + Math.round(15 * scale);
    }

    // separator line
    ctx.beginPath();
    ctx.moveTo(Math.round(15 * scale), y);
    ctx.lineTo(width - Math.round(15 * scale), y);
    ctx.stroke();
    y += Math.round(35 * scale);

    // Footer message
    const fFont = `bold ${Math.round(activeTemplate.fontSizes.footer * scale)}px 'Cairo', 'Segoe UI', 'Arial', sans-serif`;
    drawText("شكرًا لتعاملكم معنا. يرجى الاحتفاظ بالوصل.", width / 2, y, fFont, "center");
    y += Math.round(48 * scale);

    // Crop canvas to fit exact dynamic content height
    const finalCanvas = document.createElement("canvas");
    finalCanvas.width = width;
    finalCanvas.height = y;
    const finalCtx = finalCanvas.getContext("2d");
    if (finalCtx) {
      finalCtx.fillStyle = "#FFFFFF";
      finalCtx.fillRect(0, 0, width, y);
      finalCtx.drawImage(tempCanvas, 0, 0);
      return finalCanvas.toDataURL("image/png");
    }

    return tempCanvas.toDataURL("image/png");
  };

  // Opens a print page containing ONLY the rendered 80mm canvas image to guarantee crisp thermal print with no margins
  const printThermalImage = (imageUrl: string) => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      showToast(" يرجى السماح بالنوافذ المنبثقة لطباعة الوصل!", "danger");
      return;
    }
    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <title>طباعة وصل حراري</title>
        <style>
          @page {
            size: 80mm auto;
            margin: 0;
          }
          body {
            margin: 0;
            padding: 2mm;
            background: #ffffff;
            display: flex;
            justify-content: center;
            align-items: flex-start;
          }
          img {
            width: 76mm;
            height: auto;
            display: block;
          }
          @media print {
            body {
              padding: 0;
            }
            img {
              width: 80mm;
            }
          }
        </style>
      </head>
      <body>
        <img src="${imageUrl}" />
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
              setTimeout(function() {
                window.close();
              }, 500);
            }, 300);
          }
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Connect to Bluetooth Printer
  const connectBluetoothPrinter = async () => {
    if (!("bluetooth" in navigator)) {
      showToast(" متصفحك الحالي لا يدعم تقنية Web Bluetooth. يرجى استخدام متصفح Google Chrome أو Edge على الكمبيوتر أو الاندرويد.", "danger");
      return;
    }
    setIsBluetoothConnecting(true);
    setBluetoothPermissionError(false);
    try {
      showToast("⏳ جاري البحث عن أجهزة بلوتوث قريبة...", "info");
      
      let options: any = {};
      if (filterBluetoothPrintersOnly) {
        options = {
          filters: [
            // Standard thermal printer GATT services
            { services: ["000018f0-0000-1000-8000-00805f9b34fb"] },
            { services: ["0000e7e1-0000-1000-8000-00805f9b34fb"] },
            { services: ["0000ff00-0000-1000-8000-00805f9b34fb"] },
            { services: ["000018f1-0000-1000-8000-00805f9b34fb"] },
            // Common thermal printer Bluetooth name prefixes
            { namePrefix: "MPT" },
            { namePrefix: "MTP" },
            { namePrefix: "PRT" },
            { namePrefix: "Zjiang" },
            { namePrefix: "PT" },
            { namePrefix: "RP" },
            { namePrefix: "QS" },
            { namePrefix: "Printer" },
            { namePrefix: "printer" },
            { namePrefix: "Thermal" },
            { namePrefix: "POS" },
            { namePrefix: "XP" },
            { namePrefix: "JP" },
            { namePrefix: "SP" },
            { namePrefix: "BT" },
            { namePrefix: "Gprinter" },
            { namePrefix: "Print" },
            { namePrefix: "T9" },
            { namePrefix: "ZJ" }
          ],
          optionalServices: [
            "000018f0-0000-1000-8000-00805f9b34fb", // common printing GATT service 18f0
            "0000e7e1-0000-1000-8000-00805f9b34fb", // e7e1
            "0000ff00-0000-1000-8000-00805f9b34fb", // ff00
            "49535343-fe7d-4100-8b53-111a91e16422", // ISSC Microchip
            "e7e1a000-aced-436c-905a-fc87b090c0f4",
            "000018f1-0000-1000-8000-00805f9b34fb"
          ]
        };
      } else {
        options = {
          acceptAllDevices: true,
          optionalServices: [
            "000018f0-0000-1000-8000-00805f9b34fb", // common printing GATT service 18f0
            "0000e7e1-0000-1000-8000-00805f9b34fb", // e7e1
            "0000ff00-0000-1000-8000-00805f9b34fb", // ff00
            "49535343-fe7d-4100-8b53-111a91e16422", // ISSC Microchip
            "e7e1a000-aced-436c-905a-fc87b090c0f4",
            "000018f1-0000-1000-8000-00805f9b34fb"
          ]
        };
      }

      const device = await (navigator.bluetooth as any).requestDevice(options);

      showToast(` جاري الاتصال بـ: ${device.name || "طابعة غير معروفة"}...`, "info");
      const server = await device.gatt.connect();
      
      let writeChar: any = null;
      const services = await server.getPrimaryServices();
      for (const service of services) {
        try {
          const characteristics = await service.getCharacteristics();
          for (const char of characteristics) {
            if (char.properties.write || char.properties.writeWithoutResponse) {
              writeChar = char;
              break;
            }
          }
        } catch (e) {
          console.warn("Error getting characteristics:", e);
        }
        if (writeChar) break;
      }

      if (!writeChar) {
        throw new Error("لم نتمكن من العثور على خاصية الكتابة/الطباعة (write characteristic) في الطابعة.");
      }

      setBluetoothDevice({
        device,
        server,
        characteristic: writeChar,
        name: device.name || "طابعة حرارية"
      });
      showToast(` تم ربط طابعة البلوتوث بنجاح: ${device.name || "طابعة حرارية"}`, "success");
    } catch (err: any) {
      const errMsg = err?.message?.toLowerCase() || "";
      const errName = err?.name || "";
      const isCancelled = errMsg.includes("cancel") || errName === "NotFoundError" || errName === "AbortError";
      const isPolicyBlocked = errMsg.includes("permissions policy") || 
                              errMsg.includes("disallowed by permissions policy") || 
                              errName === "SecurityError";
      
      if (isCancelled) {
        console.log("Bluetooth pairing cancelled by user:", err);
        showToast("ℹ تم إلغاء البحث عن طابعة البلوتوث.", "info");
      } else if (isPolicyBlocked) {
        console.warn("Bluetooth policy blocked:", err);
        setBluetoothPermissionError(true);
        showToast(" أمان المتصفح يمنع البلوتوث داخل الإطار! يرجى فتح التطبيق في نافذة خارجية.", "danger");
      } else {
        console.error("Bluetooth pairing error:", err);
        showToast(` فشل الاتصال بالطابعة: ${err?.message || "تم إلغاء العملية"}`, "danger");
      }
    } finally {
      setIsBluetoothConnecting(false);
    }
  };

  // Print a simple ASCII test page to verify Bluetooth connection
  const printBluetoothTestPage = async () => {
    if (!bluetoothDevice || !bluetoothDevice.characteristic) {
      showToast(" يرجى ربط طابعة البلوتوث أولاً!", "info");
      return;
    }
    try {
      showToast("⏳ جاري إرسال صفحة اختبار الاتصال...", "info");
      const escposData: number[] = [];
      // Initialize printer: ESC @
      escposData.push(0x1B, 0x40);
      
      // Center align: ESC a 1
      escposData.push(0x1B, 0x61, 0x01);
      
      // Double height and double width: ESC ! 56
      escposData.push(0x1B, 0x21, 0x38);
      const header = "\nAL-SAHL SYSTEM\n";
      for (let i = 0; i < header.length; i++) {
        escposData.push(header.charCodeAt(i));
      }
      
      // Normal size, bold: ESC ! 8
      escposData.push(0x1B, 0x21, 0x08);
      const sub = "PRINTER TEST PAGE\n";
      for (let i = 0; i < sub.length; i++) {
        escposData.push(sub.charCodeAt(i));
      }
      
      // Normal size, regular: ESC ! 0
      escposData.push(0x1B, 0x21, 0x00);
      const divider = "--------------------------------\n";
      for (let i = 0; i < divider.length; i++) {
        escposData.push(divider.charCodeAt(i));
      }
      
      const lines = [
        "Device: " + (bluetoothDevice.name || "Thermal Printer") + "\n",
        "Connection: SUCCESSFUL / ناجح\n",
        "Paper Width: " + printerPaperSize + "\n",
        "Date: " + new Date().toLocaleDateString("en-US") + "\n",
      ];
      
      for (const line of lines) {
        for (let i = 0; i < line.length; i++) {
          escposData.push(line.charCodeAt(i));
        }
      }
      
      const footerDivider = "--------------------------------\n";
      for (let i = 0; i < footerDivider.length; i++) {
        escposData.push(footerDivider.charCodeAt(i));
      }
      
      // Center alignment
      escposData.push(0x1B, 0x61, 0x01);
      const footer = "Ready to Print Invoices!\n\n\n\n";
      for (let i = 0; i < footer.length; i++) {
        escposData.push(footer.charCodeAt(i));
      }
      
      // Feed paper 4 lines
      escposData.push(0x1B, 0x64, 0x04);
      // Partial cut command
      escposData.push(0x1D, 0x56, 0x42, 0x00);

      const uint8Data = new Uint8Array(escposData);
      const chunkSize = 128;
      for (let offset = 0; offset < uint8Data.length; offset += chunkSize) {
        const chunk = uint8Data.slice(offset, offset + chunkSize);
        await bluetoothDevice.characteristic.writeValue(chunk);
      }
      showToast(" تم طباعة صفحة الاختبار بنجاح!", "success");
    } catch (err: any) {
      console.error("Test page print error:", err);
      showToast(` فشل طباعة صفحة الاختبار: ${err?.message || "مشكلة في التوصيل"}`, "danger");
    }
  };

  // Convert canvas/image URL into ESC/POS bitmap & print via Web Bluetooth
  const printViaBluetoothDirect = async (imageUrl: string) => {
    if (!bluetoothDevice || !bluetoothDevice.characteristic) {
      showToast(" يرجى ربط طابعة البلوتوث أولاً!", "info");
      await connectBluetoothPrinter();
      return;
    }

    showToast("⏳ جاري تحضير وتنسيق الصورة لطباعة فائقة السرعة والوضوح...", "info");

    try {
      const img = new Image();
      img.src = imageUrl;
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });

      // Scale the receipt based on selected printer paper size to achieve pixel-to-pixel perfect print with no scaling artifacts!
      const is58mm = printerPaperSize === "58mm";
      const printWidth = is58mm ? 384 : 576;
      const printHeight = Math.round((img.height / img.width) * printWidth);

      const canvas = document.createElement("canvas");
      canvas.width = printWidth;
      canvas.height = printHeight;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Could not initialize canvas context");

      // Disable image smoothing to prevent anti-aliasing blur and get razor-sharp pixel edges
      ctx.imageSmoothingEnabled = false;

      // Draw white background then the receipt image
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, printWidth, printHeight);
      ctx.drawImage(img, 0, 0, printWidth, printHeight);

      const imgData = ctx.getImageData(0, 0, printWidth, printHeight);
      const pixels = imgData.data;

      // Pack pixels to 1-bit bitmap array using safe horizontal slicing.
      // Slicing into bands of 40 pixels prevents printer RAM/buffer overflow
      // on low-cost thermal printers and ensures stable, non-squished printing!
      const widthBytes = printWidth / 8; // 384 / 8 = 48 bytes OR 576 / 8 = 72 bytes per row
      const height = printHeight;

      const escposData: number[] = [];

      // Initialize printer: ESC @
      escposData.push(0x1B, 0x40);

      // Line spacing 24 dots: ESC 3 24
      escposData.push(0x1B, 0x33, 0x18);

      const sliceHeight = 40;
      for (let yStart = 0; yStart < height; yStart += sliceHeight) {
        const currentSliceHeight = Math.min(sliceHeight, height - yStart);

        // Raster Bit Image Command: GS v 0 0 xL xH yL yH
        escposData.push(0x1D, 0x76, 0x30, 0x00);
        escposData.push(widthBytes & 0xFF, (widthBytes >> 8) & 0xFF);
        escposData.push(currentSliceHeight & 0xFF, (currentSliceHeight >> 8) & 0xFF);

        // Binary thresholding for this slice
        for (let yOffset = 0; yOffset < currentSliceHeight; yOffset++) {
          const y = yStart + yOffset;
          for (let xByte = 0; xByte < widthBytes; xByte++) {
            let byteVal = 0;
            for (let bit = 0; bit < 8; bit++) {
              const xPixel = xByte * 8 + bit;
              const pixelIndex = (y * printWidth + xPixel) * 4;
              
              const r = pixels[pixelIndex];
              const g = pixels[pixelIndex + 1];
              const b = pixels[pixelIndex + 2];
              const a = pixels[pixelIndex + 3];

              // If transparent alpha, treat as white
              const luminance = a < 50 ? 255 : (0.299 * r + 0.587 * g + 0.114 * b);
              
              // Dark pixel becomes 1 (black dot)
              if (luminance < printerThreshold) {
                byteVal |= (1 << (7 - bit));
              }
            }
            escposData.push(byteVal);
          }
        }
      }

      // Feed paper (ESC d 5: feed 5 lines) and cut: GS V 66 0
      escposData.push(0x1B, 0x64, 0x05); // Feed 5 lines
      escposData.push(0x1D, 0x56, 0x42, 0x00); // Partial cut

      const uint8Data = new Uint8Array(escposData);

      // Send chunks with a safe delay to prevent GATT and hardware buffer overflow
      const chunkSize = 128; 
      showToast(` جاري إرسال الوصل للطباعة الفورية... 0%`, "info");

      for (let offset = 0; offset < uint8Data.length; offset += chunkSize) {
        const chunk = uint8Data.slice(offset, offset + chunkSize);
        await bluetoothDevice.characteristic.writeValue(chunk);
        
        const pct = Math.round((offset / uint8Data.length) * 100);
        if (pct % 25 === 0) {
          showToast(` جاري الإرسال... ${pct}%`, "info");
        }
        
        // 15ms is highly optimized, safe, and prevents data loss on all devices
        await new Promise(resolve => setTimeout(resolve, 15));
      }

      showToast(" تم إرسال الأمر وطباعة الفاتورة الحرارية بنجاح وسرعة فائقة!", "success");
    } catch (err: any) {
      console.error("Bluetooth print error:", err);
      showToast(` فشل إرسال البيانات للطباعة: ${err?.message || "مشكلة في التوصيل"}`, "danger");
    }
  };

  // Formats a line with left and right aligned columns for direct text printing
  const formatReceiptLineForPrinter = (leftText: string, rightText: string, widthChars = 32): string => {
    const isArabic = (c: string) => /[\u0600-\u06FF]/.test(c);
    
    const shapeWord = (w: string) => {
      const arabicMap: { [key: string]: string[] } = {
        'ا': ['ﺍ', 'ﺎ', 'ﺎ', 'ﺍ'], 'أ': ['ﺃ', 'ﺄ', 'ﺄ', 'ﺃ'], 'إ': ['ﺇ', 'ﺈ', 'ﺈ', 'ﺇ'], 'آ': ['ﺁ', 'ﺂ', 'ﺂ', 'ﺁ'],
        'ب': ['ﺏ', 'ﺐ', 'ﺒ', 'ﺑ'], 'ت': ['ﺕ', 'ﺖ', 'ﺘ', 'ﺗ'], 'ث': ['ﺙ', 'ﺚ', 'ﺜ', 'ﺛ'], 'ج': ['ﺝ', 'ﺞ', 'ﺠ', 'ﺟ'],
        'ح': ['ﺡ', 'ﺢ', 'ﺤ', 'ﺣ'], 'خ': ['ﺥ', 'ﺦ', 'ﺨ', 'ﺧ'], 'د': ['ﺩ', 'ﺪ', 'ﺪ', 'ﺩ'], 'ذ': ['ﺫ', 'ﺬ', 'ﺬ', 'ﺫ'],
        'ر': ['ﺭ', 'ﺮ', 'ﺮ', 'ﺭ'], 'ز': ['ﺯ', 'ﺰ', 'ﺰ', 'ﺯ'], 'س': ['ﺱ', 'ﺲ', 'ﺴ', 'ﺳ'], 'ش': ['ﺵ', 'ﺶ', 'ﺸ', 'ﺷ'],
        'ص': ['ﺹ', 'ﺺ', 'ﺼ', 'ﺻ'], 'ض': ['ﺽ', 'ﺾ', 'ﻀ', 'ﺿ'], 'ط': ['ﻁ', 'ﻂ', 'ﻄ', 'ﻃ'], 'ظ': ['ﻅ', 'ﻆ', 'ﻈ', 'ﻇ'],
        'ع': ['ﻉ', 'ﻊ', 'ﻌ', 'ﻋ'], 'غ': ['ﻍ', 'ﻎ', 'ﻐ', 'ﻏ'], 'ف': ['ﻑ', 'ﻒ', 'ﻔ', 'ﻓ'], 'ق': ['ﻕ', 'ﻖ', 'ﻘ', 'ﻗ'],
        'ك': ['ﻙ', 'ﻚ', 'ﻜ', 'ﻛ'], 'ل': ['ﻝ', 'ﻞ', 'ﻠ', 'ﻟ'], 'م': ['ﻡ', 'ﻢ', 'ﻤ', 'ﻣ'], 'ن': ['ﻥ', 'ﻦ', 'ﻨ', 'ﻧ'],
        'ه': ['ﻩ', 'ﻪ', 'ﻬ', 'ﻫ'], 'و': ['ﻭ', 'ﻮ', 'ﻮ', 'ﻭ'], 'ي': ['ﻱ', 'ﻲ', 'ﻴ', 'ﻳ'], 'ى': ['ﻯ', 'ﻰ', 'ﻰ', 'ﻯ'],
        'ة': ['ﺓ', 'ﺔ', 'ﺔ', 'ﺓ'], 'ؤ': ['ﺅ', 'ﺆ', 'ﺆ', 'ﺅ'], 'ئ': ['ﺉ', 'ﺊ', 'ﺌ', 'ﺋ']
      };
      
      let shaped = "";
      for (let i = 0; i < w.length; i++) {
        const c = w[i];
        if (arabicMap[c]) {
          const prev = w[i - 1];
          const next = w[i + 1];
          const hasPrev = prev && isArabic(prev) && !"اأإآدذرعوؤة".includes(prev);
          const hasNext = next && isArabic(next);
          
          if (hasPrev && hasNext) shaped += arabicMap[c][2];
          else if (hasPrev) shaped += arabicMap[c][1];
          else if (hasNext) shaped += arabicMap[c][3];
          else shaped += arabicMap[c][0];
        } else {
          shaped += c;
        }
      }
      
      if (isArabic(w)) {
        return shaped.split("").reverse().join("");
      }
      return w;
    };

    const processPart = (text: string) => {
      return text.split(/(\s+)/).map(p => {
        if (/\s+/.test(p)) return p;
        return shapeWord(p);
      }).join("");
    };

    const shapedLeft = processPart(leftText);
    const shapedRight = processPart(rightText);

    // Filter non-printing chars length for padding
    const leftLen = leftText.length;
    const rightLen = rightText.length;
    const spacesCount = Math.max(1, widthChars - (leftLen + rightLen));
    
    return shapedLeft + " ".repeat(spacesCount) + shapedRight;
  };

  // Encodes strings to standard CP1256 (Arabic) byte values
  const encodeCP1256 = (str: string): Uint8Array => {
    const bytes: number[] = [];
    const charMap: { [key: string]: number } = {
      ' ': 0x20, '!': 0x21, '"': 0x22, '#': 0x23, '$': 0x24, '%': 0x25, '&': 0x26, '\'': 0x27, '(': 0x28, ')': 0x29,
      '*': 0x2A, '+': 0x2B, ',': 0x2C, '-': 0x2D, '.': 0x2E, '/': 0x2F, ':': 0x3A, ';': 0x3B, '<': 0x3C, '=': 0x3D,
      '>': 0x3E, '?': 0x3F, '@': 0x40, '_': 0x5F, '\n': 0x0A, '\r': 0x0D,
      '0': 0x30, '1': 0x31, '2': 0x32, '3': 0x33, '4': 0x34, '5': 0x35, '6': 0x36, '7': 0x37, '8': 0x38, '9': 0x39,
      '٠': 0x30, '١': 0x31, '٢': 0x32, '٣': 0x33, '٤': 0x34, '٥': 0x35, '٦': 0x36, '٧': 0x37, '٨': 0x38, '٩': 0x39,
      'ء': 0xC1, 'آ': 0xC2, 'أ': 0xC3, 'ؤ': 0xC4, 'إ': 0xC5, 'ئ': 0xC6, 'ا': 0xC7, 'ب': 0xC8, 'ة': 0xC9, 'ت': 0xCA,
      'ث': 0xCB, 'ج': 0xCC, 'ح': 0xCD, 'خ': 0xCE, 'د': 0xCF, 'ذ': 0xD0, 'ر': 0xD1, 'ز': 0xD2, 'س': 0xD3, 'ش': 0xD4,
      'ص': 0xD5, 'ض': 0xD6, 'ط': 0xD8, 'ظ': 0xD9, 'ع': 0xDA, 'غ': 0xDB, 'ف': 0xFA, 'ق': 0xFB, 'ك': 0xFC, 'ل': 0xFD,
      'م': 0xFE, 'ن': 0xE1, 'ه': 0xE2, 'و': 0xE3, 'ى': 0xE4, 'ي': 0xE5
    };

    const presentationMap: { [key: string]: string } = {
      'ﺁ': 'آ', 'ﺂ': 'آ', 'ﺃ': 'أ', 'ﺄ': 'أ', 'ﺅ': 'ؤ', 'ﺆ': 'ؤ', 'ﺇ': 'إ', 'ﺈ': 'إ', 'ﺉ': 'ئ', 'ﺊ': 'ئ',
      'ﺋ': 'ئ', 'ﺍ': 'ا', 'ﺎ': 'ا', 'ﺏ': 'ب', 'ﺐ': 'ب', 'ﺑ': 'ب', 'ﺒ': 'ب', 'ﺓ': 'ة', 'ﺔ': 'ة',
      'ﺕ': 'ت', 'ﺖ': 'ت', 'ﺗ': 'ت', 'ﺘ': 'ت', 'ﺙ': 'ث', 'ﺚ': 'ث', 'ﺛ': 'ث', 'ﺜ': 'ث', 'ﺝ': 'ج', 'ﺞ': 'ج',
      'ﺟ': 'ج', 'ﺠ': 'ج', 'ﺡ': 'ح', 'ﺢ': 'ح', 'ﺣ': 'ح', 'ﺤ': 'ح', 'ﺥ': 'خ', 'ﺦ': 'خ', 'ﺧ': 'خ', 'ﺨ': 'خ',
      'ﺩ': 'د', 'ﺪ': 'د', 'ﺫ': 'ذ', 'ﺬ': 'ذ', 'ﺭ': 'ر', 'ﺮ': 'ر', 'ﺯ': 'ز', 'ﺰ': 'ز', 'ﺱ': 'س', 'ﺲ': 'س',
      'ﺳ': 'س', 'ﺴ': 'س', 'ﺵ': 'ش', 'ﺶ': 'ش', 'ﺷ': 'ش', 'ﺸ': 'ش', 'ﺹ': 'ص', 'ﺺ': 'ص', 'ﺻ': 'ص', 'ﺼ': 'ص',
      'ﺽ': 'ض', 'ﺿ': 'ض', 'ض': 'ض', 'ﻁ': 'ط', 'ﻂ': 'ط', 'ﻃ': 'ط', 'ﻄ': 'ط', 'ﻅ': 'ظ', 'ﻆ': 'ظ',
      'ﻇ': 'ظ', 'ﻈ': 'ظ', 'ﻉ': 'ع', 'ﻊ': 'ع', 'ﻋ': 'ع', 'ﻌ': 'ع', 'ﻍ': 'غ', 'ﻎ': 'غ', 'ﻏ': 'غ', 'ﻐ': 'غ',
      'ﻑ': 'ف', 'ﻒ': 'ف', 'ﻓ': 'ف', 'ﻔ': 'ف', 'ﻕ': 'ق', 'ﻖ': 'ق', 'ﻗ': 'ق', 'ق': 'ق', 'ﻙ': 'ك', 'ﻚ': 'ك',
      'ﻛ': 'ك', 'ﻜ': 'ك', 'ﻝ': 'ل', 'ﻞ': 'ل', 'ﻟ': 'ل', 'ﻠ': 'ل', 'ﻡ': 'م', 'ﻢ': 'م', 'ﻣ': 'م', 'ﻤ': 'م',
      'ﻥ': 'ن', 'ﻦ': 'ن', 'ﻧ': 'ن', 'ﻨ': 'ن', 'ﻩ': 'ه', 'ﻪ': 'ه', 'ﻫ': 'ه', 'ﻬ': 'ه', 'ﻭ': 'و', 'ﻮ': 'و',
      'ﻯ': 'ى', 'ﻰ': 'ى', 'ﻱ': 'ي', 'ﻲ': 'ي', 'ﻳ': 'ي', 'ﻴ': 'ي'
    };

    for (let i = 0; i < str.length; i++) {
      let char = str[i];
      if (presentationMap[char]) {
        char = presentationMap[char];
      }

      if (charMap[char] !== undefined) {
        bytes.push(charMap[char]);
      } else {
        const code = char.charCodeAt(0);
        if (code < 128) {
          bytes.push(code);
        } else {
          bytes.push(0x3F); 
        }
      }
    }
    return new Uint8Array(bytes);
  };

  // Direct print over Bluetooth using a customized, ultra-crisp Cairo text layout rendered to a 1-bit bitmap
  const printViaBluetoothText = async (data: {
    title: string;
    customerName: string;
    customerPhone: string;
    productName: string;
    totalAmount: number;
    upfront?: number;
    paidAmount?: number;
    remainingAmount: number;
    monthlyAmount?: number;
    dueDay?: number;
    date: string;
    nextDueDate?: string;
  }) => {
    if (!bluetoothDevice || !bluetoothDevice.characteristic) {
      showToast(" يرجى ربط طابعة البلوتوث أولاً!", "info");
      await connectBluetoothPrinter();
      return;
    }

    showToast("⏳ جاري صياغة النص العربي وتنسيقه للطباعة فائقة السرعة...", "info");

    try {
      // Force load the 'Cairo' font to guarantee it is ready and crisp
      try {
        await document.fonts.load("bold 24px 'Cairo'");
        await document.fonts.ready;
      } catch (fontErr) {
        console.warn("Could not load Cairo font explicitly, using fallback:", fontErr);
      }

      const is58mm = printerPaperSize === "58mm";
      const width = is58mm ? 384 : 576; // Dynamic printable width
      const scale = is58mm ? 0.72 : 1.0; // Scaled font and padding layout to fit 58mm perfectly

      const tempCanvas = document.createElement("canvas");
      tempCanvas.width = width;
      tempCanvas.height = 1600; // Large height, will be cropped
      const ctx = tempCanvas.getContext("2d");
      if (!ctx) throw new Error("Could not initialize canvas context");

      // Set white background
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);

      ctx.fillStyle = "#000000";
      ctx.strokeStyle = "#000000";
      ctx.direction = "rtl";

      let y = Math.round(50 * scale);

      // Thicker text utility to emulate physical boldness on older thermal print heads
      const drawText = (text: string, x: number, targetY: number, font: string, align: "center" | "left" | "right" = "center") => {
        ctx.font = font;
        ctx.textAlign = align;
        ctx.fillStyle = "#000000";
        ctx.fillText(text, x, targetY);
        
        if (printerThickness > 1) {
          ctx.strokeStyle = "#000000";
          const sizeMatch = font.match(/(\d+)px/);
          const fontSize = sizeMatch ? parseInt(sizeMatch[1], 10) : 20;
          ctx.lineWidth = (printerThickness - 1) * 0.35 * (fontSize / 24) * scale;
          ctx.strokeText(text, x, targetY);
        }
      };

      // Draw Header Store Name (Big and Bold Cairo)
      drawText(`${branding.shopName}`, width / 2, y, `bold ${Math.round(34 * scale)}px 'Cairo', sans-serif`, "center");
      y += Math.round(50 * scale);

      drawText(`رقم الهاتف: ${branding.phone}`, width / 2, y, `bold ${Math.round(22 * scale)}px 'Cairo', sans-serif`, "center");
      y += Math.round(40 * scale);

      // Separator
      ctx.lineWidth = Math.round((2 + printerThickness * 0.5) * scale) || 1;
      ctx.beginPath();
      ctx.moveTo(Math.round(20 * scale), y);
      ctx.lineTo(width - Math.round(20 * scale), y);
      ctx.stroke();
      y += Math.round(40 * scale);

      // Title
      drawText(`[ ${data.title} ]`, width / 2, y, `bold ${Math.round(28 * scale)}px 'Cairo', sans-serif`, "center");
      y += Math.round(50 * scale);

      // Rows helper
      const drawTextRow = (label: string, val: string) => {
        const isNumber = val.includes("د.ع") || val.match(/\d+/) || label.includes("الهاتف");
        const labelFont = `bold ${Math.round(22 * scale)}px 'Cairo', sans-serif`;
        const valueFont = `bold ${Math.round(isNumber ? 26 * scale : 22 * scale)}px 'Cairo', sans-serif`;
        drawText(label, width - Math.round(25 * scale), y, labelFont, "right");
        drawText(val, Math.round(25 * scale), y, valueFont, "left");
        y += Math.round(50 * scale);
      };

      drawTextRow("التاريخ:", data.date);
      drawTextRow("اسم الزبون:", data.customerName);
      drawTextRow("رقم الهاتف:", data.customerPhone);
      drawTextRow("المادة/الجهاز:", data.productName);

      // Separator
      ctx.beginPath();
      ctx.moveTo(Math.round(20 * scale), y);
      ctx.lineTo(width - Math.round(20 * scale), y);
      ctx.stroke();
      y += Math.round(40 * scale);

      drawTextRow("سعر الجهاز الكلي:", `${formatNumber(data.totalAmount)} د.ع`);
      if (data.upfront !== undefined) {
        drawTextRow("المقدمة المدفوعة:", `${formatNumber(data.upfront)} د.ع`);
      }
      if (data.paidAmount !== undefined) {
        drawTextRow("المسدد الحالي:", `${formatNumber(data.paidAmount)} د.ع`);
      }
      drawTextRow("المتبقي الكلي:", `${formatNumber(data.remainingAmount)} د.ع`);

      if (data.nextDueDate) {
        drawTextRow("تاريخ الدفع القادم:", data.nextDueDate);
      }

      // Separator
      ctx.beginPath();
      ctx.moveTo(Math.round(20 * scale), y);
      ctx.lineTo(width - Math.round(20 * scale), y);
      ctx.stroke();
      y += Math.round(40 * scale);

      // Footer
      drawText("شكرًا لتعاملكم معنا. يرجى الاحتفاظ بالوصل.", width / 2, y, `bold ${Math.round(18 * scale)}px 'Cairo', sans-serif`, "center");
      y += Math.round(60 * scale);

      // Crop canvas
      const finalCanvas = document.createElement("canvas");
      finalCanvas.width = width;
      finalCanvas.height = y;
      const finalCtx = finalCanvas.getContext("2d");
      if (!finalCtx) throw new Error("Could not initialize final context");

      finalCtx.fillStyle = "#FFFFFF";
      finalCtx.fillRect(0, 0, width, y);
      finalCtx.drawImage(tempCanvas, 0, 0);

      const imgData = finalCtx.getImageData(0, 0, width, y);
      const pixels = imgData.data;

      // Pack pixels to 1-bit ESC/POS format using safe horizontal slicing.
      // Slicing into bands of 40 pixels prevents printer RAM/buffer overflow
      // on low-cost thermal printers and ensures stable, non-squished printing!
      const widthBytes = width / 8; // 384 / 8 = 48 bytes OR 576 / 8 = 72 bytes
      const height = y;
      const escposData: number[] = [];

      // Initialize: ESC @
      escposData.push(0x1B, 0x40);

      // Line spacing 24 dots: ESC 3 24
      escposData.push(0x1B, 0x33, 0x18);

      const sliceHeight = 40;
      for (let yStart = 0; yStart < height; yStart += sliceHeight) {
        const currentSliceHeight = Math.min(sliceHeight, height - yStart);

        // Raster Bit Image Command: GS v 0 0 xL xH yL yH
        escposData.push(0x1D, 0x76, 0x30, 0x00);
        escposData.push(widthBytes & 0xFF, (widthBytes >> 8) & 0xFF);
        escposData.push(currentSliceHeight & 0xFF, (currentSliceHeight >> 8) & 0xFF);

        // Binary thresholding for this slice
        for (let yOffset = 0; yOffset < currentSliceHeight; yOffset++) {
          const yi = yStart + yOffset;
          for (let xByte = 0; xByte < widthBytes; xByte++) {
            let byteVal = 0;
            for (let bit = 0; bit < 8; bit++) {
              const xPixel = xByte * 8 + bit;
              const pixelIndex = (yi * width + xPixel) * 4;

              const r = pixels[pixelIndex];
              const g = pixels[pixelIndex + 1];
              const b = pixels[pixelIndex + 2];
              const a = pixels[pixelIndex + 3];

              const luminance = a < 50 ? 255 : (0.299 * r + 0.587 * g + 0.114 * b);

              // Make text very crisp and dark
              if (luminance < printerThreshold) {
                byteVal |= (1 << (7 - bit));
              }
            }
            escposData.push(byteVal);
          }
        }
      }

      // Feed paper and cut
      escposData.push(0x1B, 0x64, 0x05); // Feed 5 lines
      escposData.push(0x1D, 0x56, 0x42, 0x00); // Partial cut

      const uint8Data = new Uint8Array(escposData);

      // Send chunks with a safe delay to prevent GATT and hardware buffer overflow
      const chunkSize = 128;
      showToast(` جاري إرسال النص العربي المنقح... 0%`, "info");

      for (let offset = 0; offset < uint8Data.length; offset += chunkSize) {
        const chunk = uint8Data.slice(offset, offset + chunkSize);
        await bluetoothDevice.characteristic.writeValue(chunk);
        
        const pct = Math.round((offset / uint8Data.length) * 100);
        if (pct % 25 === 0) {
          showToast(` جاري الإرسال... ${pct}%`, "info");
        }
        await new Promise(resolve => setTimeout(resolve, 15));
      }

      showToast(" تم طباعة النص العربي المنسق بخط Cairo المتميز بنجاح وسرعة فائقة!", "success");
    } catch (err: any) {
      console.error("Bluetooth text-image print error:", err);
      showToast(` فشل طباعة النص المباشر: ${err?.message || "تأكد من توافق الطابعة"}`, "danger");
    }
  };

  // Opens a beautiful, official A4 printable statement for the client
  const printCustomerStatement = (customer: Customer) => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      showToast(" يرجى السماح بالنوافذ المنبثقة لطباعة كشف الحساب!", "danger");
      return;
    }
    
    const paymentRows = (customer.payments || []).map((p, i) => `
      <tr>
        <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">${i + 1}</td>
        <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">${p.date}</td>
        <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; font-weight: bold; color: #16a34a;">${formatNumber(p.amount)} د.ع</td>
      </tr>
    `).join("");

    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <title>كشف حساب - ${customer.name}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;850&display=swap');
          body {
            font-family: 'Cairo', sans-serif;
            margin: 40px;
            color: #1e293b;
            background-color: #ffffff;
          }
          .header {
            text-align: center;
            margin-bottom: 40px;
            border-bottom: 3px double #d4a84f;
            padding-bottom: 20px;
          }
          .title {
            font-size: 24px;
            font-weight: 850;
            color: #0b1220;
            margin: 10px 0;
          }
          .meta-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
            background-color: #f8fafc;
            padding: 20px;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
          }
          .info-block {
            font-size: 14px;
            line-height: 1.8;
          }
          .info-label {
            color: #64748b;
            font-weight: 600;
          }
          .info-value {
            color: #0f172a;
            font-weight: 700;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
          }
          th {
            background-color: #0b1f3a;
            color: #ffffff;
            padding: 12px;
            text-align: right;
            font-size: 13px;
            font-weight: 700;
          }
          td {
            padding: 12px;
            font-size: 13px;
          }
          .summary-box {
            margin-top: 40px;
            background-color: #fffbeb;
            border: 1.5px solid #fde68a;
            padding: 20px;
            border-radius: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
          }
          .footer {
            text-align: center;
            margin-top: 60px;
            color: #94a3b8;
            font-size: 11px;
            border-top: 1px solid #e2e8f0;
            padding-top: 20px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div style="font-size: 28px; font-weight: 850; color: #d4a84f;"> ${branding.shopName} </div>
          <div class="title">كشف حساب تفصيلي للأقساط والمبيعات</div>
          <div style="font-size: 12px; color: #64748b; font-weight: bold;">تاريخ التصدير: ${new Date().toLocaleDateString("ar-EG")}</div>
        </div>

        <div class="meta-info">
          <div class="info-block">
            <div><span class="info-label">اسم العميل:</span> <span class="info-value">${customer.name}</span></div>
            <div><span class="info-label">رقم الهاتف:</span> <span class="info-value">${customer.phone}</span></div>
            <div><span class="info-label">المادة/الجهاز:</span> <span class="info-value">${customer.productName}</span></div>
          </div>
          <div class="info-block" style="text-align: left;">
            <div><span class="info-label">سعر المادة الكلي:</span> <span class="info-value">${formatNumber(customer.totalAmount)} د.ع</span></div>
            <div><span class="info-label">المقدمة المدفوعة:</span> <span class="info-value">${formatNumber(customer.upfront)} د.ع</span></div>
            <div><span class="info-label">القسط الشهري:</span> <span class="info-value">${formatNumber(customer.monthlyAmount)} د.ع (يوم ${customer.dueDay} شهرياً)</span></div>
          </div>
        </div>

        <div style="font-weight: 850; font-size: 16px; margin-bottom: 10px; color: #0b1f3a;"> سجل السدادات والمدفوعات السابقة:</div>
        ${(customer.payments || []).length === 0 ? `
          <div style="text-align: center; padding: 20px; border: 1px dashed #cbd5e1; border-radius: 12px; color: #64748b; font-size: 13px; font-weight: bold;">
            لا توجد دفعات مسجلة حالياً لهذا الحساب.
          </div>
        ` : `
          <table>
            <thead>
              <tr>
                <th style="border-top-right-radius: 8px;">ت</th>
                <th>تاريخ السداد</th>
                <th style="border-top-left-radius: 8px;">المبلغ المسدد</th>
              </tr>
            </thead>
            <tbody>
              ${paymentRows}
            </tbody>
          </table>
        `}

        <div class="summary-box">
          <div>
            <span style="font-weight: bold; color: #78350f; font-size: 14px;">الموقف المالي للزبون:</span>
            <div style="font-size: 11px; color: #b45309; font-weight: bold; margin-top: 4px;">يشمل كافة السحوبات والخصومات المسجلة لغاية هذا التاريخ.</div>
          </div>
          <div style="text-align: left;">
            <span style="font-size: 12px; font-weight: bold; color: #78350f; display: block;">المتبقي المطلوب للذمة:</span>
            <span style="font-size: 24px; font-weight: 900; color: #b91c1c;">${formatNumber(customer.remainingAmount)} د.ع</span>
          </div>
        </div>

        <div class="footer">
          <p>تم استخراج وتصدير هذا الكشف إلكترونياً من نظام إدارة الأقساط والمبيعات المعتمد.</p>
          <p style="margin-top: 5px; font-weight: bold; color: #475569;"> مركز ${branding.shopName} للمبيعات والأقساط - هاتف: ${branding.phone} </p>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          }
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Shapes and formats detailed Arabic WhatsApp account statement message
  const handleShareStatementWhatsApp = (customer: Customer) => {
    const shopName = branding.shopName;
    const clientName = customer.name;
    const totalAmount = formatNumber(customer.totalAmount);
    const upfront = formatNumber(customer.upfront);
    const remainingAmount = formatNumber(customer.remainingAmount);
    const monthlyAmount = formatNumber(customer.monthlyAmount);
    const dueDay = customer.dueDay;
    const productName = customer.productName;

    let paymentsText = "";
    if (customer.payments && customer.payments.length > 0) {
      paymentsText = customer.payments.map((p, i) => ` ${i + 1}. بتاريخ: ${p.date} تم دفع: ${formatNumber(p.amount)} د.ع`).join("\n");
    } else {
      paymentsText = " - لا توجد دفعات سابقة مسجلة حالياً.";
    }

    const message = `* كشف حساب تفصيلي للأقساط - ${shopName} *\n\n` +
                    `*عزيزي الزبون:* ${clientName} المحترم\n\n` +
                    `نرسل لكم الموقف المالي وتفاصيل الأقساط الخاصة بكم:\n\n` +
                    `*▪ تفاصيل التعاقد المالي:*\n` +
                    `- *المادة/الجهاز:* ${productName}\n` +
                    `- *سعر الجهاز الكلي:* ${totalAmount} د.ع\n` +
                    `- *المقدمة المدفوعة:* ${upfront} د.ع\n` +
                    `- *القسط الشهري المحدد:* ${monthlyAmount} د.ع (يستحق يوم ${dueDay} من كل شهر)\n\n` +
                    `*▪ سجل الدفعات والوصولات السابقة:*\n` +
                    `${paymentsText}\n\n` +
                    `*▪ الموقف المالي الحالي لغاية اليوم:*\n` +
                    `- *إجمالي المتبقي الكلي للذمة:* *${remainingAmount} د.ع*\n\n` +
                    `* إدارة مبيعات وأقساط ${shopName} - هاتف: ${branding.phone} *`;

    let phoneNum = customer.phone.trim().replace(/[^\d+]/g, "");
    if (phoneNum.startsWith("07")) {
      phoneNum = "964" + phoneNum.substring(1);
    }

    const whatsappUrl = `https://api.whatsapp.com/send?phone=${phoneNum}&text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

  // Calculate remaining amount on-the-fly
  const totalVal = cleanNumber(custTotalAmount);
  const upfrontVal = cleanNumber(custUpfront);
  const remainingVal = Math.max(0, totalVal - upfrontVal);

  // Form completion helper for additions
  const getFormCompletionPercentage = () => {
    let totalFields = 0;
    let filledFields = 0;

    // Customer details
    totalFields += 6;
    if (custName.trim().length > 0) filledFields++;
    if (custPhone.replace(/[^\d]/g, "").length === 11) filledFields++;
    if (custNationalId.replace(/[^\d]/g, "").length === 12) filledFields++;
    if (custGovernorate.trim().length > 0) filledFields++;
    if (custNearestLandmark.trim().length > 0) filledFields++;
    if (custDateAdded.trim().length > 0) filledFields++;

    // Guarantor details
    if (hasGuarantor) {
      totalFields += 5;
      if (guarantorName.trim().length > 0) filledFields++;
      if (guarantorPhone.replace(/[^\d]/g, "").length === 11) filledFields++;
      if (guarantorNationalId.replace(/[^\d]/g, "").length === 12) filledFields++;
      if (guarantorGovernorate.trim().length > 0) filledFields++;
      if (guarantorNearestLandmark.trim().length > 0) filledFields++;
    }

    // Product details
    totalFields += 1;
    if (prodName.trim().length > 0) filledFields++;

    // Installment details
    totalFields += 3;
    if (custTotalAmount.trim().length > 0) filledFields++;
    if (custMonthly.trim().length > 0) filledFields++;
    if (custDueDay.trim().length > 0) filledFields++;

    return Math.round((filledFields / totalFields) * 100);
  };

  // Stepper helper functions
  const getDisplayStepNumber = (step: number | "review"): string => {
    if (step === "review") return "المراجعة والتدقيق";
    const totalSteps = hasGuarantor ? 5 : 4;
    // Map current active step to its actual sequence step number
    let displayStepNum = step;
    if (!hasGuarantor && step === 5) {
      displayStepNum = 4;
    }
    return `الخطوة ${displayStepNum} من ${totalSteps}`;
  };

  const getDisplayPercentage = (step: number | "review"): number => {
    if (step === "review") return 100;
    if (step === 1) return 20;
    if (step === 2) return 40;
    if (step === 3) return 60;
    if (step === 4) return 80;
    if (step === 5) return 100;
    return 100;
  };

  // Smart Alert Check - using the robust Next Due Date logic
  const dueCustomers = customers.filter((c) => isCustomerDue(c));

  // Detailed alerts calculation
  const customerAlerts = customers
    .filter((c) => c.status === "active")
    .map((c) => {
      const alertInfo = getCustomerAlertInfo(c);
      return {
        customer: c,
        ...alertInfo
      };
    })
    .filter((info) => info.status === "overdue" || info.status === "due_today" || info.status === "approaching");

  // Number of alerts (overdue, due_today, or approaching)
  const alertCount = customerAlerts.length;

  // Global Stat: Total Debt
  const totalDebt = customers.reduce((sum, c) => sum + c.remainingAmount, 0);

// Helper to compress base64 image using canvas to prevent Firebase "Write too large" errors and save storage space
const compressImage = (base64Str: string, maxWidth = 1000, maxHeight = 1000, quality = 0.65): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext("2d");
      if (ctx) {
        // Use high-quality image scaling settings
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(img, 0, 0, width, height);
        const compressed = canvas.toDataURL("image/jpeg", quality);
        resolve(compressed);
      } else {
        resolve(base64Str);
      }
    };
    img.onerror = () => {
      resolve(base64Str);
    };
  });
};

  // Process selected file to base64 DataURL (Bypass compression as requested)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, key: keyof CustomerImages) => {
    const file = e.target.files?.[0];
    if (file) {
      const storageKey = 'customer_' + key;
      setCompressingKeys((prev) => [...prev, storageKey]);
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const originalBase64 = event.target.result as string;
          setImages((prev) => ({
            ...prev,
            [key]: originalBase64
          }));
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        } else {
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        }
      };
      reader.onerror = () => {
        setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
      };
      reader.readAsDataURL(file);
    }
  };

  // Process selected guarantor file to base64 DataURL (Bypass compression as requested)
  const handleGuarantorFileChange = (e: React.ChangeEvent<HTMLInputElement>, key: keyof GuarantorImages) => {
    const file = e.target.files?.[0];
    if (file) {
      const storageKey = 'guarantor_' + key;
      setCompressingKeys((prev) => [...prev, storageKey]);
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const originalBase64 = event.target.result as string;
          setGuarantorImages((prev) => ({
            ...prev,
            [key]: originalBase64
          }));
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        } else {
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        }
      };
      reader.onerror = () => {
        setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDirectCustomerUpload = async (key: keyof CustomerImages, file: File) => {
    const storageKey = 'customer_' + key;
    setCompressingKeys((prev) => [...prev, storageKey]);
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const originalBase64 = event.target.result as string;
          setImages((prev) => ({
            ...prev,
            [key]: originalBase64
          }));
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        } else {
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        }
      };
      reader.onerror = () => {
        setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
      };
      reader.readAsDataURL(file);
    } catch (e) {
      setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
    }
  };

  const handleDirectGuarantorUpload = async (key: keyof GuarantorImages, file: File) => {
    const storageKey = 'guarantor_' + key;
    setCompressingKeys((prev) => [...prev, storageKey]);
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const originalBase64 = event.target.result as string;
          setGuarantorImages((prev) => ({
            ...prev,
            [key]: originalBase64
          }));
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        } else {
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        }
      };
      reader.onerror = () => {
        setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
      };
      reader.readAsDataURL(file);
    } catch (e) {
      setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
    }
  };

  // Direct WhatsApp Launch Function with prepared text
  const launchWhatsAppWithMessage = (phoneNumber: string, messageText: string) => {
    if (!phoneNumber) return;
    let cleanPhone = phoneNumber.toString().replace(/\s+/g, "");

    if (cleanPhone.startsWith("07")) {
      cleanPhone = "964" + cleanPhone.substring(1);
    } else if (cleanPhone.startsWith("7")) {
      cleanPhone = "964" + cleanPhone;
    } else if (cleanPhone.startsWith("+964")) {
      cleanPhone = cleanPhone.replace("+", "");
    }

    const encodedMsg = encodeURIComponent(messageText);
    window.open(`https://wa.me/${cleanPhone}?text=${encodedMsg}`, "_blank");
    setTemplateModalCustomer(null);
  };

  // Step Validation Helpers
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const validateStep = (stepNum: number): boolean => {
    const errs: Record<string, string> = {};

    if (stepNum === 1) {
      if (!custName.trim()) {
        errs.custName = "الاسم الكامل مطلوب";
      }
      const cleanPhone = custPhone.replace(/[^\d]/g, "");
      if (!custPhone.trim()) {
        errs.custPhone = "رقم هاتف العميل مطلوب";
      } else if (cleanPhone.length !== 11) {
        errs.custPhone = "يجب أن يتكون رقم الهاتف من 11 رقماً ويبدأ بـ 07 (مثل 07701234567)";
      }
      if (!custProfession.trim()) {
        errs.custProfession = "المهنة / الوظيفة مطلوبة";
      }
      const cleanId = custNationalId.replace(/[^\d]/g, "");
      if (!custNationalId.trim()) {
        errs.custNationalId = "رقم البطاقة الموحدة مطلوب";
      } else if (cleanId.length !== 12) {
        errs.custNationalId = "رقم البطاقة الموحدة يجب أن يتكون من 12 رقماً";
      }
      if (!custGovernorate.trim()) {
        errs.custGovernorate = "يرجى تحديد محافظة السكن";
      }
      if (!custNearestLandmark.trim()) {
        errs.custNearestLandmark = "يرجى تحديد أقرب نقطة دالة";
      }
      if (!custDateAdded.trim()) {
        errs.custDateAdded = "تاريخ تسجيل القسط مطلوب";
      }
    }

    if (stepNum === 2) {
      if (!prodName.trim()) {
        errs.prodName = "نوع السلعة / المنتج مطلوب";
      }
    }

    if (stepNum === 3) {
      if (!custCashPrice.trim() || Number(custCashPrice) <= 0) {
        errs.custCashPrice = "السعر النقدي للسلعة مطلوب ويجب أن يكون أكبر من الصفر";
      }
      if (!custTotalAmount.trim() || Number(custTotalAmount) <= 0) {
        errs.custTotalAmount = "سعر البيع بالتقسيط مطلوب ويجب أن يكون أكبر من الصفر";
      }
      if (custUpfront.trim() && Number(custUpfront) < 0) {
        errs.custUpfront = "الدفعة المقدمة لا يمكن أن تكون أقل من الصفر";
      } else if (Number(custUpfront) > Number(custTotalAmount)) {
        errs.custUpfront = "الدفعة المقدمة لا يمكن أن تتجاوز السعر الإجمالي للتقسيط";
      }
      if (!custInstallmentCount.trim() || Number(custInstallmentCount) <= 0) {
        errs.custInstallmentCount = "عدد أشهر الأقساط مطلوب ويجب أن يكون أكبر من الصفر";
      }
      if (!custDueDay.trim()) {
        errs.custDueDay = "يوم الاستحقاق مطلوب";
      } else {
        const dNum = Number(custDueDay);
        if (dNum < 1 || dNum > 31) {
          errs.custDueDay = "يجب أن يكون يوم الاستحقاق بين 1 و 31";
        }
      }
      if (!firstInstallmentDate.trim()) {
        errs.firstInstallmentDate = "تاريخ استحقاق أول قسط مطلوب";
      }
      if (!custMonthly.trim() || Number(custMonthly) <= 0) {
        errs.custMonthly = "قيمة القسط الشهري الواحد مطلوبة";
      }
    }

    if (stepNum === 4 && hasGuarantor) {
      if (!guarantorName.trim()) {
        errs.guarantorName = "الاسم الكامل للكفيل مطلوب";
      }
      const cleanPhone = guarantorPhone.replace(/[^\d]/g, "");
      if (!guarantorPhone.trim()) {
        errs.guarantorPhone = "رقم هاتف الكفيل مطلوب";
      } else if (cleanPhone.length !== 11) {
        errs.guarantorPhone = "رقم هاتف الكفيل يجب أن يتكون من 11 رقماً";
      }
      if (!guarantorProfession.trim()) {
        errs.guarantorProfession = "المهنة / الوظيفة للكفيل مطلوبة";
      }
      const cleanId = guarantorNationalId.replace(/[^\d]/g, "");
      if (!guarantorNationalId.trim()) {
        errs.guarantorNationalId = "رقم البطاقة الموحدة للكفيل مطلوب";
      } else if (cleanId.length !== 12) {
        errs.guarantorNationalId = "رقم البطاقة الموحدة للكفيل يجب أن يتكون من 12 رقماً";
      }
      if (!guarantorRelationship.trim()) {
        errs.guarantorRelationship = "صلة القرابة بالعميل مطلوبة";
      }
      if (!guarantorGovernorate.trim()) {
        errs.guarantorGovernorate = "يرجى تحديد محافظة سكن الكفيل";
      }
      if (!guarantorNearestLandmark.trim()) {
        errs.guarantorNearestLandmark = "يرجى كتابة أقرب نقطة دالة لسكن الكفيل";
      }
    }

    setFormErrors(errs);

    if (Object.keys(errs).length > 0) {
      setTimeout(() => {
        const firstErrorKey = Object.keys(errs)[0];
        const element = document.getElementById(`err-${firstErrorKey}`);
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }, 80);
      return false;
    }

    return true;
  };

  const isCurrentStepValid = (stepNum: number | "review"): boolean => {
    if (stepNum === 1) {
      const cleanPhone = custPhone.replace(/[^\d]/g, "");
      const cleanId = custNationalId.replace(/[^\d]/g, "");
      return (
        custName.trim().length > 0 &&
        cleanPhone.length === 11 &&
        custProfession.trim().length > 0 &&
        cleanId.length === 12 &&
        custGovernorate.trim().length > 0 &&
        custNearestLandmark.trim().length > 0 &&
        custDateAdded.trim().length > 0
      );
    }
    if (stepNum === 2) {
      return prodName.trim().length > 0;
    }
    if (stepNum === 3) {
      return (
        custCashPrice.trim().length > 0 &&
        Number(custCashPrice) > 0 &&
        custTotalAmount.trim().length > 0 &&
        Number(custTotalAmount) > 0 &&
        custMonthly.trim().length > 0 &&
        Number(custMonthly) > 0 &&
        custInstallmentCount.trim().length > 0 &&
        custDueDay.trim().length > 0 &&
        firstInstallmentDate.trim().length > 0
      );
    }
    if (stepNum === 4) {
      if (!hasGuarantor) return true;
      const cleanPhone = guarantorPhone.replace(/[^\d]/g, "");
      const cleanId = guarantorNationalId.replace(/[^\d]/g, "");
      return (
        guarantorName.trim().length > 0 &&
        cleanPhone.length === 11 &&
        guarantorProfession.trim().length > 0 &&
        cleanId.length === 12 &&
        guarantorRelationship.trim().length > 0 &&
        guarantorGovernorate.trim().length > 0 &&
        guarantorNearestLandmark.trim().length > 0
      );
    }
    if (stepNum === 5) {
      return true;
    }
    return true;
  };

  // Handle Form Submission
  const handleAddNewCustomer = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isSubmitting) return;

    // Final safety validations for all steps
    if (!validateStep(1)) {
      setFormStep(1);
      return;
    }
    if (!validateStep(2)) {
      setFormStep(2);
      return;
    }
    if (!validateStep(3)) {
      setFormStep(3);
      return;
    }
    if (hasGuarantor && !validateStep(4)) {
      setFormStep(4);
      return;
    }

    // Guard: Prevent duplicate customer with same name & phone number
    const alreadyExists = customers.some(
      (c) => c.name.trim() === custName.trim() && c.phone.trim() === custPhone.trim()
    );
    if (alreadyExists) {
      showToast(" هذا الزبون مسجل مسبقاً بنفس الاسم ورقم الهاتف لضمان عدم التكرار!", "danger");
      return;
    }

    await executeSaveCustomer();
  };

  // Save customer helper supporting Offline Caching & Sync
  const persistCustomer = async (cust: Customer) => {
    // 1. Optimistic Update locally
    setCustomers((prev) => {
      const index = prev.findIndex((c) => c.id === cust.id);
      let updatedList = [...prev];
      if (index > -1) {
        updatedList[index] = cust;
      } else {
        updatedList.push(cust);
      }
      cacheLightweightCustomers(updatedList);
      return updatedList;
    });

    // 2. Write to Firebase Firestore database
    await saveCustomer(cust);
  };

  // Delete customer helper supporting Offline Caching & Sync
  const persistDeleteCustomer = async (id: string) => {
    // 1. Optimistic Update locally
    setCustomers((prev) => {
      const filtered = prev.filter((c) => c.id !== id);
      cacheLightweightCustomers(filtered);
      return filtered;
    });

    // 2. Delete from Firebase Firestore database
    await deleteCustomerFromDb(id);
  };

  const executeSaveCustomer = async () => {
    setIsSubmitting(true);

    const newCustomer: Customer = {
      id: Date.now().toString(),
      name: custName.trim(),
      phone: custPhone.trim(),
      nationalId: custNationalId.trim(),
      governorate: custGovernorate.trim(),
      nearestLandmark: custNearestLandmark.trim(),
      profession: custProfession.trim(),
      productName: prodName.trim(),
      productSerial: prodSerial.trim() || "غير مسجل",
      productDetails: prodDetails.trim() || "غير مسجل",
      totalAmount: totalVal,
      upfront: upfrontVal,
      monthlyAmount: cleanNumber(custMonthly),
      remainingAmount: remainingVal,
      dueDay: parseInt(custDueDay) || 1,
      images: images,
      payments: [],
      status: remainingVal <= 0 ? "done" : "active",
      dateAdded: custDateAdded.replace(/-/g, "/"),
      hasGuarantor: hasGuarantor,
      installmentCount: parseInt(custInstallmentCount) || 12,
      firstInstallmentDate: firstInstallmentDate,
      guarantor: hasGuarantor ? {
        name: guarantorName.trim(),
        phone: guarantorPhone.trim(),
        address: guarantorAddress.trim(),
        nationalId: guarantorNationalId.trim(),
        profession: guarantorProfession.trim(),
        relationship: guarantorRelationship.trim(),
        images: guarantorImages
      } : undefined
    };

    try {
      await persistCustomer(newCustomer);
      clearFormDrafts();

      showToast(`تمت إضافة الزبون (${newCustomer.name}) وحفظ بياناته محلياً بنجاح!`, "success");
      
      // Trigger the 80mm thermal receipt modal for customer registration!
      setThermalReceiptData({
        title: "وصل تسجيل زبون جديد",
        customerName: newCustomer.name,
        customerPhone: newCustomer.phone,
        productName: newCustomer.productName,
        totalAmount: newCustomer.totalAmount,
        upfront: newCustomer.upfront,
        remainingAmount: newCustomer.remainingAmount,
        monthlyAmount: newCustomer.monthlyAmount,
        dueDay: newCustomer.dueDay,
        date: newCustomer.dateAdded,
        nextDueDate: formatNextDueDate(getCustomerNextDueDate(newCustomer))
      });

      // Switch to list
      setCurrentScreen("list");
      setShowNoDocsConfirm(false);
    } catch (error) {
      console.error(error);
      showToast(" فشل حفظ بيانات الزبون في قاعدة البيانات المحلية.", "danger");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Payment
  const handlePaymentSubmit = async (customerId: string) => {
    if (isPaying) return;
    setIsPaying(true);

    try {
      // Re-fetch the absolute freshest state of this customer directly from the database to prevent stale state issues
      const customer = await getCustomerById(customerId);
      if (!customer) {
        showToast(" لم يتم العثور على بيانات هذا العميل في قاعدة البيانات!", "danger");
        setIsPaying(false);
        return;
      }

      const amount = cleanNumber(payAmountInput);
      if (amount <= 0) {
        showToast(" يرجى كتابة مبلغ سداد صحيح أكبر من الصفر!", "danger");
        setIsPaying(false);
        return;
      }
      if (amount > customer.remainingAmount) {
        showToast(` لا يمكن دفع مبلغ أكبر من المتبقي المطلوب ذمته (${formatNumber(customer.remainingAmount)} د.ع)!`, "danger");
        setIsPaying(false);
        return;
      }

      const updatedRemaining = Math.max(0, customer.remainingAmount - amount);
      const paymentDateFormatted = payDateInput ? payDateInput.replace(/-/g, "/") : new Date().toLocaleDateString("ar-EG");

      const paymentId = `pay-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const newPaymentRecord: Payment & { id?: string } = {
        id: paymentId,
        date: paymentDateFormatted,
        amount: amount
      };

      const updatedCustomer: Customer = {
        ...customer,
        remainingAmount: updatedRemaining,
        status: updatedRemaining <= 0 ? "done" : "active",
        payments: [...(customer.payments || []), newPaymentRecord]
      };

      // Atomic Update in Database & Local State
      await persistCustomer(updatedCustomer);
      
      // Update the active full customer state immediately to trigger real-time UI refresh
      setActiveFullCustomer(updatedCustomer);
      
      // Reset payment input fields
      setPayAmountInput("");
      
      showToast(`تم تسجيل السداد بنجاح وخصم مبلغ ${formatNumber(amount)} د.ع لزبونك.`, "success");

      // Trigger the 80mm thermal receipt modal for the new payment!
      setThermalReceiptData({
        title: "وصل استلام دفعة مالية",
        customerName: updatedCustomer.name,
        customerPhone: updatedCustomer.phone,
        productName: updatedCustomer.productName,
        totalAmount: updatedCustomer.totalAmount,
        paidAmount: amount,
        remainingAmount: updatedCustomer.remainingAmount,
        monthlyAmount: updatedCustomer.monthlyAmount,
        dueDay: updatedCustomer.dueDay,
        date: paymentDateFormatted,
        nextDueDate: formatNextDueDate(getCustomerNextDueDate(updatedCustomer))
      });
    } catch (error) {
      console.error("Error during payment submission:", error);
      showToast("فشل تحديث السداد في قاعدة البيانات.", "danger");
    } finally {
      setIsPaying(false);
    }
  };
  // Delete Customer Record
  const handleDeleteCustomer = async (id: string) => {
    const customer = customers.find((c) => c.id === id);
    const customerName = customer ? customer.name : "الزبون";

    try {
      await persistDeleteCustomer(id);
      showToast(` تم حذف ملف الزبون (${customerName}) بالكامل بنجاح!`, "success");
      setCurrentScreen("list");
      setSelectedCustomerId(null);
      setDeleteConfirmId(null);
    } catch (error) {
      console.error(error);
      showToast(" فشل حذف الملف.", "danger");
    }
  };

  // Switch to details
  const viewCustomerDetails = (id: string) => {
    const customer = customers.find((c) => c.id === id);
    if (customer) {
      setSelectedCustomerId(id);
      setPayAmountInput(formatNumber(customer.monthlyAmount));
      
      const d = new Date();
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      setPayDateInput(`${year}-${month}-${day}`);
      
      setCurrentScreen("detail");
    }
  };

  // Filtered customers list
  const filteredCustomers = useMemo(() => {
    return customers.filter((c) => {
      const term = searchText.toLowerCase();
      const matchesSearch =
        c.name.toLowerCase().includes(term) ||
        c.phone.includes(term) ||
        c.productName.toLowerCase().includes(term);

      if (currentFilter === "due") {
        return matchesSearch && isCustomerDue(c);
      }
      return matchesSearch;
    });
  }, [customers, searchText, currentFilter]);

  return (
    <div 
      className={`w-screen transition-colors duration-500 flex justify-center items-center select-none overflow-hidden relative ${
        isLoggedIn ? "bg-slate-50 text-slate-800 selection:bg-slate-200" : "bg-[#0B1220] text-white selection:bg-[#D4A84F]/30"
      }`}
      dir="rtl"
      style={{ height: initialHeight ? `${initialHeight}px` : '100dvh' }}
    >
      
      {/* Background Ambient Glow Blobs matching premium mobile apps */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {isLoggedIn ? (
          <>
            <div className="absolute top-[-10%] left-[-20%] w-[80vw] h-[80vw] md:w-[45rem] md:h-[45rem] bg-slate-200/30 rounded-full blur-[100px]" />
            <div className="absolute bottom-[-10%] right-[-20%] w-[80vw] h-[80vw] md:w-[45rem] md:h-[45rem] bg-slate-100/40 rounded-full blur-[100px]" />
          </>
        ) : (
          <>
            {/* Animated gold and blue blobs for the luxury theme */}
            <div className="absolute top-[-20%] right-[-10%] w-[100vw] h-[100vw] md:w-[60rem] md:h-[60rem] bg-gradient-to-br from-[#D4A84F]/10 to-transparent rounded-full blur-[120px] animate-pulse" style={{ animationDuration: '8s' }} />
            <div className="absolute bottom-[-20%] left-[-15%] w-[90vw] h-[90vw] md:w-[50rem] md:h-[50rem] bg-gradient-to-tr from-[#0B1F3A]/60 to-transparent rounded-full blur-[100px] animate-pulse" style={{ animationDuration: '6s' }} />
          </>
        )}
      </div>
      
      {/* Toast Notification Alert Overlay */}
      {toast && (
        <div className="absolute top-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4">
          <div className={`p-4 rounded-2xl shadow-xl border text-xs font-black flex items-center gap-2.5 animate-pulse ${
            toast.type === "success" 
              ? "bg-emerald-50 border-emerald-200 text-emerald-800" 
              : toast.type === "danger"
              ? "bg-rose-50 border-rose-200 text-rose-800"
              : "bg-slate-50 border-slate-200 text-slate-800"
          }`}>
            <AlertCircle className="w-5 h-5 text-slate-900 flex-shrink-0" />
            <span className="leading-relaxed">{toast.message}</span>
          </div>
        </div>
      )}

      {!isLoggedIn ? (
        <div 
          className="relative w-full h-full min-h-screen flex flex-col justify-between items-center p-4 md:p-8 text-center overflow-y-auto overflow-x-hidden select-none bg-[#0B1220]"
          style={{ 
            backgroundImage: `radial-gradient(circle at center, rgba(11, 18, 32, 0.4) 0%, rgba(11, 18, 32, 0.95) 100%), url(${basraNightBg})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
          dir="rtl"
        >
          {/* Inject luxury animations & keyframes inside custom style sheet */}
          <style dangerouslySetInnerHTML={{ __html: `
            @keyframes golden-pulse {
              0%, 100% { opacity: 0.3; transform: scale(1); }
              50% { opacity: 0.6; transform: scale(1.05); }
            }
            @keyframes shimmer {
              0% { background-position: -200% 0; }
              100% { background-position: 200% 0; }
            }
            .luxury-shimmer {
              background: linear-gradient(90deg, rgba(212,168,79,0.05) 25%, rgba(212,168,79,0.15) 50%, rgba(212,168,79,0.05) 75%);
              background-size: 200% 100%;
              animation: shimmer 1.5s infinite linear;
            }
            .floating-blob-1 {
              animation: golden-pulse 10s infinite ease-in-out;
            }
            .floating-blob-2 {
              animation: golden-pulse 8s infinite ease-in-out reverse;
            }
          ` }} />

          {/* Floating background ambient gold blobs */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
            <div className="absolute top-[15%] right-[-10%] w-72 h-72 rounded-full bg-[#D4A84F]/5 blur-[80px] floating-blob-1" />
            <div className="absolute bottom-[20%] left-[-10%] w-80 h-80 rounded-full bg-[#D4A84F]/5 blur-[90px] floating-blob-2" />
          </div>

          {/* Top Logo & Title Section */}
          <div className="w-full max-w-md mx-auto pt-6 pb-4 flex flex-col items-center gap-3 relative z-10 animate-in fade-in slide-in-from-top-4 duration-700">
            {/* Elegant Golden Royal Emblem Vector Logo */}
            <div className="relative group cursor-pointer">
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-[#B39262] via-[#D4A84F] to-[#B39262] opacity-30 blur-md group-hover:opacity-65 transition-opacity duration-500" />
              <div className="relative w-20 h-20 rounded-full bg-slate-950/80 border border-[#D4A84F]/30 flex items-center justify-center shadow-2xl">
                <svg className="w-11 h-11 text-[#D4A84F] drop-shadow-[0_2px_8px_rgba(212,168,79,0.35)]" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Outer Shield frame */}
                  <path d="M12 2L4 5V11C4 16.2 7.4 21 12 22C16.6 21 20 16.2 20 11V5L12 2Z" fill="currentColor" fillOpacity="0.06" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
                  {/* Core Monogram Wallet/Protection curves */}
                  <path d="M12 6C10.3 6 9 7.3 9 9V11C9 11.6 9.4 12 10 12H14C14.6 12 15 11.6 15 11V9C15 7.3 13.7 6 12 6Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                  <path d="M8 11.5H16C17.1 11.5 18 12.4 18 13.5V16C18 17.1 17.1 18 16 18H8C6.9 18 6 17.1 6 16V13.5C6 12.4 6.9 11.5 8 11.5Z" fill="currentColor" fillOpacity="0.15" stroke="currentColor" strokeWidth="1.5" />
                  <circle cx="12" cy="14.8" r="1.2" fill="#0B1220" stroke="currentColor" strokeWidth="1" />
                </svg>
              </div>
            </div>

            <div className="text-center space-y-1 mt-1">
              <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight drop-shadow-md">
                لوحة الدخول
              </h1>
              <p className="text-xs md:text-sm text-slate-300 font-medium">
                سجل دخولك للوصول إلى كافة خدمات أقساط {branding.shopName}
              </p>
            </div>
          </div>

          {/* Glass Card Container */}
          <div className="w-full max-w-md mx-auto my-auto relative z-10 animate-in fade-in zoom-in-95 duration-500">
            <div className="backdrop-blur-[18px] bg-slate-950/45 border border-[#D4A84F]/25 rounded-[24px] p-6 md:p-8 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] text-right space-y-5 overflow-hidden relative">
              
              {/* Luxury Shimmer Loading State */}
              {isAuthenticating ? (
                <div className="space-y-6 py-6 animate-pulse">
                  {/* Title Shimmer */}
                  <div className="space-y-2 text-center flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full luxury-shimmer" />
                    <div className="h-4 w-32 luxury-shimmer rounded-md mt-2" />
                    <div className="h-3 w-48 luxury-shimmer rounded-md" />
                  </div>
                  {/* Inputs Shimmer */}
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <div className="h-3 w-36 luxury-shimmer rounded-md" />
                      <div className="h-14 w-full luxury-shimmer rounded-2xl" />
                    </div>
                    <div className="space-y-2">
                      <div className="h-3 w-24 luxury-shimmer rounded-md" />
                      <div className="h-14 w-full luxury-shimmer rounded-2xl" />
                    </div>
                  </div>
                  {/* Button Shimmer */}
                  <div className="h-[58px] w-full luxury-shimmer rounded-2xl mt-6" />
                  <div className="h-4 w-32 luxury-shimmer rounded-md mx-auto" />
                </div>
              ) : (
                <>
                  {/* Error Notification Alert */}
                  {loginError && (
                    <div className="p-3.5 bg-rose-500/15 border border-rose-500/30 text-rose-200 text-xs font-bold rounded-2xl flex items-start gap-2.5 animate-in slide-in-from-top-2 duration-300">
                      <AlertCircle className="w-4.5 h-4.5 text-rose-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{loginError}</span>
                    </div>
                  )}

                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    {/* Username or Phone Input Field */}
                    <div className="space-y-2">
                      <label className="text-[11px] font-black text-[#D4A84F] tracking-wide uppercase pr-1">
                        رقم الهاتف أو اسم المستخدم
                      </label>
                      <div className="relative flex items-center">
                        <input
                          type="text"
                          required
                          value={loginUsername}
                          onChange={(e) => setLoginUsername(e.target.value)}
                          placeholder="مثال: admin أو رقم الهاتف"
                          className="w-full h-14 pr-12 pl-4 bg-slate-900/60 border border-slate-700/50 hover:border-[#D4A84F]/40 focus:border-[#D4A84F] rounded-2xl text-sm font-bold text-white placeholder-slate-500 outline-none transition-all duration-300 text-right focus:ring-2 focus:ring-[#D4A84F]/10 focus:bg-slate-900/90"
                        />
                        <div className="absolute right-4 text-slate-400 focus-within:text-[#D4A84F] transition-colors">
                          <User className="w-5 h-5 stroke-[2]" />
                        </div>
                      </div>
                      
                      {/* Real-time Inline validation */}
                      {loginUsername !== "" && loginUsername.trim().length < 3 && (
                        <p className="text-[10px] text-amber-400/90 font-extrabold pr-1 animate-fade-in">
                           يرجى كتابة 3 أحرف أو أرقام على الأقل.
                        </p>
                      )}
                      {loginUsername !== "" && loginUsername.trim().length >= 3 && (
                        <p className="text-[10px] text-emerald-400 font-extrabold pr-1 flex items-center gap-1">
                          <Check className="w-3 h-3" /> مدخل مقبول
                        </p>
                      )}
                    </div>

                    {/* Password Input Field */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center pr-1">
                        <label className="text-[11px] font-black text-[#D4A84F] tracking-wide uppercase">
                          كلمة المرور
                        </label>
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="flex items-center gap-1 text-[10px] font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
                        >
                          {showLoginPassword ? (
                            <>
                              <EyeOff className="w-3.5 h-3.5 text-[#D4A84F]" />
                              <span>إخفاء</span>
                            </>
                          ) : (
                            <>
                              <Eye className="w-3.5 h-3.5 text-[#D4A84F]" />
                              <span>إظهار</span>
                            </>
                          )}
                        </button>
                      </div>
                      <div className="relative flex items-center">
                        <input
                          type={showLoginPassword ? "text" : "password"}
                          required
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          placeholder="••••••"
                          className="w-full h-14 pr-12 pl-4 bg-slate-900/60 border border-slate-700/50 hover:border-[#D4A84F]/40 focus:border-[#D4A84F] rounded-2xl text-sm font-bold text-white placeholder-slate-500 outline-none transition-all duration-300 text-right focus:ring-2 focus:ring-[#D4A84F]/10 focus:bg-slate-900/90"
                        />
                        <div className="absolute right-4 text-slate-400">
                          <Lock className="w-5 h-5 stroke-[2]" />
                        </div>
                      </div>

                      {/* Real-time Inline validation */}
                      {loginPassword !== "" && loginPassword.length < 4 && (
                        <p className="text-[10px] text-amber-400/90 font-extrabold pr-1 animate-fade-in">
                           كلمة المرور يجب أن تكون 4 رموز على الأقل.
                        </p>
                      )}
                      {loginPassword !== "" && loginPassword.length >= 4 && (
                        <p className="text-[10px] text-emerald-400 font-extrabold pr-1 flex items-center gap-1">
                          <Check className="w-3 h-3" /> مدخل مقبول
                        </p>
                      )}
                    </div>

                    {/* Submit Login Button */}
                    <button
                      type="submit"
                      disabled={loginUsername.trim().length < 3 || loginPassword.length < 4}
                      className="w-full h-[58px] bg-gradient-to-r from-[#B39262] via-[#D4A84F] to-[#B39262] hover:brightness-110 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black text-sm rounded-2xl transition-all duration-300 flex items-center justify-center gap-2.5 shadow-[0_8px_30px_rgb(212,168,79,0.25)] cursor-pointer mt-2 group"
                    >
                      <LogIn className="w-5 h-5 text-slate-950 group-hover:translate-x-1 transition-transform" />
                      <span>دخول آمن</span>
                    </button>
                  </form>
                </>
              )}

            </div>
          </div>

        </div>
      ) : (
        /* Main Container */
        <div className={`w-full max-w-lg h-full max-h-full md:h-[94vh] md:max-h-[880px] md:my-auto flex flex-col md:rounded-[36px] md:shadow-[0_20px_50px_rgba(15,23,42,0.06)] md:border md:border-slate-100 overflow-hidden relative z-10 transition-all duration-300 ${
          currentScreen === "add" ? "bg-slate-50" : "bg-slate-50/95 backdrop-blur-2xl"
        }`}>

          {/* Header */}
          <header className="bg-white/95 backdrop-blur-md px-5 py-4 sticky top-0 z-40 flex justify-between items-center border-b border-slate-100/80">
            {/* Right side: Abstract spiral logo and Title */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#0B1F3A] flex items-center justify-center text-white shadow-sm">
                <svg className="w-5.5 h-5.5 text-[#D4A44B]" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 9.25 20.88 6.76 19.07 4.93C18.68 4.54 18.05 4.54 17.66 4.93C17.27 5.32 17.27 5.95 17.66 6.34C19.11 7.8 20 9.8 20 12C20 16.42 16.42 20 12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C14.2 4 16.2 4.89 17.66 6.34C18.05 6.73 18.68 6.73 19.07 6.34C19.46 5.95 19.46 5.32 19.07 6.34C17.24 3.1 14.75 2 12 2Z" fill="currentColor"/>
                  <path d="M12 6C8.69 6 6 8.69 6 12C6 15.31 8.69 18 12 18C15.31 18 18 15.31 18 12C18 10.34 17.33 8.84 16.24 7.76C15.85 7.37 15.22 7.37 14.83 7.76C14.44 8.15 14.44 8.78 14.83 9.17C15.56 9.9 16 10.9 16 12C16 14.21 14.21 16 12 16C9.79 16 8 14.21 8 12C8 9.79 9.79 8 12 8C12.55 8 13 7.55 13 7C13 6.45 12.55 6 12 6Z" fill="currentColor"/>
                </svg>
              </div>
              <div className="flex flex-col text-right">
                <span className="text-sm font-black text-slate-800">
                  {currentScreen === "add" && "إضافة قسط جديد"}
                  {currentScreen === "list" && "قائمة العملاء"}
                  {currentScreen === "detail" && "تفاصيل القسط"}
                  {currentScreen === "alerts" && "تنبيهات الاستحقاقات"}
                  {currentScreen === "settings" && "إعدادات الأمان"}
                </span>
                <span className="text-[10px] text-[#D4A44B] font-black">المبيعات والأقساط</span>
              </div>
            </div>

            {/* Left side: History, Notifications, Logout */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setCurrentScreen("list");
                  setSelectedCustomerId(null);
                }}
                title="سجل المعاملات والعملاء"
                className="w-9 h-9 rounded-full bg-slate-50 hover:bg-slate-100 border border-slate-100 flex items-center justify-center text-slate-600 transition-all cursor-pointer hover:scale-105 active:scale-95"
              >
                <Clock className="w-4.5 h-4.5" />
              </button>

              <button
                type="button"
                onClick={
                  notificationPermission === "granted"
                    ? () => triggerInstantCheck(customers)
                    : notificationPermission === "denied"
                    ? () => showToast(" الإشعارات محظورة بالمتصفح! يرجى تفعيلها من إعدادات الموقع بجانب شريط العنوان.", "danger")
                    : requestNotificationPermission
                }
                title={
                  notificationPermission === "granted"
                    ? "تنبيهات الأقساط نشطة (اضغط للاختبار)"
                    : notificationPermission === "denied"
                    ? "التنبيهات محظورة"
                    : "تفعيل تنبيهات الأقساط"
                }
                className={`w-9 h-9 rounded-full flex items-center justify-center border transition-all cursor-pointer relative hover:scale-105 active:scale-95 ${
                  notificationPermission === "granted"
                    ? "bg-slate-50 hover:bg-slate-100 border-slate-100 text-slate-600"
                    : "bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-700 animate-pulse"
                }`}
              >
                <Bell className="w-4.5 h-4.5" />
                {alertCount > 0 && (
                  <span className="absolute top-0.5 right-0.5 w-2.5 h-2.5 bg-rose-500 rounded-full ring-2 ring-white" />
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  if (isDemoActive) {
                    wipeAllData();
                    localStorage.removeItem("demo_active");
                    localStorage.removeItem("demo_start_time");
                    localStorage.setItem("demo_used", "true");
                    setIsDemoActive(false);
                    setDemoStartTime(null);
                    setDemoUsed(true);
                  } else {
                    localStorage.removeItem("isLoggedIn");
                  }
                  setIsLoggedIn(false);
                  showToast(" تم تسجيل الخروج بنجاح!", "info");
                }}
                title="تسجيل الخروج"
                className="w-9 h-9 rounded-full bg-rose-50 hover:bg-rose-100 border border-rose-100 flex items-center justify-center text-rose-600 transition-all cursor-pointer hover:scale-105 active:scale-95"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </header>

          {/* Demo Active Notice Banner */}
          {isDemoActive && (
            <div className="bg-[#D4A44B]/10 border-b border-[#D4A44B]/20 px-4 py-2.5 flex items-center justify-between text-[11px] font-black text-slate-700" dir="rtl">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
                <span>جلسة تجريبية مؤقتة (متبقي: <span className="font-mono text-rose-600 font-extrabold">{demoTimeLeftText || "02:00:00"}</span>)</span>
              </div>
              <button
                type="button"
                onClick={() => setShowDemoLimitReachedModal(true)}
                className="text-[#0B1F3A] bg-[#D4A44B]/20 px-2.5 py-1 rounded-lg border border-[#D4A44B]/30 hover:bg-[#D4A44B]/35 transition-colors text-[10px] font-extrabold cursor-pointer"
              >
                شراء النسخة الكاملة 
              </button>
            </div>
          )}



        {/* Dynamic Screens */}
        <main className="flex-1 overflow-y-auto p-4 pb-28 relative -webkit-overflow-scrolling: touch;">
          
          {/* SCREEN 1: ADD CUSTOMER */}
          {currentScreen === "add" && (
            <div className="space-y-6">
              {/* Top Title Bar with Return & Reset */}
              <div className="flex items-center justify-between bg-white px-5 py-4 rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.01)]" dir="rtl">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      if (custName.trim() || prodName.trim() || custTotalAmount.trim()) {
                        if (window.confirm("هل تريد العودة لقائمة العملاء؟ سيتم حفظ بيانات النموذج كمسودة تلقائياً.")) {
                          setCurrentScreen("list");
                        }
                      } else {
                        setCurrentScreen("list");
                      }
                    }}
                    className="w-10 h-10 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 flex items-center justify-center border border-slate-200/50 transition-all cursor-pointer active:scale-95 border-0"
                    title="العودة لقائمة العملاء"
                  >
                    <ArrowRight className="w-5 h-5 text-slate-700" />
                  </button>
                  <div className="text-right">
                    <h2 className="text-sm font-black text-slate-900">تسجيل قسط جديد</h2>
                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">{getDisplayStepNumber(formStep)}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleResetFormWithConfirm}
                  className="px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100/75 border border-rose-100/50 text-rose-700 font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>تفريغ الحقول</span>
                </button>
              </div>

              {/* Progress Line and Circular Nodes Stepper */}
              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.01)]" dir="rtl">
                <div className="relative flex items-center justify-between w-full px-2">
                  {/* Progress Line */}
                  <div className="absolute top-4.5 left-8 right-8 h-1 bg-slate-100 -z-0">
                    <div
                      className="bg-[#D4A44B] h-full transition-all duration-500 rounded-full"
                      style={{ width: `${getDisplayPercentage(formStep) - (hasGuarantor ? 20 : 25)}%` }}
                    />
                  </div>

                  {/* Step Nodes */}
                  {(hasGuarantor ? [1, 2, 3, 4, 5] : [1, 2, 3, 5]).map((sNum, idx) => {
                    const isDone = formStep === "review" || (typeof formStep === "number" && formStep > sNum);
                    const isCurrent = formStep === sNum;
                    const labels = ["العميل", "المنتج", "الحسابات", "الكفيل", "المستمسكات"];
                    const labelStr = sNum === 5 ? labels[4] : labels[sNum - 1];

                    return (
                      <div
                        key={sNum}
                        onClick={() => {
                          // Allow direct navigation back to previously completed steps or next step if valid
                          if (typeof formStep === "number") {
                            if (sNum < formStep) {
                              setFormStep(sNum);
                            } else if (sNum === formStep + 1 && isCurrentStepValid(formStep)) {
                              setFormStep(sNum);
                            }
                          } else if (formStep === "review") {
                            setFormStep(sNum);
                          }
                        }}
                        className="flex flex-col items-center relative z-10 cursor-pointer group"
                      >
                        <div
                          className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs border-2 transition-all duration-300 ${
                            isDone
                              ? "bg-[#0B1F3A] border-[#0B1F3A] text-white"
                              : isCurrent
                              ? "bg-white border-[#D4A44B] text-[#0B1F3A] ring-4 ring-[#D4A44B]/10 scale-110"
                              : "bg-slate-50 border-slate-200 text-slate-400 group-hover:border-slate-300"
                          }`}
                        >
                          {isDone ? (
                            <Check className="w-4 h-4 text-[#D4A44B]" strokeWidth={3} />
                          ) : (
                            <span>{idx + 1}</span>
                          )}
                        </div>
                        <span
                          className={`text-[10px] font-black mt-2 text-center transition-colors ${
                            isCurrent
                              ? "text-[#D4A44B]"
                              : isDone
                              ? "text-slate-800"
                              : "text-slate-400"
                          }`}
                        >
                          {labelStr}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step Forms inside AnimatePresence */}
              <AnimatePresence mode="wait">
                <form onSubmit={handleAddNewCustomer} className="space-y-6 pb-12">
                  
                  {/* STEP 1: CUSTOMER INFO */}
                  {formStep === 1 && (
                    <motion.div
                      key="step1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-6"
                      dir="rtl"
                    >
                      {/* Step Header */}
                      <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                        <div className="w-8 h-8 rounded-lg bg-[#0B1F3A]/5 text-[#0B1F3A] flex items-center justify-center">
                          <User className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-slate-900">بيانات صاحب القسط العميل</h3>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">يرجى ملء البيانات الشخصية والتحقق منها</p>
                        </div>
                      </div>

                      {/* Guarantor Toggle Selection */}
                      <div className="space-y-2">
                        <label className="text-xs font-black text-slate-700 block mb-1 text-right">نوع ضمان القسط *</label>
                        <div className="grid grid-cols-2 gap-3">
                          <button
                            type="button"
                            onClick={() => {
                              setHasGuarantor(true);
                              localStorage.setItem("draft_hasGuarantor", "true");
                            }}
                            className={`py-3 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 border ${
                              hasGuarantor
                                ? "bg-[#0B1F3A] border-[#0B1F3A] text-white shadow-md shadow-slate-950/10"
                                : "bg-slate-50/50 border-slate-200 text-slate-600 hover:bg-slate-50"
                            }`}
                          >
                            <Users className="w-4 h-4 text-[#D4A44B]" />
                            <span>بوجود كفيل ضامن</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setHasGuarantor(false);
                              localStorage.setItem("draft_hasGuarantor", "false");
                            }}
                            className={`py-3 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 border ${
                              !hasGuarantor
                                ? "bg-[#0B1F3A] border-[#0B1F3A] text-white shadow-md shadow-slate-950/10"
                                : "bg-slate-50/50 border-slate-200 text-slate-600 hover:bg-slate-50"
                            }`}
                          >
                            <User className="w-4 h-4 text-[#D4A44B]" />
                            <span>بدون كفيل (ضمان ذاتي)</span>
                          </button>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {/* Name Input */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">الاسم الكامل الثلاثي لصاحب القسط *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custName}
                              onChange={(e) => {
                                setCustName(e.target.value);
                                if (formErrors.custName) setFormErrors(prev => ({ ...prev, custName: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custName ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <User className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custName && (
                            <span id="err-custName" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custName}</span>
                          )}
                        </div>

                        {/* Phone Input */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">رقم هاتف العميل (يفضل رقم واتساب) *</label>
                          <div className="relative">
                            <input
                              type="tel"
                              value={custPhone}
                              onChange={(e) => {
                                setCustPhone(e.target.value);
                                if (formErrors.custPhone) setFormErrors(prev => ({ ...prev, custPhone: "" }));
                              }}
                              maxLength={11}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custPhone ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Phone className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custPhone && (
                            <span id="err-custPhone" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custPhone}</span>
                          )}
                        </div>

                        {/* Profession / Job */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">المهنة / الوظيفة *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custProfession}
                              onChange={(e) => {
                                setCustProfession(e.target.value);
                                if (formErrors.custProfession) setFormErrors(prev => ({ ...prev, custProfession: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custProfession ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Briefcase className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custProfession && (
                            <span id="err-custProfession" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custProfession}</span>
                          )}
                        </div>

                        {/* National Card ID */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">رقم البطاقة الوطنية الموحدة *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custNationalId}
                              onChange={(e) => {
                                setCustNationalId(e.target.value);
                                if (formErrors.custNationalId) setFormErrors(prev => ({ ...prev, custNationalId: "" }));
                              }}
                              maxLength={12}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custNationalId ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <CreditCard className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custNationalId && (
                            <span id="err-custNationalId" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custNationalId}</span>
                          )}
                        </div>

                        {/* Governorate Select */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">محافظة السكن الحالية *</label>
                          <div className="relative">
                            <select
                              value={custGovernorate}
                              onChange={(e) => {
                                setCustGovernorate(e.target.value);
                                if (formErrors.custGovernorate) setFormErrors(prev => ({ ...prev, custGovernorate: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custGovernorate ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right appearance-none`}
                            >
                              <option value="">-- اختر محافظة السكن --</option>
                              {[
                                "بغداد", "نينوى", "البصرة", "ذي قار", "بابل", "الأنبار", "أربيل", 
                                "النجف", "كربلاء", "القادسية", "واسط", "صلاح الدين", "ميسان", 
                                "السليمانية", "دهوك", "ديالى", "كركوك", "حلبجة", "المثنى"
                              ].map((g) => (
                                <option key={g} value={g}>{g}</option>
                              ))}
                            </select>
                            <MapPin className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                            <ChevronDown className="w-4 h-4 text-slate-500 absolute left-4.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                          </div>
                          {formErrors.custGovernorate && (
                            <span id="err-custGovernorate" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custGovernorate}</span>
                          )}
                        </div>

                        {/* Nearest Landmark */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">أقرب نقطة دالة أو معلّم سكن *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custNearestLandmark}
                              onChange={(e) => {
                                setCustNearestLandmark(e.target.value);
                                if (formErrors.custNearestLandmark) setFormErrors(prev => ({ ...prev, custNearestLandmark: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custNearestLandmark ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Navigation className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custNearestLandmark && (
                            <span id="err-custNearestLandmark" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custNearestLandmark}</span>
                          )}
                        </div>

                        {/* Date Added */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">تاريخ تسجيل المعاملة والبيع *</label>
                          <div className="relative">
                            <input
                              type="date"
                              value={custDateAdded}
                              onChange={(e) => {
                                setCustDateAdded(e.target.value);
                                if (formErrors.custDateAdded) setFormErrors(prev => ({ ...prev, custDateAdded: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custDateAdded ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Calendar className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custDateAdded && (
                            <span id="err-custDateAdded" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custDateAdded}</span>
                          )}
                        </div>

                      </div>

                      {/* Wizard Step Nav */}
                      <div className="flex justify-end pt-5 mt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => {
                            if (validateStep(1)) setFormStep(2);
                          }}
                          className="flex-1 py-4 bg-[#0B1F3A] hover:bg-[#1E293B] text-white font-black text-xs rounded-2xl shadow-lg shadow-slate-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95 border-0"
                        >
                          <span>الخطوة التالية</span>
                          <ArrowLeft className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 2: PRODUCT INFO */}
                  {formStep === 2 && (
                    <motion.div
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-6"
                      dir="rtl"
                    >
                      <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                        <div className="w-8 h-8 rounded-lg bg-[#0B1F3A]/5 text-[#0B1F3A] flex items-center justify-center">
                          <ShoppingBag className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-slate-900">بيانات السلعة والمنتج المباع</h3>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">سجل تفاصيل المادة المبيعة بالتقسيط للزبون</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {/* Product Name */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">نوع أو اسم السلعة المباعة *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={prodName}
                              onChange={(e) => {
                                setProdName(e.target.value);
                                if (formErrors.prodName) setFormErrors(prev => ({ ...prev, prodName: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.prodName ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <ShoppingBag className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.prodName && (
                            <span id="err-prodName" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.prodName}</span>
                          )}
                        </div>

                        {/* Product Details Notes */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">مواصفات وتفاصيل إضافية للسلعة (اختياري)</label>
                          <div className="relative">
                            <textarea
                              value={prodDetails}
                              onChange={(e) => setProdDetails(e.target.value)}
                              rows={3}
                              className="w-full pr-12 pl-4.5 py-3.5 rounded-2xl border border-slate-200 bg-slate-50/10 focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right resize-none"
                            />
                            <ClipboardList className="w-5 h-5 text-slate-400 absolute right-4.5 top-4" />
                          </div>
                        </div>
                      </div>

                      {/* Wizard Step Nav */}
                      <div className="flex gap-3 pt-5 mt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setFormStep(1)}
                          className="w-24 py-4 bg-slate-50 hover:bg-slate-100 text-slate-700 font-black rounded-2xl border border-slate-200/80 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 text-xs border-0"
                        >
                          <ArrowRight className="w-4.5 h-4.5 text-[#D4A44B]" />
                          <span>سابق</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (validateStep(2)) setFormStep(3);
                          }}
                          className="flex-1 py-4 bg-[#0B1F3A] hover:bg-[#1E293B] text-white font-black text-xs rounded-2xl shadow-lg shadow-slate-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95 border-0"
                        >
                          <span>الخطوة التالية</span>
                          <ArrowLeft className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 3: FINANCIAL MATH & INSTALLMENTS */}
                  {formStep === 3 && (
                    <motion.div
                      key="step3"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-6"
                      dir="rtl"
                    >
                      <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                        <div className="w-8 h-8 rounded-lg bg-[#0B1F3A]/5 text-[#0B1F3A] flex items-center justify-center">
                          <Coins className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-slate-900">حسابات مبالغ وتقسيط السلعة</h3>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">ادخل المبالغ والتواريخ ليقوم النظام بجدولتها تلقائياً</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {/* Cash Price */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">السعر النقدي الفعلي للسلعة (سعر الكاش) *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custCashPrice}
                              onChange={(e) => {
                                handleMoneyInputChange(e.target.value, setCustCashPrice);
                                if (formErrors.custCashPrice) setFormErrors(prev => ({ ...prev, custCashPrice: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custCashPrice ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-black text-emerald-600 text-right`}
                            />
                            <Coins className="w-5 h-5 text-emerald-500 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custCashPrice && (
                            <span id="err-custCashPrice" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custCashPrice}</span>
                          )}
                        </div>

                        {/* Total Amount (Installment Price) */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">سعر البيع بالتقسيط (المبلغ الإجمالي الكلي) *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custTotalAmount}
                              onChange={(e) => {
                                handleMoneyInputChange(e.target.value, setCustTotalAmount);
                                if (formErrors.custTotalAmount) setFormErrors(prev => ({ ...prev, custTotalAmount: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custTotalAmount ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-black text-slate-900 text-right`}
                            />
                            <Hash className="w-5 h-5 text-slate-500 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custTotalAmount && (
                            <span id="err-custTotalAmount" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custTotalAmount}</span>
                          )}
                        </div>

                        {/* Upfront (Down Payment) */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">الدفعة المقدمة المدفوعة سلفاً (المقدمة) *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custUpfront}
                              onChange={(e) => {
                                handleMoneyInputChange(e.target.value, setCustUpfront);
                                if (formErrors.custUpfront) setFormErrors(prev => ({ ...prev, custUpfront: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custUpfront ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-black text-blue-600 text-right`}
                            />
                            <Coins className="w-5 h-5 text-blue-500 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custUpfront && (
                            <span id="err-custUpfront" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custUpfront}</span>
                          )}
                        </div>

                        {/* Number of Installment Months */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">عدد أشهر الأقساط (فترة التقسيط) *</label>
                          <div className="relative">
                            <input
                              type="number"
                              min={1}
                              max={120}
                              value={custInstallmentCount}
                              onChange={(e) => {
                                setCustInstallmentCount(e.target.value);
                                if (formErrors.custInstallmentCount) setFormErrors(prev => ({ ...prev, custInstallmentCount: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custInstallmentCount ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Calendar className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custInstallmentCount && (
                            <span id="err-custInstallmentCount" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custInstallmentCount}</span>
                          )}
                        </div>

                        {/* Monthly Installment Amount */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">قيمة القسط الشهري الواحد *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={custMonthly}
                              onChange={(e) => {
                                handleMoneyInputChange(e.target.value, setCustMonthly);
                                if (formErrors.custMonthly) setFormErrors(prev => ({ ...prev, custMonthly: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custMonthly ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-black text-amber-600 text-right`}
                            />
                            <Wallet className="w-5 h-5 text-amber-500 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          <span className="text-[10px] text-slate-400 font-bold block text-right mt-1"> يقوم النظام باحتساب القسط تلقائياً ويمكنك كتابة قيمة مخصصة إذا أردت</span>
                          {formErrors.custMonthly && (
                            <span id="err-custMonthly" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custMonthly}</span>
                          )}
                        </div>

                        {/* Due Day */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">يوم الاستحقاق الشهري (تاريخ الدفع المحدد) *</label>
                          <div className="relative">
                            <input
                              type="number"
                              min={1}
                              max={31}
                              value={custDueDay}
                              onChange={(e) => {
                                setCustDueDay(e.target.value);
                                if (formErrors.custDueDay) setFormErrors(prev => ({ ...prev, custDueDay: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.custDueDay ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Clock className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.custDueDay && (
                            <span id="err-custDueDay" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.custDueDay}</span>
                          )}
                        </div>

                        {/* First Installment Date */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">تاريخ استحقاق أول قسط شهري *</label>
                          <div className="relative">
                            <input
                              type="date"
                              value={firstInstallmentDate}
                              onChange={(e) => {
                                setFirstInstallmentDate(e.target.value);
                                if (formErrors.firstInstallmentDate) setFormErrors(prev => ({ ...prev, firstInstallmentDate: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.firstInstallmentDate ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Calendar className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.firstInstallmentDate && (
                            <span id="err-firstInstallmentDate" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.firstInstallmentDate}</span>
                          )}
                        </div>

                        {/* Calculations Summary Sheet */}
                        <div className="bg-[#FAF9F5] rounded-2xl border border-[#D4A44B]/15 p-4.5 space-y-3.5" dir="rtl">
                          <div className="flex justify-between items-center text-xs font-bold text-slate-600">
                            <span>السعر الكلي بالتقسيط:</span>
                            <span className="font-extrabold text-slate-900">{custTotalAmount || "0"} د.ع</span>
                          </div>
                          <div className="flex justify-between items-center text-xs font-bold text-slate-600">
                            <span>الدفعة المقدمة المدفوعة:</span>
                            <span className="font-extrabold text-emerald-600">-{custUpfront || "0"} د.ع</span>
                          </div>
                          <div className="h-[1px] bg-slate-100" />
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-black text-slate-800">صافي المتبقي في الذمة:</span>
                            <span className="text-base font-black text-[#D4A44B]">
                              {formatNumber(cleanNumber(custTotalAmount) - cleanNumber(custUpfront))} د.ع
                            </span>
                          </div>
                        </div>

                      </div>

                      {/* Wizard Step Nav */}
                      <div className="flex gap-3 pt-5 mt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setFormStep(2)}
                          className="w-24 py-4 bg-slate-50 hover:bg-slate-100 text-slate-700 font-black rounded-2xl border border-slate-200/80 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 text-xs border-0"
                        >
                          <ArrowRight className="w-4.5 h-4.5 text-[#D4A44B]" />
                          <span>سابق</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (validateStep(3)) {
                              // If they checked "Has Guarantor", move to Step 4, otherwise go directly to Step 5
                              setFormStep(hasGuarantor ? 4 : 5);
                            }
                          }}
                          className="flex-1 py-4 bg-[#0B1F3A] hover:bg-[#1E293B] text-white font-black text-xs rounded-2xl shadow-lg shadow-slate-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95 border-0"
                        >
                          <span>الخطوة التالية</span>
                          <ArrowLeft className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 4: GUARANTOR DETAILS (CONDITIONAL) */}
                  {formStep === 4 && hasGuarantor && (
                    <motion.div
                      key="step4"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-6"
                      dir="rtl"
                    >
                      <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                        <div className="w-8 h-8 rounded-lg bg-[#0B1F3A]/5 text-[#0B1F3A] flex items-center justify-center">
                          <Users className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-slate-900">بيانات الكفيل الضامن</h3>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">سجل بيانات الشخص الكافل للعميل</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {/* Guarantor Name */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">الاسم الكامل الثلاثي للكفيل *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={guarantorName}
                              onChange={(e) => {
                                setGuarantorName(e.target.value);
                                if (formErrors.guarantorName) setFormErrors(prev => ({ ...prev, guarantorName: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.guarantorName ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <User className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.guarantorName && (
                            <span id="err-guarantorName" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.guarantorName}</span>
                          )}
                        </div>

                        {/* Guarantor Phone */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">رقم هاتف الكفيل *</label>
                          <div className="relative">
                            <input
                              type="tel"
                              value={guarantorPhone}
                              onChange={(e) => {
                                setGuarantorPhone(e.target.value);
                                if (formErrors.guarantorPhone) setFormErrors(prev => ({ ...prev, guarantorPhone: "" }));
                              }}
                              maxLength={11}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.guarantorPhone ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Phone className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.guarantorPhone && (
                            <span id="err-guarantorPhone" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.guarantorPhone}</span>
                          )}
                        </div>

                        {/* Guarantor Profession */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">مهنة / وظيفة الكفيل *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={guarantorProfession}
                              onChange={(e) => {
                                setGuarantorProfession(e.target.value);
                                if (formErrors.guarantorProfession) setFormErrors(prev => ({ ...prev, guarantorProfession: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.guarantorProfession ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Briefcase className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.guarantorProfession && (
                            <span id="err-guarantorProfession" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.guarantorProfession}</span>
                          )}
                        </div>

                        {/* Guarantor Relationship */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">صلة القرابة بصاحب القسط *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={guarantorRelationship}
                              onChange={(e) => {
                                setGuarantorRelationship(e.target.value);
                                if (formErrors.guarantorRelationship) setFormErrors(prev => ({ ...prev, guarantorRelationship: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.guarantorRelationship ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Heart className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.guarantorRelationship && (
                            <span id="err-guarantorRelationship" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.guarantorRelationship}</span>
                          )}
                        </div>

                        {/* Guarantor National ID */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">رقم البطاقة الوطنية الموحدة للكفيل *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={guarantorNationalId}
                              onChange={(e) => {
                                setGuarantorNationalId(e.target.value);
                                if (formErrors.guarantorNationalId) setFormErrors(prev => ({ ...prev, guarantorNationalId: "" }));
                              }}
                              maxLength={12}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.guarantorNationalId ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <CreditCard className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.guarantorNationalId && (
                            <span id="err-guarantorNationalId" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.guarantorNationalId}</span>
                          )}
                        </div>

                        {/* Guarantor Governorate */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">محافظة سكن الكفيل الحالية *</label>
                          <div className="relative">
                            <select
                              value={guarantorGovernorate}
                              onChange={(e) => {
                                setGuarantorGovernorate(e.target.value);
                                if (formErrors.guarantorGovernorate) setFormErrors(prev => ({ ...prev, guarantorGovernorate: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.guarantorGovernorate ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right appearance-none`}
                            >
                              <option value="">-- اختر محافظة سكن الكفيل --</option>
                              {[
                                "بغداد", "نينوى", "البصرة", "ذي قار", "بابل", "الأنبار", "أربيل", 
                                "النجف", "كربلاء", "القادسية", "واسط", "صلاح الدين", "ميسان", 
                                "السليمانية", "دهوك", "ديالى", "كركوك", "حلبجة", "المثنى"
                              ].map((g) => (
                                <option key={g} value={g}>{g}</option>
                              ))}
                            </select>
                            <MapPin className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                            <ChevronDown className="w-4 h-4 text-slate-500 absolute left-4.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                          </div>
                          {formErrors.guarantorGovernorate && (
                            <span id="err-guarantorGovernorate" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.guarantorGovernorate}</span>
                          )}
                        </div>

                        {/* Guarantor Nearest Landmark */}
                        <div className="space-y-1.5 relative">
                          <label className="text-xs font-black text-slate-700 block mb-1 text-right">أقرب نقطة دالة لسكن الكفيل *</label>
                          <div className="relative">
                            <input
                              type="text"
                              value={guarantorNearestLandmark}
                              onChange={(e) => {
                                setGuarantorNearestLandmark(e.target.value);
                                if (formErrors.guarantorNearestLandmark) setFormErrors(prev => ({ ...prev, guarantorNearestLandmark: "" }));
                              }}
                              className={`w-full pr-12 pl-4.5 py-3.5 rounded-2xl border ${
                                formErrors.guarantorNearestLandmark ? "border-rose-300 bg-rose-50/10" : "border-slate-200 bg-slate-50/10"
                              } focus:bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold text-slate-800 text-right`}
                            />
                            <Navigation className="w-5 h-5 text-slate-400 absolute right-4.5 top-1/2 -translate-y-1/2" />
                          </div>
                          {formErrors.guarantorNearestLandmark && (
                            <span id="err-guarantorNearestLandmark" className="text-[10px] font-black text-rose-600 block mt-1 text-right"> {formErrors.guarantorNearestLandmark}</span>
                          )}
                        </div>
                      </div>

                      {/* Wizard Step Nav */}
                      <div className="flex gap-3 pt-5 mt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setFormStep(3)}
                          className="w-24 py-4 bg-slate-50 hover:bg-slate-100 text-slate-700 font-black rounded-2xl border border-slate-200/80 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 text-xs border-0"
                        >
                          <ArrowRight className="w-4.5 h-4.5 text-[#D4A44B]" />
                          <span>سابق</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (validateStep(4)) setFormStep(5);
                          }}
                          className="flex-1 py-4 bg-[#0B1F3A] hover:bg-[#1E293B] text-white font-black text-xs rounded-2xl shadow-lg shadow-slate-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95 border-0"
                        >
                          <span>الخطوة التالية</span>
                          <ArrowLeft className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 5: DOCUMENT UPLOAD & ATTACHMENTS */}
                  {formStep === 5 && (
                    <motion.div
                      key="step5"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-6"
                      dir="rtl"
                    >
                      <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                        <div className="w-8 h-8 rounded-lg bg-[#0B1F3A]/5 text-[#0B1F3A] flex items-center justify-center">
                          <Camera className="w-4.5 h-4.5 text-[#D4A44B]" />
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-slate-900">رفع وتصوير المستمسكات الرسمية</h3>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">يمكنك تصوير الهويات مباشرة بالهاتف أو رفعها من المعرض</p>
                        </div>
                      </div>

                      {/* Customer Docs Grid */}
                      <div className="space-y-4">
                        <span className="text-xs font-black text-[#D4A44B] block border-r-2 border-[#D4A44B] pr-2.5">الوثائق الثبوتية لصاحب القسط:</span>
                        
                        <div className="grid grid-cols-2 gap-3.5">
                          {/* 1. Customer Personal Image (Centered, prominent profile circle look for high-end feel) */}
                          <div className="col-span-2 bg-slate-50/50 p-4 rounded-2xl border border-slate-100/75 flex flex-col items-center justify-center min-h-[140px] relative overflow-hidden group">
                            <span className="text-[11px] font-black text-slate-700 mb-2.5 block text-center"> الصورة الشخصية للعميل *</span>
                            {images.personal ? (
                              <div className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-white shadow-md group">
                                <img src={images.personal} alt="Personal" className="w-full h-full object-cover" />
                                <button
                                  type="button"
                                  onClick={() => setImages(prev => ({ ...prev, personal: "" }))}
                                  className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white cursor-pointer border-0"
                                >
                                  <X className="w-6 h-6 bg-rose-600 rounded-full p-1 shadow-md" />
                                </button>
                              </div>
                            ) : (
                              <div
                                onClick={() => setUploadTarget({ type: "customer", docKey: "personal", label: "الصورة الشخصية للعميل" })}
                                className="w-20 h-20 rounded-full border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-[#D4A44B]/50 hover:bg-[#D4A44B]/5 transition-all bg-white"
                              >
                                <Camera className="w-4.5 h-4.5 text-slate-400" />
                                <span className="text-[9px] font-bold text-slate-400">التقاط / رفع</span>
                              </div>
                            )}
                          </div>

                          {/* 2. National ID Front */}
                          <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                            {images.idFront ? (
                              <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                <img src={images.idFront} alt="ID Front" className="w-full h-full object-cover" />
                                <button
                                  type="button"
                                  onClick={() => setImages(prev => ({ ...prev, idFront: "" }))}
                                  className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div
                                onClick={() => setUploadTarget({ type: "customer", docKey: "idFront", label: "البطاقة الموحدة (الوجه الأمامي)" })}
                                className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-[#D4A44B]/50 hover:bg-[#D4A44B]/5 transition-all bg-white"
                              >
                                <Camera className="w-6 h-6 text-slate-400" />
                                <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                              </div>
                            )}
                            <span className="text-[10px] font-black text-slate-600 mt-2 block">البطاقة الموحدة (أمام)</span>
                          </div>

                          {/* 3. National ID Back */}
                          <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                            {images.idBack ? (
                              <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                <img src={images.idBack} alt="ID Back" className="w-full h-full object-cover" />
                                <button
                                  type="button"
                                  onClick={() => setImages(prev => ({ ...prev, idBack: "" }))}
                                  className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div
                                onClick={() => setUploadTarget({ type: "customer", docKey: "idBack", label: "البطاقة الموحدة (الوجه الخلفي)" })}
                                className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-[#D4A44B]/50 hover:bg-[#D4A44B]/5 transition-all bg-white"
                              >
                                <Camera className="w-6 h-6 text-slate-400" />
                                <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                              </div>
                            )}
                            <span className="text-[10px] font-black text-slate-600 mt-2 block">البطاقة الموحدة (خلف)</span>
                          </div>

                          {/* 4. Residency Card Front */}
                          <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                            {images.resFront ? (
                              <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                <img src={images.resFront} alt="Residency Front" className="w-full h-full object-cover" />
                                <button
                                  type="button"
                                  onClick={() => setImages(prev => ({ ...prev, resFront: "" }))}
                                  className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div
                                onClick={() => setUploadTarget({ type: "customer", docKey: "resFront", label: "بطاقة السكن (الوجه الأمامي)" })}
                                className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-[#D4A44B]/50 hover:bg-[#D4A44B]/5 transition-all bg-white"
                              >
                                <Camera className="w-6 h-6 text-slate-400" />
                                <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                              </div>
                            )}
                            <span className="text-[10px] font-black text-slate-600 mt-2 block">بطاقة السكن (أمام)</span>
                          </div>

                          {/* 5. Residency Card Back */}
                          <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                            {images.resBack ? (
                              <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                <img src={images.resBack} alt="Residency Back" className="w-full h-full object-cover" />
                                <button
                                  type="button"
                                  onClick={() => setImages(prev => ({ ...prev, resBack: "" }))}
                                  className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div
                                onClick={() => setUploadTarget({ type: "customer", docKey: "resBack", label: "بطاقة السكن (الوجه الخلفي)" })}
                                className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-[#D4A44B]/50 hover:bg-[#D4A44B]/5 transition-all bg-white"
                              >
                                <Camera className="w-6 h-6 text-slate-400" />
                                <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                              </div>
                            )}
                            <span className="text-[10px] font-black text-slate-600 mt-2 block">بطاقة السكن (خلف)</span>
                          </div>
                        </div>
                      </div>

                      {/* Guarantor Docs Grid (Conditional) */}
                      {hasGuarantor && (
                        <div className="space-y-4 pt-4 border-t border-slate-100">
                          <span className="text-xs font-black text-[#D4A44B] block border-r-2 border-[#D4A44B] pr-2.5">المستمسكات والوثائق الخاصة بالكفيل:</span>
                          
                          <div className="grid grid-cols-2 gap-3.5">
                            {/* 1. Guarantor Personal Image */}
                            <div className="col-span-2 bg-slate-50/50 p-4 rounded-2xl border border-slate-100/75 flex flex-col items-center justify-center min-h-[140px] relative overflow-hidden group">
                              <span className="text-[11px] font-black text-slate-700 mb-2.5 block text-center"> الصورة الشخصية للكفيل</span>
                              {guarantorImages.personal ? (
                                <div className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-white shadow-md group">
                                  <img src={guarantorImages.personal} alt="Guarantor Personal" className="w-full h-full object-cover" />
                                  <button
                                    type="button"
                                    onClick={() => setGuarantorImages(prev => ({ ...prev, personal: "" }))}
                                    className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white cursor-pointer border-0"
                                  >
                                    <X className="w-6 h-6 bg-rose-600 rounded-full p-1 shadow-md" />
                                  </button>
                                </div>
                              ) : (
                                <div
                                  onClick={() => setUploadTarget({ type: "guarantor", docKey: "personal", label: "الصورة الشخصية للكفيل" })}
                                  className="w-20 h-20 rounded-full border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-[#D4A44B]/50 hover:bg-[#D4A44B]/5 transition-all bg-white"
                                >
                                  <Camera className="w-4.5 h-4.5 text-slate-400" />
                                  <span className="text-[9px] font-bold text-slate-400">التقاط / رفع</span>
                                </div>
                              )}
                            </div>

                            {/* 2. Guarantor ID Front */}
                            <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                              {guarantorImages.idFront ? (
                                <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                  <img src={guarantorImages.idFront} alt="Guarantor ID Front" className="w-full h-full object-cover" />
                                  <button
                                    type="button"
                                    onClick={() => setGuarantorImages(prev => ({ ...prev, idFront: "" }))}
                                    className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div
                                  onClick={() => setUploadTarget({ type: "guarantor", docKey: "idFront", label: "بطاقة الكفيل الموحدة (الوجه الأمامي)" })}
                                  className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-slate-300 transition-all bg-white"
                                >
                                  <Camera className="w-6 h-6 text-slate-400" />
                                  <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                                </div>
                              )}
                              <span className="text-[10px] font-black text-slate-600 mt-2 block">هوية الكفيل (أمام)</span>
                            </div>

                            {/* 3. Guarantor ID Back */}
                            <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                              {guarantorImages.idBack ? (
                                <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                  <img src={guarantorImages.idBack} alt="Guarantor ID Back" className="w-full h-full object-cover" />
                                  <button
                                    type="button"
                                    onClick={() => setGuarantorImages(prev => ({ ...prev, idBack: "" }))}
                                    className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div
                                  onClick={() => setUploadTarget({ type: "guarantor", docKey: "idBack", label: "بطاقة الكفيل الموحدة (الوجه الخلفي)" })}
                                  className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-slate-300 transition-all bg-white"
                                >
                                  <Camera className="w-6 h-6 text-slate-400" />
                                  <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                                </div>
                              )}
                              <span className="text-[10px] font-black text-slate-600 mt-2 block">هوية الكفيل (خلف)</span>
                            </div>

                            {/* 4. Guarantor Residency Card Front */}
                            <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                              {guarantorImages.resFront ? (
                                <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                  <img src={guarantorImages.resFront} alt="Guarantor Residency Front" className="w-full h-full object-cover" />
                                  <button
                                    type="button"
                                    onClick={() => setGuarantorImages(prev => ({ ...prev, resFront: "" }))}
                                    className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div
                                  onClick={() => setUploadTarget({ type: "guarantor", docKey: "resFront", label: "بطاقة السكن للكفيل (الوجه الأمامي)" })}
                                  className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-slate-300 transition-all bg-white"
                                >
                                  <Camera className="w-6 h-6 text-slate-400" />
                                  <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                                </div>
                              )}
                              <span className="text-[10px] font-black text-slate-600 mt-2 block">سكن الكفيل (أمام)</span>
                            </div>

                            {/* 5. Guarantor Residency Card Back */}
                            <div className="bg-slate-50/50 p-3 rounded-2xl border border-slate-100 text-center flex flex-col justify-between min-h-36 relative overflow-hidden group">
                              {guarantorImages.resBack ? (
                                <div className="relative w-full h-24 rounded-lg overflow-hidden border border-slate-200">
                                  <img src={guarantorImages.resBack} alt="Guarantor Residency Back" className="w-full h-full object-cover" />
                                  <button
                                    type="button"
                                    onClick={() => setGuarantorImages(prev => ({ ...prev, resBack: "" }))}
                                    className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shadow-md border-0"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div
                                  onClick={() => setUploadTarget({ type: "guarantor", docKey: "resBack", label: "بطاقة السكن للكفيل (الوجه الخلفي)" })}
                                  className="w-full h-24 rounded-lg border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-slate-300 transition-all bg-white"
                                >
                                  <Camera className="w-6 h-6 text-slate-400" />
                                  <span className="text-[10px] font-bold text-slate-400">التقاط / رفع صورة</span>
                                </div>
                              )}
                              <span className="text-[10px] font-black text-slate-600 mt-2 block">سكن الكفيل (خلف)</span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Wizard Step Nav */}
                      <div className="flex gap-3 pt-5 mt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setFormStep(hasGuarantor ? 4 : 3)}
                          className="w-24 py-4 bg-slate-50 hover:bg-slate-100 text-slate-700 font-black rounded-2xl border border-slate-200/80 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 text-xs border-0"
                        >
                          <ArrowRight className="w-4.5 h-4.5 text-[#D4A44B]" />
                          <span>سابق</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setFormStep("review")}
                          className="flex-1 py-4 bg-[#D4A44B] hover:bg-[#C3933B] text-white font-black text-xs rounded-2xl shadow-lg shadow-[#D4A44B]/10 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95 border-0"
                        >
                          <Check className="w-4.5 h-4.5 text-[#0B1F3A]" strokeWidth={2.5} />
                          <span>الانتقال للمراجعة النهائية</span>
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP: FINAL REVIEW SCREEN */}
                  {formStep === "review" && (
                    <motion.div
                      key="stepReview"
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      transition={{ duration: 0.3 }}
                      className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-6"
                      dir="rtl"
                    >
                      <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                        <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center">
                          <ShieldCheck className="w-4.5 h-4.5 text-emerald-600" />
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-slate-900">المراجعة النهائية والتدقيق</h3>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">يرجى التأكد من دقة المعلومات المدخلة قبل الحفظ النهائي</p>
                        </div>
                      </div>

                      <div className="space-y-5">
                        
                        {/* 1. Customer Section Summary */}
                        <div className="border border-slate-100 rounded-2xl p-4.5 space-y-3">
                          <div className="flex justify-between items-center border-b border-slate-50 pb-2">
                            <span className="text-xs font-black text-slate-800"> بيانات الزبون (صاحب القسط)</span>
                            <button
                              type="button"
                              onClick={() => setFormStep(1)}
                              className="text-[10px] font-black text-[#D4A44B] hover:underline bg-transparent border-0 cursor-pointer"
                            >
                              تعديل البيانات
                            </button>
                          </div>
                          <div className="grid grid-cols-2 gap-y-2.5 gap-x-4 text-xs font-bold text-slate-600">
                            <div>الاسم الكامل: <span className="text-slate-900 font-extrabold">{custName}</span></div>
                            <div>رقم الهاتف: <span className="text-slate-900 font-mono font-extrabold">{custPhone}</span></div>
                            <div>المهنة: <span className="text-slate-900 font-extrabold">{custProfession}</span></div>
                            <div>محافظة السكن: <span className="text-slate-900 font-extrabold">{custGovernorate}</span></div>
                            <div className="col-span-2 text-right">المعلم/النقطة الدالة: <span className="text-slate-900 font-extrabold">{custNearestLandmark}</span></div>
                          </div>
                        </div>

                        {/* 2. Product Section Summary */}
                        <div className="border border-slate-100 rounded-2xl p-4.5 space-y-3">
                          <div className="flex justify-between items-center border-b border-slate-50 pb-2">
                            <span className="text-xs font-black text-slate-800"> بيانات السلعة والمنتج</span>
                            <button
                              type="button"
                              onClick={() => setFormStep(2)}
                              className="text-[10px] font-black text-[#D4A44B] hover:underline bg-transparent border-0 cursor-pointer"
                            >
                              تعديل البيانات
                            </button>
                          </div>
                          <div className="grid grid-cols-2 gap-y-2.5 gap-x-4 text-xs font-bold text-slate-600">
                            <div className="col-span-2 text-right">نوع السلعة: <span className="text-slate-900 font-extrabold">{prodName}</span></div>
                            <div className="col-span-2 text-right">المواصفات: <span className="text-slate-900 font-extrabold">{prodDetails || "لا يوجد تفاصيل مخصصة"}</span></div>
                          </div>
                        </div>

                        {/* 3. Financial Summary */}
                        <div className="border border-[#D4A44B]/15 bg-[#FAF9F5]/40 rounded-2xl p-4.5 space-y-3">
                          <div className="flex justify-between items-center border-b border-[#D4A44B]/10 pb-2">
                            <span className="text-xs font-black text-slate-800"> الجدولة والحسابات المالية</span>
                            <button
                              type="button"
                              onClick={() => setFormStep(3)}
                              className="text-[10px] font-black text-[#D4A44B] hover:underline bg-transparent border-0 cursor-pointer"
                            >
                              تعديل المبالغ
                            </button>
                          </div>
                          <div className="grid grid-cols-2 gap-y-2.5 gap-x-4 text-xs font-bold text-slate-600">
                            <div>السعر الكلي: <span className="text-slate-900 font-extrabold">{custTotalAmount} د.ع</span></div>
                            <div>الدفعة المقدمة: <span className="text-emerald-600 font-extrabold">{custUpfront || "0"} د.ع</span></div>
                            <div>عدد الأشهر: <span className="text-slate-900 font-extrabold">{custInstallmentCount} شهر</span></div>
                            <div>القسط الشهري: <span className="text-amber-600 font-black">{custMonthly} د.ع</span></div>
                            <div>يوم الدفع المحدد: <span className="text-slate-900 font-extrabold">يوم {custDueDay} من كل شهر</span></div>
                            <div>أول تاريخ دفع: <span className="text-slate-900 font-mono font-extrabold">{firstInstallmentDate}</span></div>
                          </div>
                        </div>

                        {/* 4. Guarantor Summary (If exists) */}
                        {hasGuarantor && (
                          <div className="border border-slate-100 rounded-2xl p-4.5 space-y-3">
                            <div className="flex justify-between items-center border-b border-slate-50 pb-2">
                              <span className="text-xs font-black text-slate-800"> الكفيل الضامن</span>
                              <button
                                type="button"
                                onClick={() => setFormStep(4)}
                                className="text-[10px] font-black text-[#D4A44B] hover:underline bg-transparent border-0 cursor-pointer"
                              >
                                تعديل بيانات الكفيل
                              </button>
                            </div>
                            <div className="grid grid-cols-2 gap-y-2.5 gap-x-4 text-xs font-bold text-slate-600">
                              <div>الاسم الكامل: <span className="text-slate-900 font-extrabold">{guarantorName}</span></div>
                              <div>رقم هاتف الكفيل: <span className="text-slate-900 font-mono font-extrabold">{guarantorPhone}</span></div>
                              <div>المهنة: <span className="text-slate-900 font-extrabold">{guarantorProfession}</span></div>
                              <div>القرابة بالزبون: <span className="text-slate-900 font-extrabold">{guarantorRelationship}</span></div>
                              <div className="col-span-2 text-right">عنوان سكن الكفيل: <span className="text-slate-900 font-extrabold">{guarantorGovernorate} - {guarantorNearestLandmark}</span></div>
                            </div>
                          </div>
                        )}

                        {/* 5. Documents summary */}
                        <div className="border border-slate-100 rounded-2xl p-4.5 space-y-3">
                          <span className="text-xs font-black text-slate-800 block border-b border-slate-50 pb-2"> المرفقات والمستمسكات المحملة</span>
                          <div className="flex gap-2 flex-wrap text-right">
                            {images.personal && <span className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-[10px] font-bold rounded-lg text-slate-700">الصورة الشخصية للعميل</span>}
                            {images.idFront && <span className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-[10px] font-bold rounded-lg text-slate-700">البطاقة الموحدة (وجه)</span>}
                            {images.idBack && <span className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-[10px] font-bold rounded-lg text-slate-700">البطاقة الموحدة (ظهر)</span>}
                            {images.resFront && <span className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-[10px] font-bold rounded-lg text-slate-700">بطاقة سكن العميل (وجه)</span>}
                            {images.resBack && <span className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-[10px] font-bold rounded-lg text-slate-700">بطاقة سكن العميل (ظهر)</span>}
                            {hasGuarantor && guarantorImages.idFront && <span className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-[10px] font-bold rounded-lg text-slate-700">هوية الكفيل (وجه)</span>}
                            {hasGuarantor && guarantorImages.idBack && <span className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-[10px] font-bold rounded-lg text-slate-700">هوية الكفيل (ظهر)</span>}
                            {!images.personal && !images.idFront && !images.idBack && !images.resFront && !images.resBack && <span className="text-xs text-amber-600 font-bold"> لم يتم رفع أي مستمسكات حتى الآن. يمكنك الحفظ والمتابعة أو رفعها لاحقاً.</span>}
                          </div>
                        </div>

                      </div>

                      {/* Submit & Go Back Buttons */}
                      <div className="flex gap-3 pt-5 mt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setFormStep(5)}
                          className="w-24 py-4 bg-slate-50 hover:bg-slate-100 text-slate-700 font-black rounded-2xl border border-slate-200/80 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 text-xs border-0"
                        >
                          <ArrowRight className="w-4.5 h-4.5 text-[#D4A44B]" />
                          <span>سابق</span>
                        </button>
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className={`flex-1 py-4 text-xs font-black rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 border-0 ${
                            isSubmitting
                              ? "bg-slate-400 cursor-not-allowed shadow-none text-white"
                              : "bg-[#0B1F3A] hover:bg-[#1E293B] text-white shadow-slate-900/15 cursor-pointer active:scale-95"
                          }`}
                        >
                          {isSubmitting ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              <span>جاري معالجة وحفظ القسط...</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-4.5 h-4.5 text-[#D4A44B]" />
                              <span>حفظ وتأكيد القسط نهائياً</span>
                            </>
                          )}
                        </button>
                      </div>
                    </motion.div>
                  )}

                </form>
              </AnimatePresence>
            </div>
          )}

          {/* SCREEN 2: CUSTOMERS LIST & FILTER */}
          {currentScreen === "list" && (
            <div className="space-y-4">
              
              <div className="space-y-3 pb-1">
                {/* Smart Alert Alert Banner */}
                {dueCustomers.length > 0 && (
                  <div className="bg-amber-50/75 border border-amber-200 text-amber-900 p-4 rounded-2xl shadow-sm flex items-start gap-3">
                    <div className="p-1 bg-amber-100 text-amber-800 rounded-lg mt-0.5">
                      <AlertCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-amber-950 text-right"> تنبيهات الاستحقاق:</h4>
                      <p className="text-xs mt-1 leading-relaxed text-right">
                        يوجد <strong className="text-red-700 underline">{dueCustomers.length}</strong> من العملاء يستحق موعد قسطهم أو تجاوزه!
                      </p>
                    </div>
                  </div>
                )}

                {/* Search & Filter Buttons */}
                <div className="bg-slate-50 pb-3 pt-1.5 border-b border-slate-100/80 shadow-sm space-y-2">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchText}
                      onChange={(e) => setSearchText(e.target.value)}
                      className="w-full pl-4 pr-10 py-3.5 rounded-xl border border-slate-200 bg-white focus:ring-4 focus:ring-[#0B1F3A]/5 focus:border-[#0B1F3A] outline-none transition-all text-sm font-semibold shadow-inner text-right"
                    />
                    <Search className="w-5 h-5 text-slate-400 absolute top-3.5 right-3.5" />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setCurrentFilter("all")}
                      className={`py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        currentFilter === "all"
                          ? "bg-[#0B1F3A] text-white shadow-md shadow-slate-900/10"
                          : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                       كل عملاء الأقساط ({customers.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentFilter("due")}
                      className={`py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                        currentFilter === "due"
                          ? "bg-amber-600 text-white shadow-md shadow-amber-600/20"
                          : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>المستحقين للدفع ({dueCustomers.length})</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Customers Grid list */}
              <div className="space-y-3">
                {filteredCustomers.length === 0 ? (
                  <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-500">
                    <UserPlus className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="text-sm font-bold">لا يوجد أي سجلات مطابقة للبحث حالياً.</p>
                    <p className="text-xs text-slate-400 mt-1">يمكنك إضافة قسط جديد من التبويب السفلي.</p>
                  </div>
                ) : (
                  filteredCustomers.slice(0, visibleCount).map((c) => {
                    const isDue = isCustomerDue(c);
                    const isCompleted = c.status === "done";
                    
                    let statusBadgeColor = "bg-emerald-50 text-emerald-700 border-emerald-200";
                    let statusText = "مستمر بالدفع";
 
                    if (isCompleted) {
                      statusBadgeColor = "bg-slate-100 text-slate-500 border-slate-200";
                      statusText = "مكتمل السداد";
                    } else if (isDue) {
                      statusBadgeColor = "bg-red-50 text-red-600 border-red-200 animate-pulse";
                      statusText = " يستحق الدفع";
                    }
 
                    const defaultAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23cbd5e1"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`;
 
                    return (
                      <div
                        key={c.id}
                        className="bg-white rounded-[20px] border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] hover:shadow-[0_12px_36px_rgba(11,31,58,0.06)] hover:border-[#D4A44B]/50 transition-all duration-300 p-6 relative overflow-hidden flex flex-col gap-4 group text-right"
                      >
                        {/* Decorative subtle colored bar matching status */}
                        <div className={`absolute top-0 right-0 bottom-0 w-1.5 ${
                          isCompleted ? "bg-slate-300" : isDue ? "bg-rose-600" : "bg-[#D4A44B]"
                        }`} />

                        {/* Top customer info & Status row */}
                        <div className="flex justify-between items-start pl-1 pr-1">
                          {/* Left-aligned Status badge */}
                          <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full border flex items-center gap-1.5 shadow-sm ${statusBadgeColor}`}>
                            <span className={`w-1.5 h-1.5 rounded-full bg-current ${isDue ? "animate-ping" : ""}`}></span>
                            {statusText}
                          </span>

                          {/* Right-aligned Name and Avatar */}
                          <div
                            onClick={() => viewCustomerDetails(c.id)}
                            className="flex items-center gap-3 text-right cursor-pointer"
                          >
                            <div className="text-right">
                              <h3 className="font-extrabold text-sm text-slate-900 group-hover:text-[#D4A44B] transition-colors leading-tight">
                                {c.name}
                              </h3>
                              <span className="text-[10px] text-slate-400 font-semibold block mt-0.5 font-sans" dir="ltr">
                                {c.phone} 
                              </span>
                            </div>
                            <img
                              src={c.images?.personal || defaultAvatar}
                              alt="Avatar"
                              className="w-11 h-11 rounded-full object-cover border border-slate-200 bg-slate-50 shadow-sm hover:scale-105 transition-transform"
                            />
                          </div>
                        </div>

                        {/* Product and schedule info strip */}
                        <div 
                          onClick={() => viewCustomerDetails(c.id)}
                          className="flex flex-wrap gap-1.5 items-center bg-slate-50 p-2 rounded-xl border border-slate-100/60 text-[11px] font-bold text-slate-700 cursor-pointer justify-end pr-2"
                        >
                          {!isCompleted && (
                            <span className="bg-amber-500/10 text-amber-800 px-2 py-0.5 rounded-lg border border-amber-500/10">
                               الاستحقاق: {formatNextDueDate(getCustomerNextDueDate(c))}
                            </span>
                          )}
                          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-lg border border-slate-200">
                             {c.productName}
                          </span>
                        </div>

                        {/* Money Summary Grid with Android-style metrics */}
                        <div
                          onClick={() => viewCustomerDetails(c.id)}
                          className="grid grid-cols-2 gap-3.5 bg-slate-50/50 p-3 rounded-2xl border border-slate-100/50 text-xs text-right pr-2 cursor-pointer"
                        >
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">الواصل الإجمالي:</span>
                            <span className="font-extrabold text-emerald-600 block mt-0.5">
                              {formatNumber(c.totalAmount - c.remainingAmount)} د.ع
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">المتبقي الصافي:</span>
                            <span className="font-extrabold text-red-600 block mt-0.5">
                              {formatNumber(c.remainingAmount)} د.ع
                            </span>
                          </div>
                        </div>

                        {/* Android-style Action Bar */}
                        <div className="flex gap-2 justify-end pt-1 pr-1 border-t border-dashed border-slate-100">
                          {/* Quick Message */}
                          <button
                            type="button"
                            onClick={() => setTemplateModalCustomer(c)}
                            className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-100 rounded-xl transition-all cursor-pointer text-xs font-extrabold flex items-center gap-1.5"
                          >
                            <MessageCircle className="w-4 h-4 text-emerald-600" />
                            <span>تذكير</span>
                          </button>

                          {/* Quick Call */}
                          <a
                            href={`tel:${c.phone}`}
                            className="px-3 py-2 bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-100 rounded-xl transition-all text-xs font-bold flex items-center justify-center gap-1"
                            title="اتصال هاتفي سريع"
                          >
                            <Phone className="w-4 h-4" />
                          </a>

                          {/* View Profile */}
                          <button
                            type="button"
                            onClick={() => viewCustomerDetails(c.id)}
                            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all text-xs font-extrabold cursor-pointer"
                          >
                            عرض الحساب
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* SCREEN 3: CUSTOMER DETAIL PANEL */}
          {currentScreen === "detail" && selectedCustomerId && (() => {
            const customer = activeFullCustomer || customers.find((c) => c.id === selectedCustomerId);
            if (!customer) return <p className="text-center py-10">العميل غير موجود.</p>;

            const defaultAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23cbd5e1"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`;

            return (
              <div className="space-y-4">
                {/* Back Button */}
                <button
                  type="button"
                  onClick={() => setCurrentScreen("list")}
                  className="bg-white border border-slate-200 text-slate-700 text-xs font-bold py-2 px-4 rounded-xl hover:bg-slate-50 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>العودة لقائمة العملاء</span>
                </button>

                {/* Profile header card */}
                <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] text-center space-y-3">
                  <img
                    src={customer.images?.personal || defaultAvatar}
                    alt="avatar"
                    className="w-20 h-20 rounded-full object-cover mx-auto border-2 border-slate-200 bg-slate-50"
                  />
                  <div className="space-y-1">
                    <h2 className="text-lg font-extrabold text-slate-900">{customer.name}</h2>
                    <p className="text-xs font-semibold text-slate-500 tracking-wide">{customer.phone}</p>
                    {customer.nationalId && (
                      <div className="mt-2 text-xs font-bold text-slate-700 bg-slate-50 border border-slate-200 py-1 px-3 rounded-lg inline-block">
                        البطاقة الوطنية للعميل: <span className="font-mono text-[#0B1F3A] font-black">{customer.nationalId}</span>
                      </div>
                    )}
                    {(customer.governorate || customer.nearestLandmark) && (
                      <div className="mt-1.5 flex flex-wrap justify-center gap-1.5 text-xs font-bold text-slate-700">
                        {customer.governorate && (
                          <span className="bg-slate-50 border border-slate-200 py-1 px-3 rounded-lg">
                            المحافظة: <span className="text-[#0B1F3A] font-black">{customer.governorate}</span>
                          </span>
                        )}
                        {customer.nearestLandmark && (
                          <span className="bg-slate-50 border border-slate-200 py-1 px-3 rounded-lg">
                            أقرب نقطة دالة: <span className="text-[#0B1F3A] font-black">{customer.nearestLandmark}</span>
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Triggers template chooser modal */}
                  <button
                    type="button"
                    onClick={() => setTemplateModalCustomer(customer)}
                    className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-extrabold shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>مراسلة واختيار نموذج رسالة جاهزة</span>
                  </button>
                </div>

                {/* Product details card */}
                <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-3 border-r-4 border-r-[#0B1F3A] text-right">
                    <h3 className="font-extrabold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                      <span>تفاصيل المادة المبيعة</span>
                    </h3>
                  
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">اسم المنتج:</span>
                    <span className="font-bold text-slate-800">{customer.productName}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">تفاصيل ومواصفات المنتج:</span>
                    <span className="font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">{customer.productDetails || customer.productSerial || "غير محدد"}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">تاريخ تسجيل المعاملة:</span>
                    <span className="font-bold text-slate-800">{customer.dateAdded}</span>
                  </div>
                </div>

                {/* Guarantor Details Card */}
                {customer.hasGuarantor && customer.guarantor && (
                  <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-3.5 border-r-4 border-r-[#D4A44B] text-right">
                    <h3 className="font-extrabold text-sm text-[#0B1F3A] pb-2 border-b border-slate-100 flex items-center gap-1.5">
                      <span> تفاصيل وبيانات الكفيل الضامن</span>
                    </h3>
                    
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500">اسم الكفيل الثلاثي:</span>
                      <span className="font-extrabold text-slate-800">{customer.guarantor.name}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500">رقم هاتف الكفيل:</span>
                      <div className="flex items-center gap-1">
                        <a href={`tel:${customer.guarantor.phone}`} className="text-[#0B1F3A] font-extrabold underline">{customer.guarantor.phone}</a>
                        <span></span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500">عنوان سكن الكفيل:</span>
                      <span className="font-bold text-slate-800">{customer.guarantor.address}</span>
                    </div>
                    {customer.guarantor.nationalId && (
                      <div className="flex justify-between items-center text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                        <span className="text-slate-600 font-bold">رقم البطاقة الوطنية للكفيل:</span>
                        <span className="font-black text-[#0B1F3A] font-mono">{customer.guarantor.nationalId}</span>
                      </div>
                    )}

                    {/* Guarantor Documents preview */}
                    {customer.guarantor?.images && (
                      <div className="pt-2.5 border-t border-slate-100 space-y-2">
                        <span className="text-[11px] font-extrabold text-[#D4A44B] block">🪪 وثائق الكفيل الضامن (اضغط للتكبير):</span>
                        <div className="grid grid-cols-5 gap-1.5">
                          {customer.guarantor.images?.personal && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">الوجه</span>
                              <img
                                src={customer.guarantor.images.personal}
                                alt="Guarantor Face"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.personal || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images?.idFront && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">موحدة أ</span>
                              <img
                                src={customer.guarantor.images.idFront}
                                alt="Guarantor ID Front"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.idFront || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images?.idBack && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">موحدة خ</span>
                              <img
                                src={customer.guarantor.images.idBack}
                                alt="Guarantor ID Back"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.idBack || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images?.resFront && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">سكن أ</span>
                              <img
                                src={customer.guarantor.images.resFront}
                                alt="Guarantor Res Front"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.resFront || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images?.resBack && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">سكن خ</span>
                              <img
                                src={customer.guarantor.images.resBack}
                                alt="Guarantor Res Back"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.resBack || null)}
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Financial Status Card */}
                <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-3 text-right">
                  <h3 className="font-extrabold text-sm text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                    <span> المبالغ وتواريخ الدفع</span>
                  </h3>

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">السعر الكلي للمادة:</span>
                    <span className="font-extrabold text-slate-800">{formatNumber(customer.totalAmount)} د.ع</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">المقدمة المدفوعة:</span>
                    <span className="font-bold text-slate-800">{formatNumber(customer.upfront)} د.ع</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">القسط الشهري المحدد:</span>
                    <span className="font-bold text-slate-800">{formatNumber(customer.monthlyAmount)} د.ع</span>
                  </div>
                  
                  <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 flex flex-col gap-1.5 text-xs text-amber-900">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold">يوم السداد المحدد:</span>
                      <span className="font-extrabold">يوم {customer.dueDay} في كل شهر</span>
                    </div>
                    {customer.status === "active" && (
                      <div className="flex justify-between items-center border-t border-amber-200/60 pt-1.5 mt-0.5">
                        <span className="font-extrabold text-amber-950">تاريخ الاستحقاق القادم:</span>
                        <span className="font-extrabold text-red-700 underline font-mono">
                          {formatNextDueDate(getCustomerNextDueDate(customer))}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                    <span className="text-sm font-bold text-slate-700">المتبقي الصافي للذمة:</span>
                    <span className="text-xl font-extrabold text-red-600">{formatNumber(customer.remainingAmount)} د.ع</span>
                  </div>
                </div>

                {/* Submit Payment Card */}
                {customer.remainingAmount > 0 ? (
                  <div className="bg-emerald-50 rounded-2xl p-5 border border-emerald-200 shadow-sm space-y-4 text-right">
                    <h3 className="font-extrabold text-sm text-emerald-900 flex items-center gap-1.5">
                      <DollarSign className="w-5 h-5 text-emerald-600" />
                      <span> تسديد دفعة أو قسط جديد</span>
                    </h3>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-600">اكتب مبلغ الدفع بالدينار العراقي:</label>
                      <input
                        type="text"
                        value={payAmountInput}
                        onChange={(e) => handleMoneyInputChange(e.target.value, setPayAmountInput)}
                        className="w-full px-4 py-3 rounded-xl border border-emerald-300 bg-white focus:ring-4 focus:ring-emerald-100 focus:border-emerald-500 outline-none transition-all text-base font-bold text-emerald-900 text-right"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-600">تاريخ تسجيل الدفع (تلقائي أو اختر يدوياً):</label>
                      <input
                        type="date"
                        value={payDateInput}
                        onChange={(e) => setPayDateInput(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-emerald-300 bg-white focus:ring-4 focus:ring-emerald-100 focus:border-emerald-500 outline-none transition-all text-sm font-bold text-slate-800 text-right"
                      />
                    </div>

                    <button
                      type="button"
                      disabled={isPaying}
                      onClick={() => handlePaymentSubmit(customer.id)}
                      className={`w-full py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 active:scale-[0.98] transition-all text-sm flex items-center justify-center gap-2 ${
                        isPaying ? "opacity-75 cursor-not-allowed" : "cursor-pointer"
                      }`}
                    >
                      {isPaying ? (
                        <>
                          <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin inline-block" />
                          <span>جاري تسجيل وتأكيد الدفعة...</span>
                        </>
                      ) : (
                        <span> تأكيد وتسجيل الدفعة الحالية</span>
                      )}
                    </button>
                  </div>
                ) : (
                  <div className="bg-slate-100 text-slate-600 border border-slate-300 rounded-2xl p-5 text-center font-bold text-sm">
                     تم سداد كافة الأقساط بالكامل وإبراء ذمة العميل بنجاح!
                  </div>
                )}

                {/* Receipt and payment log history */}
                <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-3 text-right">
                  <h3 className="font-extrabold text-sm text-slate-900 pb-2 border-b border-slate-100">
                    سجل الوصولات السابقة والمدفوعات
                  </h3>

                  {!customer.payments || customer.payments.length === 0 ? (
                    <p className="text-center text-xs text-slate-400 py-4 font-medium">لا توجد أي سحوبات أو سدادات مسجلة حالياً.</p>
                  ) : (
                    <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto pr-1">
                      {customer.payments.map((p, index) => (
                        <div key={index} className="flex justify-between items-center py-2.5 text-xs px-2 rounded-lg hover:bg-slate-50 transition-colors">
                          <span className="text-slate-500 font-semibold">{p.date}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-emerald-600 font-extrabold bg-emerald-50 border border-emerald-100 px-2.5 py-0.5 rounded-full">
                              + {formatNumber(p.amount)} د.ع
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setThermalReceiptData({
                                  title: "وصل استلام دفعة مالية",
                                  customerName: customer.name,
                                  customerPhone: customer.phone,
                                  productName: customer.productName,
                                  totalAmount: customer.totalAmount,
                                  paidAmount: p.amount,
                                  remainingAmount: customer.remainingAmount,
                                  monthlyAmount: customer.monthlyAmount,
                                  dueDay: customer.dueDay,
                                  date: p.date,
                                  nextDueDate: formatNextDueDate(getCustomerNextDueDate(customer))
                                });
                              }}
                              className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
                              title="طباعة الوصل الحراري 80mm"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Document verification images archive */}
                {customer.images && Object.values(customer.images).some(val => !!val) && (
                  <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-4 text-right">
                    <h3 className="font-extrabold text-sm text-slate-900 border-b border-slate-100 pb-2">
                      🪪 أرشيف المستمسكات والوثائق المرفقة (اضغط للتكبير)
                    </h3>

                    <div className="grid grid-cols-2 gap-3.5">
                      {customer.images?.resFront && (
                        <div className="text-center space-y-1">
                          <span className="text-[10px] font-bold text-slate-500 block">بطاقة السكن - الوجه الأمامي</span>
                          <img
                            src={customer.images.resFront}
                            alt="Residence Card Front"
                            className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                            onClick={() => setPreviewImageSrc(customer.images?.resFront || null)}
                          />
                        </div>
                      )}
                      {customer.images?.resBack && (
                        <div className="text-center space-y-1">
                          <span className="text-[10px] font-bold text-slate-500 block">بطاقة السكن - الوجه الخلفي</span>
                          <img
                            src={customer.images.resBack}
                            alt="Residence Card Back"
                            className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                            onClick={() => setPreviewImageSrc(customer.images?.resBack || null)}
                          />
                        </div>
                      )}
                      {customer.images?.idFront && (
                        <div className="text-center space-y-1">
                          <span className="text-[10px] font-bold text-slate-500 block">البطاقة الوطنية - الوجه الأمامي</span>
                          <img
                            src={customer.images.idFront}
                            alt="ID Card Front"
                            className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                            onClick={() => setPreviewImageSrc(customer.images?.idFront || null)}
                          />
                        </div>
                      )}
                      {customer.images?.idBack && (
                        <div className="text-center space-y-1">
                          <span className="text-[10px] font-bold text-slate-500 block">البطاقة الوطنية - الوجه الخلفي</span>
                          <img
                            src={customer.images.idBack}
                            alt="ID Card Back"
                            className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                            onClick={() => setPreviewImageSrc(customer.images?.idBack || null)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Permanent Delete Button with custom confirmation modal trigger */}
                <button
                  type="button"
                  onClick={() => setDeleteConfirmId(customer.id)}
                  className="w-full py-3.5 bg-rose-50 text-rose-600 border border-rose-200 rounded-xl font-extrabold hover:bg-rose-100/80 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                >
                  <Trash2 className="w-5 h-5" />
                  <span> حذف ملف هذا الزبون نهائياً</span>
                </button>
              </div>
          );
          })()}

          {/* SCREEN 4: ALERTS / NOTIFICATIONS SCREEN */}
          {currentScreen === "alerts" && (
            <div className="space-y-4">
              
              <div className="space-y-3 pb-2">
                {/* Header card with summary statistics */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-right space-y-3">
                  <div className="flex items-center gap-2 text-[#0B1F3A] font-bold">
                    <Bell className="w-5 h-5 text-[#D4A44B]" />
                    <span> مركز تتبع واستحقاق الأقساط</span>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                    يقوم هذا المركز تلقائياً بتحليل حسابات الزبائن وتحديد المواعيد القادمة، المتأخرة، أو المستحقة بناءً على الأشهر الفعلية وعمليات السداد السابقة.
                  </p>
                  
                  {/* Visual statistics cards */}
                  <div className="grid grid-cols-3 gap-2 text-center pt-2">
                    <div className="bg-rose-50 border border-rose-200 rounded-xl p-2">
                      <span className="text-[10px] font-extrabold text-rose-800 block">متأخر عن السداد</span>
                      <span className="text-sm font-black text-rose-700">
                        {customerAlerts.filter(a => a.status === "overdue").length}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-2">
                      <span className="text-[10px] font-extrabold text-amber-800 block">مستحق اليوم</span>
                      <span className="text-sm font-black text-amber-700">
                        {customerAlerts.filter(a => a.status === "due_today").length}
                      </span>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-2">
                      <span className="text-[10px] font-extrabold text-yellow-800 block">يقترب موعده</span>
                      <span className="text-sm font-black text-yellow-700">
                        {customerAlerts.filter(a => a.status === "approaching").length}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Alert Level Filter Pills */}
                <div className="flex gap-1.5 overflow-x-auto pb-1" dir="rtl">
                  <button
                    type="button"
                    onClick={() => setAlertFilter("all")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "all"
                        ? "bg-[#0B1F3A] text-white border-[#0B1F3A] shadow-sm"
                        : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                    }`}
                  >
                    الكل ({customerAlerts.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlertFilter("overdue")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "overdue"
                        ? "bg-rose-600 text-white border-rose-700 shadow-sm animate-pulse"
                        : "bg-white text-rose-600 border-rose-200 hover:bg-rose-50"
                    }`}
                  >
                    متأخر عن السداد ({customerAlerts.filter(a => a.status === "overdue").length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlertFilter("due_today")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "due_today"
                        ? "bg-amber-600 text-white border-amber-700 shadow-sm"
                        : "bg-white text-amber-600 border-amber-200 hover:bg-slate-50"
                    }`}
                  >
                    مستحق اليوم ({customerAlerts.filter(a => a.status === "due_today").length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlertFilter("approaching")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "approaching"
                        ? "bg-yellow-500 text-slate-900 border-yellow-600 shadow-sm"
                        : "bg-white text-yellow-600 border-yellow-200 hover:bg-slate-50"
                    }`}
                  >
                    يقترب السداد ({customerAlerts.filter(a => a.status === "approaching").length})
                  </button>
                </div>
              </div>

              {/* List of Alerts */}
              <div className="space-y-3">
                {(() => {
                  const filtered = customerAlerts.filter(a => alertFilter === "all" || a.status === alertFilter);
                  
                  if (filtered.length === 0) {
                    return (
                      <div className="bg-white rounded-2xl p-8 border border-slate-200/80 shadow-sm text-center space-y-3">
                        <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto text-3xl shadow-inner animate-pulse">
                          
                        </div>
                        <h4 className="font-extrabold text-sm text-slate-800">تنبيهات فارغة ومطابقة تماماً!</h4>
                        <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                          لا توجد أقساط مطابقة لهذا الفلتر في الوقت الحالي. جميع الحسابات منتظمة!
                        </p>
                      </div>
                    );
                  }

                  return filtered.map((alert) => {
                    const c = alert.customer;
                    const defaultAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23cbd5e1"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`;
                    
                    let badgeStyles = "";
                    if (alert.status === "overdue") {
                      badgeStyles = "bg-rose-50 text-rose-700 border-rose-200";
                    } else if (alert.status === "due_today") {
                      badgeStyles = "bg-amber-500 text-white border-amber-600 animate-pulse";
                    } else if (alert.status === "approaching") {
                      badgeStyles = "bg-yellow-50 text-yellow-800 border-yellow-200";
                    }

                    return (
                      <div
                        key={c.id}
                        className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm hover:shadow-md transition-all flex flex-col gap-3 relative overflow-hidden text-right"
                      >
                        {/* Decorative side accent bar */}
                        <div className={`absolute top-0 right-0 bottom-0 w-1.5 ${
                          alert.status === "overdue" ? "bg-rose-600" :
                          alert.status === "due_today" ? "bg-amber-500 animate-pulse" : "bg-yellow-400"
                        }`} />

                        {/* Top customer and badge row */}
                        <div className="flex justify-between items-start pl-1 pr-2">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={c.images?.personal || defaultAvatar}
                              alt={c.name}
                              className="w-10 h-10 rounded-full object-cover border border-slate-200 bg-slate-100 flex-shrink-0"
                            />
                            <div className="text-right">
                              <h4 className="font-extrabold text-xs text-slate-900 hover:text-[#D4A44B] transition-colors cursor-pointer" onClick={() => viewCustomerDetails(c.id)}>
                                {c.name}
                              </h4>
                              <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">
                                 {c.phone}
                              </span>
                            </div>
                          </div>

                          <span className={`text-[10px] font-extrabold px-2 py-1 rounded-lg border ${badgeStyles}`}>
                            {alert.statusText}
                          </span>
                        </div>

                        {/* Middle financial details */}
                        <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100/60 text-xs text-right pr-4">
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">المادة / الجهاز:</span>
                            <span className="font-bold text-slate-800 block truncate mt-0.5"> {c.productName}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">القسط الشهري المطلوب:</span>
                            <span className="font-extrabold text-[#0B1F3A] block mt-0.5">{formatNumber(c.monthlyAmount)} د.ع</span>
                          </div>
                          <div className="mt-1.5">
                            <span className="text-slate-400 block text-[9px] font-bold">المتبقي الإجمالي:</span>
                            <span className="font-extrabold text-rose-600 block mt-0.5">{formatNumber(c.remainingAmount)} د.ع</span>
                          </div>
                          <div className="mt-1.5">
                            <span className="text-slate-400 block text-[9px] font-bold">تاريخ الاستحقاق القادم:</span>
                            <span className="font-bold text-slate-800 font-mono block mt-0.5"> {formatNextDueDate(alert.nextDueDate)}</span>
                          </div>
                        </div>

                        {/* Quick Action Buttons Row */}
                        <div className="flex gap-2 pr-2">
                          {/* Direct WhatsApp Message Dialog button */}
                          <button
                            type="button"
                            onClick={() => setTemplateModalCustomer(c)}
                            className="flex-1 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl transition-all cursor-pointer text-[11px] font-bold flex items-center justify-center gap-1.5 animate-bounce-subtle"
                          >
                            <MessageCircle className="w-4 h-4 text-emerald-600" />
                            <span>مراسلة وتذكير</span>
                          </button>

                          {/* Fast Phone call button */}
                          <a
                            href={`tel:${c.phone}`}
                            className="px-3 py-2 bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 rounded-xl transition-all text-[11px] font-bold flex items-center justify-center gap-1"
                            title="اتصال هاتفي سريع"
                          >
                            <Phone className="w-4 h-4" />
                          </a>

                          {/* Full Customer Profile details button */}
                          <button
                            type="button"
                            onClick={() => viewCustomerDetails(c.id)}
                            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all text-[11px] font-bold cursor-pointer"
                          >
                            الملف الشخصي
                          </button>
                        </div>

                      </div>
                    );
                  });
                })()}
              </div>
            </div>
          )}

          {/* SCREEN 5: SETTINGS */}
          {currentScreen === "settings" && (
            <SettingsScreen
              showToast={showToast}
              onImportSuccess={() => {
                setCurrentScreen("list");
                setSelectedCustomerId(null);
                setActiveFullCustomer(null);
              }}
              printerPaperSize={printerPaperSize}
              setPrinterPaperSize={setPrinterPaperSize}
              printerThickness={printerThickness}
              setPrinterThickness={setPrinterThickness}
              printerThreshold={printerThreshold}
              setPrinterThreshold={setPrinterThreshold}
              activeTemplateId={activeTemplateId}
              setActiveTemplateId={setActiveTemplateId}
              customTemplates={customTemplates}
              setCustomTemplates={setCustomTemplates}
            />
          )}

        </main>

        {/* Navigation bottom menu */}
        <nav className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-2xl h-16 flex border border-[#E8ECF2] z-40 rounded-[20px] shadow-[0_10px_30px_rgba(11,31,58,0.06)] px-2 justify-around items-center" dir="rtl">
          
          {/* Tab 1: Add Customer (إضافة قسط) */}
          <button
            type="button"
            onClick={() => setCurrentScreen("add")}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1 h-full"
          >
            <div className={`flex items-center justify-center transition-all duration-300 ${
              currentScreen === "add" 
                ? "bg-[#0B1F3A] text-[#D4A44B] px-4.5 py-1.5 rounded-xl shadow-md scale-105" 
                : "text-slate-400 hover:text-slate-600 px-3 py-1 hover:bg-slate-50 rounded-xl"
            }`}>
              <PlusCircle className="w-5 h-5" />
            </div>
            <span className={`text-[9px] mt-1 transition-all font-bold ${
              currentScreen === "add" ? "text-[#0B1F3A] font-extrabold" : "text-slate-500"
            }`}>إضافة قسط</span>
            {currentScreen === "add" && <div className="w-3 h-0.5 bg-[#D4A44B] rounded-full mt-0.5" />}
          </button>

          {/* Tab 2: Customers List (كل العملاء) */}
          <button
            type="button"
            onClick={() => {
              setCurrentScreen("list");
              setSelectedCustomerId(null);
            }}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1 h-full"
          >
            <div className={`flex items-center justify-center transition-all duration-300 ${
              currentScreen === "list" 
                ? "bg-[#0B1F3A] text-[#D4A44B] px-4.5 py-1.5 rounded-xl shadow-md scale-105" 
                : "text-slate-400 hover:text-slate-600 px-3 py-1 hover:bg-slate-50 rounded-xl"
            }`}>
              <Users className="w-5 h-5" />
            </div>
            <span className={`text-[9px] mt-1 transition-all font-bold ${
              currentScreen === "list" ? "text-[#0B1F3A] font-extrabold" : "text-slate-500"
            }`}>كل العملاء</span>
            {currentScreen === "list" && <div className="w-3 h-0.5 bg-[#D4A44B] rounded-full mt-0.5" />}
          </button>

          {/* Tab 3: Alerts (التنبيهات) */}
          <button
            type="button"
            onClick={() => {
              setCurrentScreen("alerts");
              setSelectedCustomerId(null);
            }}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1 h-full"
          >
            <div className={`flex items-center justify-center transition-all duration-300 ${
              currentScreen === "alerts" 
                ? "bg-[#0B1F3A] text-[#D4A44B] px-4.5 py-1.5 rounded-xl shadow-md scale-105" 
                : "text-slate-400 hover:text-slate-600 px-3 py-1 hover:bg-slate-50 rounded-xl"
            }`}>
              <Bell className="w-5 h-5" />
            </div>
            <span className={`text-[9px] mt-1 transition-all font-bold ${
              currentScreen === "alerts" ? "text-[#0B1F3A] font-extrabold" : "text-slate-500"
            }`}>التنبيهات</span>
            {alertCount > 0 && (
              <span className="absolute top-1.5 right-1/2 translate-x-4 bg-rose-500 text-white text-[8px] font-extrabold px-1.5 py-0.5 rounded-full min-w-[16px] text-center shadow-sm border border-white">
                {alertCount}
              </span>
            )}
            {currentScreen === "alerts" && <div className="w-3 h-0.5 bg-[#D4A44B] rounded-full mt-0.5" />}
          </button>

          {/* Tab 4: Settings (الإعدادات) */}
          <button
            type="button"
            onClick={() => {
              setCurrentScreen("settings");
              setSelectedCustomerId(null);
            }}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1 h-full"
          >
            <div className={`flex items-center justify-center transition-all duration-300 ${
              currentScreen === "settings" 
                ? "bg-[#0B1F3A] text-[#D4A44B] px-4.5 py-1.5 rounded-xl shadow-md scale-105" 
                : "text-slate-400 hover:text-slate-600 px-3 py-1 hover:bg-slate-50 rounded-xl"
            }`}>
              <Settings className="w-5 h-5" />
            </div>
            <span className={`text-[9px] mt-1 transition-all font-bold ${
              currentScreen === "settings" ? "text-[#0B1F3A] font-extrabold" : "text-slate-500"
            }`}>الإعدادات</span>
            {currentScreen === "settings" && <div className="w-3 h-0.5 bg-[#D4A44B] rounded-full mt-0.5" />}
          </button>

        </nav>

        {/* MODAL 1: Ready-made Message Templates Chooser */}
        {templateModalCustomer && (() => {
          const c = templateModalCustomer;
          
          // Custom beautiful message templates
          const templates = [
            {
              title: "⏰ تذكير بموعد القسط القادم",
              text: `السلام عليكم أخي ${c.name} المحترم، نود تذكيرك بموعد قسط المادة (${c.productName}) المستحق في يوم ${c.dueDay} من الشهر، والبالغ قدره: ${formatNumber(c.monthlyAmount)} د.ع. يرجى التفضل بالسداد لتجنب الغرامات أو تراكم الأقساط. شكراً لالتزامك وتواصلك المستمر معنا.`
            },
            {
              title: " تنبيه تأخير في السداد",
              text: `أخي العزيز ${c.name}، نلاحظ تأخر سداد القسط المستحق للمادة (${c.productName}) والبالغ قدره ${formatNumber(c.monthlyAmount)} د.ع. المتبقي بذمتك حتى الآن هو ${formatNumber(c.remainingAmount)} د.ع. نرجو منك التكرم بسداد المبلغ بأقرب وقت لتفادي أي إشكال قانوني. تفضل بقبول الاحترام والتقدير.`
            },
            {
              title: " شكر وتقدير بعد السداد",
              text: `أخي المحترم ${c.name}، نشكرك جزيل الشكر على سداد الدفعة الحالية بنجاح والتزامك الراقي بمواعيد الأقساط. المبلغ المتبقي بذمتك الصافي الآن هو: ${formatNumber(c.remainingAmount)} د.ع فقط. نتمنى لك دوام الموفقية والنجاح!`
            }
          ];

          return (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
              <div className="bg-white w-full max-w-sm rounded-t-3xl sm:rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-100 max-h-[85vh] overflow-y-auto text-right">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                    <MessageCircle className="w-5 h-5 text-[#D4A44B]" />
                    <span>قوالب رسائل الواتساب الجاهزة</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setTemplateModalCustomer(null)}
                    className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <p className="text-xs text-slate-500 font-bold leading-relaxed">
                  اختر أحد القوالب التلقائية أدناه لإرسال رسالة مباشرة إلى هاتف الزبون (<span className="text-[#D4A44B]">{c.name}</span>) دون الحاجة للكتابة اليدوية:
                </p>

                <div className="space-y-3">
                  {templates.map((tpl, i) => (
                    <div
                      key={i}
                      className="p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-all cursor-pointer group"
                      onClick={() => launchWhatsAppWithMessage(c.phone, tpl.text)}
                    >
                      <h4 className="font-extrabold text-xs text-slate-900 mb-1 flex justify-between items-center">
                        <span>{tpl.title}</span>
                        <span className="text-[9px] bg-slate-100 text-[#D4A44B] px-1.5 py-0.5 rounded font-extrabold group-hover:bg-slate-200">إرسال مباشر</span>
                      </h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed text-justify line-clamp-3">
                        {tpl.text}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => launchWhatsAppWithMessage(c.phone, "")}
                    className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs cursor-pointer transition-all"
                  >
                     فتح محادثة فارغة بدون قالب جاهز
                  </button>
                </div>
              </div>
            </div>
          );
        })()}

        {/* MODAL 2: Fullscreen Image Preview Zoom Overlay */}
        {previewImageSrc && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col justify-center items-center p-4">
            <button
              type="button"
              onClick={() => setPreviewImageSrc(null)}
              className="absolute top-5 right-5 p-2 bg-white/20 hover:bg-white/30 text-white rounded-full transition-all cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={previewImageSrc}
              alt="Fullscreen Zoomed Document"
              className="max-w-full max-h-[80vh] object-contain rounded-2xl shadow-2xl border border-white/10"
            />
            <p className="text-white/70 text-xs font-bold mt-4">اسحب أو انقر في أي مكان آخر للإغلاق</p>
          </div>
        )}

        {/* MODAL 3: Custom Delete Confirmation Modal */}
        {deleteConfirmId && (() => {
          const c = customers.find((cust) => cust.id === deleteConfirmId);
          if (!c) return null;
          return (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-100 text-right">
                <div className="flex items-center gap-2.5 text-rose-600 font-extrabold border-b border-rose-50 pb-3">
                  <AlertCircle className="w-6 h-6 text-rose-500" />
                  <span className="text-sm">تأكيد حذف الزبون نهائياً</span>
                </div>
                
                <p className="text-xs text-slate-600 font-bold leading-relaxed">
                  هل أنت متأكد من حذف ملف الزبون (<span className="text-rose-600 font-extrabold">{c.name}</span>) بالكامل من النظام المحلي؟
                </p>
                
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed bg-rose-50/50 p-2.5 rounded-xl border border-rose-100">
                   تنبيه: سيتم حذف معلومات الزبون، الوصولات، وجميع الوثائق والصور بشكل نهائي ولا يمكن التراجع عن هذا الإجراء مطلقاً!
                </p>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => handleDeleteCustomer(c.id)}
                    className="py-3 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl text-xs cursor-pointer transition-all shadow-lg shadow-rose-600/20"
                  >
                    نعم، احذف نهائياً
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmId(null)}
                    className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs cursor-pointer transition-all"
                  >
                    تراجع وإلغاء
                  </button>
                </div>
              </div>
            </div>
          );
        })()}

        {/* MODAL 4: Optional Documents Warning Confirmation Modal */}
        {showNoDocsConfirm && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-100 text-right">
              <div className="flex items-center gap-2.5 text-amber-600 font-extrabold border-b border-amber-50 pb-3">
                <AlertCircle className="w-6 h-6 text-amber-500" />
                <span className="text-sm">تأكيد التسجيل بدون مستندات</span>
              </div>
              
              <p className="text-xs text-slate-600 font-bold leading-relaxed">
                هل أنت متأكد من تسجيل هذا الزبون بدون رفع المستمسكات الثبوتية؟
              </p>
              
              <p className="text-[11px] text-amber-700 font-medium leading-relaxed bg-amber-50 p-2.5 rounded-xl border border-amber-100">
                 تنبيه: لم يتم رفع أو تصوير كافة الوثائق المطلوبة (مثل بطاقة السكن أو البطاقة الموحدة). يمكنك مواصلة الحفظ وحفظها لاحقاً إذا أردت.
              </p>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => executeSaveCustomer()}
                  className="py-3 bg-amber-500 hover:bg-amber-600 text-white font-extrabold rounded-xl text-xs cursor-pointer transition-all shadow-lg shadow-amber-500/20"
                >
                  نعم، أكمل التسجيل
                </button>
                <button
                  type="button"
                  onClick={() => setShowNoDocsConfirm(false)}
                  className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs cursor-pointer transition-all"
                >
                  إلغاء ورفع الصور
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL 5: Clear Fields Confirmation Modal */}
        {showClearFieldsConfirm && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-100 text-right" dir="rtl">
              <div className="flex items-center gap-2.5 text-rose-600 font-extrabold border-b border-rose-50 pb-3">
                <Trash2 className="w-6 h-6 text-rose-500" />
                <span className="text-sm">تأكيد تفريغ الحقول</span>
              </div>
              
              <p className="text-xs text-slate-600 font-bold leading-relaxed">
                هل أنت متأكد من رغبتك في تفريغ كافة الحقول والبدء بنموذج قسط جديد؟
              </p>
              
              <p className="text-[11px] text-rose-700 font-medium leading-relaxed bg-rose-50 p-2.5 rounded-xl border border-rose-100">
                 تنبيه: هذا الإجراء سيقوم بمسح كافة البيانات المدخلة حالياً في هذا النموذج (بيانات العميل، المنتج، الحسابات، الكفيل، والصور) ولا يمكن التراجع عنه.
              </p>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    clearFormDrafts();
                    // Clear states explicitly to guarantee full reset
                    setCustName("");
                    setCustPhone("");
                    setCustNationalId("");
                    setCustGovernorate("");
                    setCustNearestLandmark("");
                    setCustProfession("");
                    setProdName("");
                    setProdSerial("");
                    setProdDetails("");
                    setCustCashPrice("");
                    setCustTotalAmount("");
                    setCustUpfront("");
                    setCustMonthly("");
                    setCustInstallmentCount("12");
                    setImages({
                      personal: "",
                      resFront: "",
                      resBack: "",
                      idFront: "",
                      idBack: ""
                    });
                    setHasGuarantor(false);
                    setGuarantorName("");
                    setGuarantorPhone("");
                    setGuarantorAddress("");
                    setGuarantorGovernorate("");
                    setGuarantorNearestLandmark("");
                    setGuarantorNationalId("");
                    setGuarantorProfession("");
                    setGuarantorRelationship("");
                    setGuarantorImages({
                      personal: "",
                      idFront: "",
                      idBack: "",
                      resFront: "",
                      resBack: ""
                    });
                    setFormStep(1);
                    setShowClearFieldsConfirm(false);
                    showToast(" تم تفريغ كافة الحقول والبدء بنموذج جديد", "info");
                  }}
                  className="py-3 bg-rose-500 hover:bg-rose-600 text-white font-extrabold rounded-xl text-xs cursor-pointer transition-all shadow-lg shadow-rose-500/20"
                >
                  نعم، فرّغ الحقول
                </button>
                <button
                  type="button"
                  onClick={() => setShowClearFieldsConfirm(false)}
                  className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs cursor-pointer transition-all"
                >
                  إلغاء وتراجع
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Hidden inputs for programmatic Bottom Sheet trigger */}
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture={uploadTarget?.docKey === "personal" ? "user" : "environment"}
          onChange={(e) => {
            if (!uploadTarget) return;
            if (uploadTarget.type === "customer") {
              handleFileChange(e, uploadTarget.docKey);
            } else {
              handleGuarantorFileChange(e, uploadTarget.docKey);
            }
            setUploadTarget(null);
          }}
          className="hidden"
        />
        <input
          ref={galleryInputRef}
          type="file"
          accept="image/*"
          onChange={(e) => {
            if (!uploadTarget) return;
            if (uploadTarget.type === "customer") {
              handleFileChange(e, uploadTarget.docKey);
            } else {
              handleGuarantorFileChange(e, uploadTarget.docKey);
            }
            setUploadTarget(null);
          }}
          className="hidden"
        />

        {/* COMPACT FLOATING UPLOAD BOTTOM SHEET */}
        <AnimatePresence>
          {uploadTarget && (
            <div className="fixed inset-0 z-50 flex items-end justify-center">
              {/* Semi-transparent Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setUploadTarget(null)}
                className="absolute inset-0 bg-slate-900/40 backdrop-blur-[2px]"
              />

              {/* Slide-up Bottom Sheet */}
              <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 280 }}
                className="relative bg-white w-full max-w-md rounded-t-[32px] p-6 shadow-2xl border-t border-slate-100/80 z-10 text-right space-y-5 pb-8"
                dir="rtl"
              >
                {/* Visual drag handle */}
                <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto -mt-2 mb-4" />

                <div className="text-right">
                  <h3 className="text-base font-black text-slate-900">طريقة رفع المستمسك</h3>
                  <p className="text-xs font-semibold text-slate-500 mt-1">
                    اختر طريقة لإضافة: <span className="text-[#D4A44B] font-black">{uploadTarget.label}</span>
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Camera Option */}
                  <button
                    type="button"
                    onClick={() => {
                      if (cameraInputRef.current) {
                        cameraInputRef.current.click();
                      }
                    }}
                    className="flex flex-col items-center justify-center p-5 rounded-2xl bg-slate-50 hover:bg-[#D4A44B]/5 border border-slate-100 hover:border-[#D4A44B]/30 transition-all group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-full bg-slate-100 text-[#0B1F3A] flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                      <Camera className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-black text-slate-800 mt-3">التقاط صورة كاميرا</span>
                  </button>

                  {/* Gallery Option */}
                  <button
                    type="button"
                    onClick={() => {
                      if (galleryInputRef.current) {
                        galleryInputRef.current.click();
                      }
                    }}
                    className="flex flex-col items-center justify-center p-5 rounded-2xl bg-slate-50 hover:bg-[#D4A44B]/5 border border-slate-100 hover:border-[#D4A44B]/30 transition-all group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-full bg-slate-100 text-[#D4A44B] flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                      <ImageIcon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-black text-slate-800 mt-3">من استوديو الصور</span>
                  </button>
                </div>

                {/* Cancel Button */}
                <button
                  type="button"
                  onClick={() => setUploadTarget(null)}
                  className="w-full py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-2xl text-xs transition-all cursor-pointer"
                >
                  إلغاء التراجع
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    )}

    {/* MODAL 6: Demo Expired Modal */}
    {showDemoExpiredModal && (
      <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-center justify-center p-4" dir="rtl">
        <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-5 shadow-2xl border border-slate-100 text-center animate-in fade-in zoom-in-95 duration-200">
          <div className="mx-auto w-14 h-14 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
            <ShieldAlert className="w-8 h-8" />
          </div>
          
          <div className="space-y-1.5">
            <h3 className="text-base font-black text-slate-900">انتهت الفترة التجريبية!</h3>
            <p className="text-xs text-slate-500 font-semibold leading-relaxed">
              لقد انتهت فترة الدخول التجريبي المحددة بـ (ساعتان).
            </p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-right space-y-2">
            <p className="text-[11px] text-slate-600 font-bold leading-relaxed">
               تم حذف كافة بيانات الجلسة المؤقتة المسجلة لحماية خصوصية بياناتك وتصفير مخزن المتصفح المؤقت.
            </p>
            <p className="text-[11px] text-[#D4A44B] font-extrabold leading-relaxed">
               لشراء النسخة الأصلية الكاملة والاستفادة من حفظ البيانات الدائم بدون قيود زمنية، يرجى التواصل معنا لتفعيل حسابك.
            </p>
          </div>

          <div className="space-y-2">
            <a
              href="tel:07803453936"
              className="w-full py-3 bg-[#0B1F3A] hover:bg-[#122b4e] text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
            >
              <Phone className="w-4 h-4 text-[#D4A44B]" />
              <span>اتصل الآن: 07803453936</span>
            </a>
            <button
              type="button"
              onClick={() => setShowDemoExpiredModal(false)}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-[11px] cursor-pointer transition-all"
            >
              إغلاق النافذة
            </button>
          </div>
        </div>
      </div>
    )}

    {/* MODAL 7: Demo Limit Reached (Purchase) Modal */}
    {showDemoLimitReachedModal && (
      <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-center justify-center p-4" dir="rtl">
        <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-5 shadow-2xl border border-slate-100 text-center animate-in fade-in zoom-in-95 duration-200">
          <div className="mx-auto w-14 h-14 rounded-full bg-amber-50 flex items-center justify-center text-[#D4A44B]">
            <CreditCard className="w-7 h-7" />
          </div>
          
          <div className="space-y-1.5">
            <h3 className="text-base font-black text-slate-900">شراء النسخة الأصلية</h3>
            <p className="text-xs text-slate-500 font-semibold leading-relaxed">
              لقد تم استنفاد الفترة التجريبية الخاصة بك مسبقاً.
            </p>
          </div>

          <div className="bg-amber-50/50 p-3.5 rounded-2xl border border-amber-100/50 text-right space-y-2">
            <p className="text-[11px] text-slate-600 font-bold leading-relaxed">
               نظام الحماية يمنع تسجيل الدخول التجريبي لمرة أخرى على نفس المتصفح بعد انتهاء فترة الساعتين لتجنب تكرار الجلسات المؤقتة.
            </p>
            <p className="text-[11px] text-[#D4A44B] font-extrabold leading-relaxed">
               تفضل بالحصول على نسختك الكاملة المدعومة بنظام المزامنة الدائم وقاعدة البيانات الآمنة لإدارة أقساطك باحترافية كاملة.
            </p>
          </div>

          <div className="space-y-2">
            <a
              href="tel:07803453936"
              className="w-full py-3 bg-[#D4A44B] hover:bg-[#c3933c] text-slate-900 font-black rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
            >
              <Phone className="w-4 h-4" />
              <span>اتصل الآن: 07803453936</span>
            </a>
            <button
              type="button"
              onClick={() => {
                // Wipe all saved data and states
                wipeAllData();
                // Remove demo_used restriction to allow a fresh start
                localStorage.removeItem("demo_used");
                setDemoUsed(false);
                setShowDemoLimitReachedModal(false);
                showToast(" تم إعادة تعيين الفترة التجريبية وتصفير كافة البيانات بنجاح! يمكنك تجربة الدخول التجريبي مرة أخرى الآن.", "success");
              }}
              className="w-full py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-extrabold rounded-xl text-[10px] cursor-pointer transition-all border border-emerald-200/50"
            >
               إعادة تعيين الفترة التجريبية وتصفير البيانات (للفحص)
            </button>
            <button
              type="button"
              onClick={() => setShowDemoLimitReachedModal(false)}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-[11px] cursor-pointer transition-all"
            >
              إغلاق النافذة
            </button>
          </div>
        </div>
      </div>
    )}

    {/* MODAL: Thermal Receipt 80mm Printer */}
    {thermalReceiptData && (() => {
      // Draw image from canvas
      const receiptImgSrc = drawThermalReceipt(thermalReceiptData);
      
      return (
        <div className="fixed inset-0 bg-slate-900/85 backdrop-blur-md z-[110] flex items-center justify-center p-4 overflow-y-auto" dir="rtl">
          <div className="bg-white w-full max-w-md md:max-w-lg rounded-[24px] p-6 space-y-4 shadow-2xl border border-slate-200 text-center animate-in fade-in zoom-in-95 duration-200 my-auto">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <span className="text-sm font-black text-slate-800 flex items-center gap-1.5">
                <Printer className="w-5 h-5 text-[#D4A44B]" />
                <span>طابعة الفواتير الحرارية {printerPaperSize === "58mm" ? "58mm" : "80mm"}</span>
              </span>
              <button
                type="button"
                onClick={() => setThermalReceiptData(null)}
                className="w-8 h-8 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1 text-right">
              <p className="text-[11px] font-bold text-slate-500">تم إنتاج الفاتورة كـ (صورة عالية الدقة) لتطابق تام مع طابعات البلوتوث والحراري بدون مشاكل خطوط:</p>
            </div>

            {/* Paper Size Selector */}
            <div className="bg-slate-50 p-2 rounded-2xl border border-slate-200/60 flex items-center justify-between text-right gap-2">
              <span className="text-[11px] font-black text-slate-700 pr-1 flex items-center gap-1">
                <span> قياس الورق:</span>
              </span>
              <div className="flex gap-1 bg-slate-200/50 p-0.5 rounded-xl border border-slate-300/30">
                <button
                  type="button"
                  onClick={() => {
                    setPrinterPaperSize("58mm");
                    localStorage.setItem("printer_paper_size", "58mm");
                    showToast(" تم ضبط قياس الفاتورة على 58 ملم (للطابعات المحمولة الصغيرة)", "info");
                  }}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer ${
                    printerPaperSize === "58mm"
                      ? "bg-blue-600 text-white shadow-sm"
                      : "bg-transparent text-slate-600 hover:bg-white/50"
                  }`}
                >
                   58 ملم (صغيرة)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPrinterPaperSize("80mm");
                    localStorage.setItem("printer_paper_size", "80mm");
                    showToast(" تم ضبط قياس الفاتورة على 80 ملم (للطابعات المكتبية الكبيرة)", "info");
                  }}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer ${
                    printerPaperSize === "80mm"
                      ? "bg-blue-600 text-white shadow-sm"
                      : "bg-transparent text-slate-600 hover:bg-white/50"
                  }`}
                >
                   80 ملم (كبيرة)
                </button>
              </div>
            </div>

            {/* Advanced Calibration Controls (Threshold & Thickness) */}
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60 space-y-3 text-right">
              <span className="text-[11px] font-black text-slate-800 flex items-center gap-1">
                <span> معايرة عمق وجودة طباعة الحبر الحراري:</span>
              </span>
              
              {/* Thickness Slider */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[10px] font-extrabold text-slate-600">
                  <span> سمك ووضوح الخط: {printerThickness}x</span>
                  <span className="text-blue-600 font-black">
                    {printerThickness === 1 ? "نحيف جداً" : printerThickness === 2 ? "عادي (افتراضي)" : printerThickness === 3 ? "واضح غامق" : printerThickness === 4 ? "سميك داكن" : "عريض جداً مميز"}
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={printerThickness}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setPrinterThickness(val);
                    localStorage.setItem("printer_thickness", String(val));
                  }}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
              </div>

              {/* Threshold Slider */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[10px] font-extrabold text-slate-600">
                  <span> عتبة سواد بيكسل الصورة: {printerThreshold}</span>
                  <span className="text-emerald-600 font-black">
                    {printerThreshold < 150 ? "خفيف رمادي" : printerThreshold < 200 ? "متوازن" : printerThreshold < 235 ? "داكن مشبع" : "شديد السواد"}
                  </span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="255"
                  step="5"
                  value={printerThreshold}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setPrinterThreshold(val);
                    localStorage.setItem("printer_threshold", String(val));
                  }}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                />
              </div>
            </div>

            {/* Scrollable Receipt Preview Container */}
            <div className="bg-slate-100 p-2.5 rounded-2xl border border-slate-200 max-h-[500px] overflow-y-auto shadow-inner flex justify-center">
              {receiptImgSrc ? (
                <img
                  src={receiptImgSrc}
                  alt="Thermal Receipt Preview"
                  className="w-full max-w-full md:max-w-[420px] h-auto object-contain bg-white shadow-sm rounded-lg"
                />
              ) : (
                <p className="text-xs text-slate-400 py-4">جاري تحميل المعاينة...</p>
              )}
            </div>

            {/* Print and Actions */}
            <div className="space-y-2.5 pt-1">
              
              {/* Bluetooth Printer Section */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/60 space-y-2.5 text-right">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-black text-slate-700 flex items-center gap-1">
                    <Bluetooth className={`w-3.5 h-3.5 ${bluetoothDevice ? "text-blue-600 animate-pulse" : "text-slate-400"}`} />
                    <span>طابعة البلوتوث اللاسلكية ({printerPaperSize === "58mm" ? "58mm" : "80mm"})</span>
                  </span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-extrabold ${bluetoothDevice ? "bg-emerald-100 text-emerald-700 border border-emerald-200" : isBluetoothConnecting ? "bg-blue-100 text-blue-700 border border-blue-200 animate-pulse" : "bg-slate-100 text-slate-500 border border-slate-200"}`}>
                    {bluetoothDevice ? "متصلة وجاهزة" : isBluetoothConnecting ? "جاري البحث" : "غير مقترنة"}
                  </span>
                </div>

                {!bluetoothDevice && !isBluetoothConnecting && (
                  <div className="flex items-center justify-between bg-slate-100/70 p-2 rounded-xl text-right mb-2 text-[10px]">
                    <span className="font-bold text-slate-600">تصفية البحث (عرض الطابعات فقط لتجنب الفوضى):</span>
                    <button
                      type="button"
                      onClick={() => {
                        const val = !filterBluetoothPrintersOnly;
                        setFilterBluetoothPrintersOnly(val);
                        showToast(val ? "تم تفعيل تصفية الطابعات لتسهيل العثور على طابعتك" : "تم إلغاء تصفية البحث لعرض كافة الأجهزة المتوفرة", "info");
                      }}
                      className={`px-2 py-1 rounded-lg font-black transition-all ${
                        filterBluetoothPrintersOnly
                          ? "bg-blue-600 text-white shadow-sm"
                          : "bg-slate-200 text-slate-700"
                      }`}
                    >
                      {filterBluetoothPrintersOnly ? "مفعّل" : "عرض الكل"}
                    </button>
                  </div>
                )}

                {isBluetoothConnecting ? (
                  <div className="bg-slate-50/50 p-3 rounded-xl border border-blue-100 text-right space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                        <Bluetooth className="w-4 h-4 text-blue-600 animate-spin" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-[11px] font-black text-blue-900">جاري البحث عن طابعات بلوتوث قريبة...</h4>
                        <p className="text-[9px] text-slate-400 font-bold mt-0.5">الرجاء اختيار طابعتك الحرارية من القائمة المنبثقة</p>
                      </div>
                    </div>

                    {/* Welcoming message / loading visual skeleton */}
                    <div className="space-y-1.5 pt-1 border-t border-slate-200/40">
                      <div className="h-2 bg-slate-200 rounded-full w-3/4 animate-pulse" />
                      <div className="h-1.5 bg-slate-200 rounded-full w-full animate-pulse" />
                    </div>

                    {/* Elegant Discovered Device Skeletons */}
                    <div className="space-y-1.5 pt-2">
                      {[1, 2].map((i) => (
                        <div key={i} className="flex items-center justify-between bg-white/60 p-2 rounded-xl border border-slate-100/80 animate-pulse">
                          <div className="flex items-center gap-2">
                            <div className="w-5 h-5 bg-slate-200 rounded-lg shrink-0" />
                            <div className="space-y-1">
                              <div className="h-1.5 bg-slate-300 rounded w-16" />
                              <div className="h-1 bg-slate-200 rounded w-12" />
                            </div>
                          </div>
                          <div className="w-8 h-3 bg-slate-200 rounded" />
                        </div>
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setIsBluetoothConnecting(false);
                        showToast("تم إلغاء البحث عن طابعة البلوتوث.", "info");
                      }}
                      className="w-full py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-lg text-[9px] transition-all cursor-pointer text-center"
                    >
                      إلغاء البحث والاقتران
                    </button>
                  </div>
                ) : bluetoothDevice ? (
                  <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-sm space-y-2.5 text-right">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center border border-emerald-100 shrink-0">
                        <Bluetooth className="w-4 h-4 text-emerald-600 animate-pulse" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-black text-slate-800 truncate">{bluetoothDevice.name || "طابعة حرارية غير مسمّاة"}</p>
                        <div className="flex items-center gap-1 mt-0.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                          <span className="text-[9px] text-emerald-600 font-bold">متصلة وجاهزة للطباعة فوراً</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={printBluetoothTestPage}
                        className="py-1.5 px-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold border border-slate-200 rounded-xl text-[9px] flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95"
                      >
                        <Printer className="w-3 h-3 text-slate-500" />
                        <span>تجربة الطباعة</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setBluetoothDevice(null);
                          showToast("تم فصل طابعة البلوتوث.", "info");
                        }}
                        className="py-1.5 px-2 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold border border-rose-100 rounded-xl text-[9px] flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95"
                      >
                        <X className="w-3 h-3 text-rose-500" />
                        <span>قطع الاتصال</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={connectBluetoothPrinter}
                    disabled={isBluetoothConnecting}
                    className="w-full py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-[0.97]"
                  >
                    <Bluetooth className="w-3.5 h-3.5 text-blue-600" />
                    <span>ربط واقتران طابعة بلوتوث</span>
                  </button>
                )}

                {bluetoothPermissionError && (
                  <div className="bg-amber-50 text-amber-900 text-[10px] p-2.5 rounded-xl border border-amber-200 font-medium leading-relaxed mt-2 text-right">
                    <p className="font-extrabold text-amber-800 mb-1"> قيود حماية المتصفح (Iframe Sandbox):</p>
                    <p>يمنع المتصفح الوصول إلى أجهزة البلوتوث من داخل الإطارات البرمجية المدمجة (Iframe) لحماية الأمان.</p>
                    <p className="font-extrabold text-blue-800 mt-1.5"> الحل السريع والسهل:</p>
                    <p>يرجى فتح التطبيق في <strong>علامة تبويب جديدة (نافذة خارجية كاملة)</strong> عبر النقر على رابط المعاينة أعلى يسار الصفحة أو زر المشاركة، وبذلك سيظهر لك مربع اختيار طابعة البلوتوث وتعمل الطباعة فوراً وبدون مشاكل!</p>
                  </div>
                )}
              </div>

              {/* Primary Action Button: Print via Bluetooth */}
              <button
                type="button"
                onClick={() => {
                  if (bluetoothDevice) {
                    if (receiptImgSrc) printViaBluetoothDirect(receiptImgSrc);
                  } else {
                    connectBluetoothPrinter();
                  }
                }}
                disabled={isBluetoothConnecting}
                className="w-full py-3 bg-[#0B1F3A] hover:bg-[#15345d] text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all active:scale-[0.98] disabled:opacity-60"
              >
                <Bluetooth className="w-4 h-4 text-[#D4A44B] animate-pulse" />
                <span>{bluetoothDevice ? "🖨️ طباعة الفاتورة عبر البلوتوث" : "🔗 ربط الطابعة وطباعة الفاتورة"}</span>
              </button>

              <button
                type="button"
                onClick={() => setThermalReceiptData(null)}
                className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-xl text-xs font-semibold cursor-pointer transition-all border border-slate-200"
              >
                إغلاق النافذة
              </button>
            </div>

          </div>
        </div>
      );
    })()}

    {/* MODAL: Account Statement Export */}

    </div>
  );
}
