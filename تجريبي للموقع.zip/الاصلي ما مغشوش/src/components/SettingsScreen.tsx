import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  RefreshCw, 
  AlertCircle, 
  Upload, 
  ShieldCheck, 
  Share2, 
  History, 
  Printer, 
  Sliders, 
  Plus, 
  Save, 
  Trash2, 
  Check, 
  Layout, 
  Type, 
  Ruler, 
  ChevronDown, 
  ChevronUp 
} from "lucide-react";
import { exportBackupZip, importBackupZip, getBackupLogs, BackupLog } from "../firebase";
import { PrintTemplate, DEFAULT_TEMPLATES } from "../types";

interface SettingsScreenProps {
  showToast: (msg: string, type: "success" | "danger" | "info") => void;
  onImportSuccess?: () => void;
  printerPaperSize: string;
  setPrinterPaperSize: (val: string) => void;
  printerThickness: number;
  setPrinterThickness: (val: number) => void;
  printerThreshold: number;
  setPrinterThreshold: (val: number) => void;
  activeTemplateId: string;
  setActiveTemplateId: (val: string) => void;
  customTemplates: PrintTemplate[];
  setCustomTemplates: (val: PrintTemplate[]) => void;
}

export default function SettingsScreen({
  showToast,
  onImportSuccess,
  printerPaperSize,
  setPrinterPaperSize,
  printerThickness,
  setPrinterThickness,
  printerThreshold,
  setPrinterThreshold,
  activeTemplateId,
  setActiveTemplateId,
  customTemplates,
  setCustomTemplates,
}: SettingsScreenProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  
  const [progressPercent, setProgressPercent] = useState<number | null>(null);
  const [progressMessage, setProgressMessage] = useState("");
  const [backupLogs, setBackupLogs] = useState<BackupLog[]>([]);

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [importResultReport, setImportResultReport] = useState<string | null>(null);

  // Accordion/Collapse toggles
  const [isPrinterExpanded, setIsPrinterExpanded] = useState(true);
  const [isBackupExpanded, setIsBackupExpanded] = useState(false);

  // Editing custom templates states
  const [isCreatingTemplate, setIsCreatingTemplate] = useState(false);
  const [editingTemplateId, setEditingTemplateId] = useState<string | null>(null);
  const [templateFormName, setTemplateFormName] = useState("");
  
  // Sliders values for the custom template being created/edited
  const [fontSizes, setFontSizes] = useState({
    shopName: 38,
    shopPhone: 23,
    title: 32,
    customerName: 34,
    customerPhone: 28,
    productName: 24,
    financialLabel: 18,
    financialValue: 25,
    dueBannerLabel: 19,
    dueBannerValue: 24,
    footer: 18
  });

  const [paddings, setPaddings] = useState({
    shopNameBottom: 52,
    shopPhoneBottom: 42,
    titleBottom: 50,
    customerCardBottom: 42,
    productBottom: 58,
    financialRowBottom: 42,
    dueBannerBottom: 60
  });

  // Fetch operational logs
  const fetchLogs = async () => {
    try {
      const logs = await getBackupLogs();
      setBackupLogs(logs);
    } catch (e) {
      console.error("Error fetching backup logs:", e);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleExport = async () => {
    if (isExporting || isImporting) return;
    setIsExporting(true);
    setProgressPercent(0);
    setProgressMessage("جاري البدء في تجهيز الأرشيف...");
    try {
      const zipBlob = await exportBackupZip((pct, msg) => {
        setProgressPercent(pct);
        setProgressMessage(msg);
      });
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `AlAqsat_Full_Backup_${dateStr}.zip`;
      const file = new File([zipBlob], filename, { type: "application/zip" });

      const downloadFallback = () => {
        const url = URL.createObjectURL(zipBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast("✨ تم تصدير النسخة الاحتياطية (ZIP) بنجاح وحفظها في جهازك!", "success");
      };

      // Check if browser supports sharing files
      if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({
            files: [file],
            title: "النسخة الاحتياطية لتطبيق الأقساط",
            text: "ملف نسخة احتياطية كامل شامل للصور والنصوص"
          });
          showToast("✨ تم مشاركة ملف النسخ الاحتياطي بنجاح!", "success");
        } catch (shareErr: any) {
          if (shareErr.name !== "AbortError") {
            console.info("Sharing policy restriction in this browser context. Falling back to direct download.", shareErr);
            downloadFallback();
          } else {
            showToast("ℹ️ تم إلغاء عملية المشاركة.", "info");
          }
        }
      } else {
        downloadFallback();
      }
      await fetchLogs();
    } catch (error) {
      console.error("Export error:", error);
      showToast("❌ عذراً، فشل تصدير النسخة الاحتياطية", "danger");
    } finally {
      setIsExporting(false);
      setProgressPercent(null);
      setProgressMessage("");
    }
  };

  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPendingFile(file);
    setShowConfirmModal(true);
    e.target.value = "";
  };

  const executeImport = async () => {
    if (!pendingFile) return;
    const file = pendingFile;
    setShowConfirmModal(false);
    setPendingFile(null);

    setIsImporting(true);
    setProgressPercent(0);
    setProgressMessage("جاري البدء في عملية استيراد البيانات...");

    try {
      const resultReport = await importBackupZip(file, (pct, msg) => {
        setProgressPercent(pct);
        setProgressMessage(msg);
      });
      setImportResultReport(resultReport);
      showToast("✨ تم استيراد واسترجاع البيانات والصور بنجاح 100%!", "success");
      await fetchLogs();
      if (onImportSuccess) {
        onImportSuccess();
      }
    } catch (error) {
      console.error("خطأ في عملية استيراد البيانات:", error);
      const msg = error instanceof Error ? error.message : "تأكت من أنه ملف ZIP نسخة احتياطية صالح ومصدر من النظام.";
      showToast(`❌ فشل الاستيراد: ${msg}`, "danger");
      await fetchLogs();
    } finally {
      setIsImporting(false);
      setProgressPercent(null);
      setProgressMessage("");
    }
  };

  // Helper to open the form for editing/creating templates
  const startNewCustomTemplate = () => {
    setIsCreatingTemplate(true);
    setEditingTemplateId(null);
    setTemplateFormName(`قالب مخصص ${customTemplates.length + 1}`);
    // Load standard template values as base defaults
    setFontSizes({ ...DEFAULT_TEMPLATES[0].fontSizes });
    setPaddings({ ...DEFAULT_TEMPLATES[0].paddings });
  };

  const startEditCustomTemplate = (tpl: PrintTemplate) => {
    setIsCreatingTemplate(true);
    setEditingTemplateId(tpl.id);
    setTemplateFormName(tpl.name);
    setFontSizes({ ...tpl.fontSizes });
    setPaddings({ ...tpl.paddings });
  };

  const saveCustomTemplate = () => {
    if (!templateFormName.trim()) {
      showToast("⚠️ الرجاء إدخال اسم للقالب لتتمكن من حفظه", "danger");
      return;
    }

    const newTemplate: PrintTemplate = {
      id: editingTemplateId || `custom_${Date.now()}`,
      name: templateFormName.trim(),
      fontSizes: { ...fontSizes },
      paddings: { ...paddings }
    };

    let updatedTemplates: PrintTemplate[];
    if (editingTemplateId) {
      updatedTemplates = customTemplates.map(t => t.id === editingTemplateId ? newTemplate : t);
      showToast(`✨ تم تعديل قالب الطباعة "${templateFormName}" بنجاح!`, "success");
    } else {
      updatedTemplates = [...customTemplates, newTemplate];
      showToast(`✨ تم حفظ قالب الطباعة الجديد "${templateFormName}" بنجاح!`, "success");
    }

    setCustomTemplates(updatedTemplates);
    localStorage.setItem("custom_print_templates", JSON.stringify(updatedTemplates));
    
    // Automatically select this new/edited template as active
    setActiveTemplateId(newTemplate.id);
    localStorage.setItem("active_print_template_id", newTemplate.id);

    // Reset editing states
    setIsCreatingTemplate(false);
    setEditingTemplateId(null);
  };

  const deleteCustomTemplate = (id: string, name: string) => {
    const updated = customTemplates.filter(t => t.id !== id);
    setCustomTemplates(updated);
    localStorage.setItem("custom_print_templates", JSON.stringify(updated));
    showToast(`🗑️ تم حذف قالب الطباعة "${name}" بنجاح`, "info");

    // If the deleted template was the active one, fallback to standard
    if (activeTemplateId === id) {
      setActiveTemplateId("standard");
      localStorage.setItem("active_print_template_id", "standard");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="h-full flex flex-col overflow-hidden text-right"
      dir="rtl"
    >
      <div className="flex-shrink-0 space-y-4 pb-2">
        {/* Title Header */}
        <div className="bg-gradient-to-l from-[#0B1F3A] to-slate-900 rounded-[28px] p-5 text-white shadow-lg space-y-2 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -translate-x-8 -translate-y-8" />
          <div className="absolute bottom-0 right-0 w-24 h-24 bg-[#D4A44B]/10 rounded-full blur-xl translate-x-4 translate-y-4" />
          
          <h2 className="text-xl font-extrabold flex items-center gap-2.5">
            <span>⚙️ إعدادات النظام المتقدمة</span>
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            من هنا يمكنك ضبط ومعايرة الطباعة الحرارية وتخصيص الفواتير، إضافة لإدارة النسخ الاحتياطي للنظام.
          </p>
        </div>
      </div>
 
      {/* Scrollable Container */}
      <div className="flex-1 overflow-y-auto pb-24 px-1 bg-white rounded-3xl p-6 border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.04)] space-y-4 -webkit-overflow-scrolling: touch;">
        
        {/* SECTION 1: Printer Calibration & Custom Print Templates */}
        <div className="bg-slate-50/50 rounded-2xl border border-slate-200/60 overflow-hidden shadow-sm">
          <button
            type="button"
            onClick={() => setIsPrinterExpanded(!isPrinterExpanded)}
            className="w-full p-4 flex items-center justify-between font-extrabold text-slate-800 bg-slate-100/50 hover:bg-slate-100 transition-colors border-b border-slate-200/50 cursor-pointer text-right"
          >
            <div className="flex items-center gap-2.5">
              <Printer className="w-5 h-5 text-[#D4A44B]" />
              <span className="text-sm">🖨️ إعدادات طابعة الفواتير والخطوط المخصصة</span>
            </div>
            {isPrinterExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
          </button>

          {isPrinterExpanded && (
            <div className="p-4 space-y-5">
              <p className="text-[11px] text-slate-500 leading-relaxed font-bold">
                تحكم في عتاد طابعتك ونوع الورق، أو اختر قوالب مخصصة لتكبير الخطوط وتوفير الورق الحراري وموازنة وضوح الفاتورة والوصل.
              </p>

              {/* Hardware & Calibration Stats */}
              <div className="grid grid-cols-2 gap-3.5 bg-white p-3 rounded-xl border border-slate-100">
                <div>
                  <span className="text-slate-400 block text-[9px] font-bold">حجم ورق الطابعة:</span>
                  <span className="font-extrabold text-[#0B1F3A] text-xs">
                    {printerPaperSize === "58mm" ? "58 ملم (محمولة)" : "80 ملم (مكتبية)"}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[9px] font-bold">سمك الخط النشط:</span>
                  <span className="font-extrabold text-[#0B1F3A] text-xs">
                    {printerThickness}x (واضح)
                  </span>
                </div>
              </div>

              {/* Template Selection Grid */}
              <div className="space-y-3">
                <label className="text-xs font-black text-slate-700 block"> اختر قالب الفاتورة النشط:</label>
                
                {/* 1. Standard Built-in Templates */}
                <div className="grid grid-cols-1 gap-2.5">
                  {DEFAULT_TEMPLATES.map((tpl) => (
                    <div
                      key={tpl.id}
                      onClick={() => {
                        setActiveTemplateId(tpl.id);
                        localStorage.setItem("active_print_template_id", tpl.id);
                        showToast(`✨ تم تنشيط قالب الطباعة "${tpl.name}"`, "success");
                      }}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-right relative flex justify-between items-center ${
                        activeTemplateId === tpl.id
                          ? "bg-[#D4A44B]/10 border-[#D4A44B] shadow-sm"
                          : "bg-white border-slate-200/80 hover:bg-slate-50"
                      }`}
                    >
                      <div className="space-y-1">
                        <h4 className="font-extrabold text-xs text-slate-900 flex items-center gap-2">
                          {activeTemplateId === tpl.id && <Check className="w-3.5 h-3.5 text-[#D4A44B] stroke-[3]" />}
                          <span>{tpl.name}</span>
                        </h4>
                        <p className="text-[10px] text-slate-500 font-semibold leading-relaxed">
                          حجم خط العميل: <span className="font-mono">{tpl.fontSizes.customerName}px</span> | المتبقي: <span className="font-mono">{tpl.fontSizes.dueBannerValue}px</span>
                        </p>
                      </div>
                      <span className="text-[9px] bg-slate-100 text-slate-500 font-black px-2 py-0.5 rounded-md border border-slate-200">افتراضي مدمج</span>
                    </div>
                  ))}

                  {/* 2. Custom Templates List */}
                  {customTemplates.map((tpl) => (
                    <div
                      key={tpl.id}
                      className={`p-3.5 rounded-2xl border transition-all text-right relative flex justify-between items-center ${
                        activeTemplateId === tpl.id
                          ? "bg-[#D4A44B]/10 border-[#D4A44B] shadow-sm"
                          : "bg-white border-slate-200/80"
                      }`}
                    >
                      {/* Left side actions and Badge */}
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => startEditCustomTemplate(tpl)}
                          className="p-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors cursor-pointer border border-blue-100"
                          title="تعديل قيم القالب والمسافات"
                        >
                          <Sliders className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteCustomTemplate(tpl.id, tpl.name)}
                          className="p-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors cursor-pointer border border-rose-100"
                          title="حذف القالب نهائياً"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Clickable Area to Select Template */}
                      <div 
                        onClick={() => {
                          setActiveTemplateId(tpl.id);
                          localStorage.setItem("active_print_template_id", tpl.id);
                          showToast(`✨ تم تنشيط قالبك المخصص "${tpl.name}"`, "success");
                        }}
                        className="flex-1 cursor-pointer pr-2"
                      >
                        <h4 className="font-extrabold text-xs text-slate-900 flex items-center gap-2 justify-end">
                          {activeTemplateId === tpl.id && <Check className="w-3.5 h-3.5 text-[#D4A44B] stroke-[3]" />}
                          <span>{tpl.name}</span>
                        </h4>
                        <p className="text-[10px] text-slate-500 font-semibold leading-relaxed text-right">
                          تعديل يدوي مخصص من قبلك
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Create Custom Template Trigger Button */}
                {!isCreatingTemplate && (
                  <button
                    type="button"
                    onClick={startNewCustomTemplate}
                    className="w-full py-2.5 mt-2 bg-gradient-to-r from-[#0B1F3A] to-slate-800 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-[0.98] shadow-sm"
                  >
                    <Plus className="w-4 h-4 text-[#D4A44B]" />
                    <span>إنشاء وتصميم قالب طباعة مخصص جديد</span>
                  </button>
                )}
              </div>

              {/* Template Form Creator / Editor */}
              {isCreatingTemplate && (
                <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-4 shadow-inner">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-2.5">
                    <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                      <Sliders className="w-4.5 h-4.5 text-[#D4A44B]" />
                      <span>{editingTemplateId ? `تعديل القالب: ${templateFormName}` : "تعديل وتصميم قالب طباعة مخصص"}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsCreatingTemplate(false)}
                      className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-500 px-2 py-1 rounded-md transition-all font-bold cursor-pointer"
                    >
                      إلغاء التعديل
                    </button>
                  </div>

                  {/* Name field input */}
                  <div className="space-y-1 text-right">
                    <label className="text-[11px] font-bold text-slate-600 block">اسم قالب الطباعة:</label>
                    <input
                      type="text"
                      placeholder="مثال: قالب طابعتي المحمولة 58مم"
                      value={templateFormName}
                      onChange={(e) => setTemplateFormName(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0B1F3A]/20 font-bold"
                    />
                  </div>

                  {/* 1. Category: Font Sizes */}
                  <div className="space-y-3 pt-2 border-t border-slate-100">
                    <h5 className="text-[11px] font-black text-[#0B1F3A] flex items-center gap-1">
                      <Type className="w-3.5 h-3.5 text-[#D4A44B]" />
                      <span>١. التحكم في أحجام الخطوط (Font Sizes):</span>
                    </h5>

                    {/* Shop Name Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>اسم المعرض الرئيسي: {fontSizes.shopName}px</span>
                      </div>
                      <input
                        type="range"
                        min="16"
                        max="60"
                        value={fontSizes.shopName}
                        onChange={(e) => setFontSizes({ ...fontSizes, shopName: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Shop Phone Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>هاتف المعرض وبيانات الرأس: {fontSizes.shopPhone}px</span>
                      </div>
                      <input
                        type="range"
                        min="12"
                        max="35"
                        value={fontSizes.shopPhone}
                        onChange={(e) => setFontSizes({ ...fontSizes, shopPhone: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Title Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>عنوان الفاتورة الرئيسي: {fontSizes.title}px</span>
                      </div>
                      <input
                        type="range"
                        min="16"
                        max="45"
                        value={fontSizes.title}
                        onChange={(e) => setFontSizes({ ...fontSizes, title: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Customer Name Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>اسم العميل / الزبون: {fontSizes.customerName}px</span>
                      </div>
                      <input
                        type="range"
                        min="16"
                        max="55"
                        value={fontSizes.customerName}
                        onChange={(e) => setFontSizes({ ...fontSizes, customerName: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Customer Phone Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>هاتف العميل وبيانات الاتصال: {fontSizes.customerPhone}px</span>
                      </div>
                      <input
                        type="range"
                        min="14"
                        max="40"
                        value={fontSizes.customerPhone}
                        onChange={(e) => setFontSizes({ ...fontSizes, customerPhone: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Product Name Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>اسم المادة أو الجهاز المباع: {fontSizes.productName}px</span>
                      </div>
                      <input
                        type="range"
                        min="12"
                        max="40"
                        value={fontSizes.productName}
                        onChange={(e) => setFontSizes({ ...fontSizes, productName: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Financial Labels / Labels Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>عناوين الأقساط (الواصل والمتبقي): {fontSizes.financialLabel}px</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="30"
                        value={fontSizes.financialLabel}
                        onChange={(e) => setFontSizes({ ...fontSizes, financialLabel: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Financial Values Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>قيم المبالغ والأرقام المالية: {fontSizes.financialValue}px</span>
                      </div>
                      <input
                        type="range"
                        min="14"
                        max="45"
                        value={fontSizes.financialValue}
                        onChange={(e) => setFontSizes({ ...fontSizes, financialValue: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Due Date Banner Value Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>تاريخ وشريط الاستحقاق القادم: {fontSizes.dueBannerValue}px</span>
                      </div>
                      <input
                        type="range"
                        min="14"
                        max="40"
                        value={fontSizes.dueBannerValue}
                        onChange={(e) => setFontSizes({ ...fontSizes, dueBannerValue: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>

                    {/* Footer Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>نصوص التذييل وشكر العميل أسفل الوصل: {fontSizes.footer}px</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="28"
                        value={fontSizes.footer}
                        onChange={(e) => setFontSizes({ ...fontSizes, footer: Number(e.target.value) })}
                        className="w-full accent-[#0B1F3A]"
                      />
                    </div>
                  </div>

                  {/* 2. Category: Paddings & Spacings */}
                  <div className="space-y-3 pt-4 border-t border-slate-100">
                    <h5 className="text-[11px] font-black text-[#0B1F3A] flex items-center gap-1">
                      <Ruler className="w-3.5 h-3.5 text-[#D4A44B]" />
                      <span>٢. التحكم في التباعد والمسافات (Spacing / Padding):</span>
                    </h5>

                    {/* Shop Name Spacing */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>المسافة أسفل اسم المحل: {paddings.shopNameBottom}px</span>
                      </div>
                      <input
                        type="range"
                        min="15"
                        max="100"
                        value={paddings.shopNameBottom}
                        onChange={(e) => setPaddings({ ...paddings, shopNameBottom: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>

                    {/* Shop Phone Spacing */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>المسافة أسفل هاتف المحل: {paddings.shopPhoneBottom}px</span>
                      </div>
                      <input
                        type="range"
                        min="15"
                        max="90"
                        value={paddings.shopPhoneBottom}
                        onChange={(e) => setPaddings({ ...paddings, shopPhoneBottom: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>

                    {/* Title Spacing */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>المسافة أسفل عنوان الفاتورة: {paddings.titleBottom}px</span>
                      </div>
                      <input
                        type="range"
                        min="15"
                        max="100"
                        value={paddings.titleBottom}
                        onChange={(e) => setPaddings({ ...paddings, titleBottom: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>

                    {/* Customer Card Spacing */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>المسافة وتكبير بطاقة العميل: {paddings.customerCardBottom}px</span>
                      </div>
                      <input
                        type="range"
                        min="15"
                        max="100"
                        value={paddings.customerCardBottom}
                        onChange={(e) => setPaddings({ ...paddings, customerCardBottom: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>

                    {/* Product Spacing */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>المسافة أسفل اسم المادة: {paddings.productBottom}px</span>
                      </div>
                      <input
                        type="range"
                        min="15"
                        max="100"
                        value={paddings.productBottom}
                        onChange={(e) => setPaddings({ ...paddings, productBottom: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>

                    {/* Financial Row Spacing */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>التباعد بين سطور الحسابات المالية: {paddings.financialRowBottom}px</span>
                      </div>
                      <input
                        type="range"
                        min="15"
                        max="100"
                        value={paddings.financialRowBottom}
                        onChange={(e) => setPaddings({ ...paddings, financialRowBottom: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>

                    {/* Due Date Spacing */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>الارتفاع والمسافة لشريط الاستحقاق: {paddings.dueBannerBottom}px</span>
                      </div>
                      <input
                        type="range"
                        min="15"
                        max="120"
                        value={paddings.dueBannerBottom}
                        onChange={(e) => setPaddings({ ...paddings, dueBannerBottom: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>
                  </div>

                  {/* Action Bar inside form */}
                  <div className="pt-3 border-t border-slate-100 flex gap-2 justify-end">
                    <button
                      type="button"
                      onClick={saveCustomTemplate}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                    >
                      <Save className="w-4 h-4 text-white" />
                      <span>حفظ القالب المخصص</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsCreatingTemplate(false)}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl text-xs transition-all cursor-pointer"
                    >
                      إلغاء التراجع
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* SECTION 2: Backup and Restore Section */}
        <div className="bg-slate-50/50 rounded-2xl border border-slate-200/60 overflow-hidden shadow-sm">
          <button
            type="button"
            onClick={() => setIsBackupExpanded(!isBackupExpanded)}
            className="w-full p-4 flex items-center justify-between font-extrabold text-slate-800 bg-slate-100/50 hover:bg-slate-100 transition-colors border-b border-slate-200/50 cursor-pointer text-right"
          >
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-[#D4A44B]" />
              <span className="text-sm">💾 إدارة النسخ الاحتياطي والاستعادة الشاملة</span>
            </div>
            {isBackupExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
          </button>

          {isBackupExpanded && (
            <div className="p-4 space-y-4">
              <p className="text-[11px] text-slate-500 leading-relaxed font-bold">
                يدعم النظام ضغط جميع السجلات والصور وتصديرها في ملف أرشيف مجمع <span className="text-[#D4A44B]">ZIP</span> محمي ومؤمن برمز أمان، وضمان سلامة البيانات وصور الكفلاء بنسبة 100%.
              </p>

              {/* Real-time Progress Bar Indicator */}
              {progressPercent !== null && (
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-3 shadow-inner">
                  <div className="flex justify-between items-center text-xs font-extrabold text-[#0B1F3A]">
                    <span className="flex items-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#D4A44B]" />
                      <span>{progressMessage}</span>
                    </span>
                    <span className="font-mono text-[#0B1F3A] bg-slate-100 px-2 py-0.5 rounded-lg">{progressPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-[#0B1F3A] via-[#D4A44B] to-emerald-500 h-full transition-all duration-300 rounded-full"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              )}
      
              <div className="grid grid-cols-2 gap-3 pt-1">
                {/* Export Button */}
                <button
                  type="button"
                  onClick={handleExport}
                  disabled={isExporting || isImporting}
                  className="h-12 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-[#0B1F3A] hover:text-[#D4A44B] font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50"
                >
                  {isExporting ? (
                    <>
                      <RefreshCw className="w-4 h-4 text-[#D4A44B] animate-spin" />
                      <span>جاري التحضير...</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-4 h-4 text-[#D4A44B]" />
                      <span>تصدير ومشاركة ZIP</span>
                    </>
                  )}
                </button>
      
                {/* Import Button */}
                <label className={`h-12 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-[#0B1F3A] hover:text-[#D4A44B] font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.98] text-center ${(isImporting || isExporting) ? 'opacity-50 pointer-events-none' : ''}`}>
                  {isImporting ? (
                    <>
                      <RefreshCw className="w-4 h-4 text-[#D4A44B] animate-spin" />
                      <span>جاري الاستيراد...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 text-[#D4A44B]" />
                      <span>استيراد ملف ZIP</span>
                    </>
                  )}
                  <input
                    type="file"
                    accept=".zip"
                    className="hidden"
                    disabled={isImporting || isExporting}
                    onChange={handleImportFileChange}
                  />
                </label>
              </div>

              {/* Historical Logs List */}
              <div className="border-t border-slate-100 pt-6 space-y-3">
                <div className="flex items-center gap-2 text-slate-800 font-extrabold text-sm">
                  <History className="w-4 h-4 text-[#0B1F3A]" />
                  <span>📜 سجل عمليات النسخ واستعادة السابقة</span>
                </div>
                
                {backupLogs.length === 0 ? (
                  <div className="bg-slate-50 rounded-xl p-4 text-center border border-dashed border-slate-200">
                    <p className="text-[10px] text-slate-400 font-bold">لا توجد عمليات تصدير أو استيراد مسجلة حتى الآن.</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {backupLogs.map((log) => (
                      <div 
                        key={log.id} 
                        className={`p-3 rounded-xl border text-xs flex flex-col gap-1.5 transition-all hover:bg-slate-50/50 ${
                          log.status === "success" 
                            ? "bg-emerald-50/20 border-emerald-100" 
                            : "bg-rose-50/20 border-rose-100"
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className={`px-2 py-0.5 rounded-md font-bold text-[9px] ${
                            log.type === "export" 
                              ? "bg-slate-100 text-slate-700 border border-slate-200" 
                              : "bg-emerald-50 text-emerald-700 border border-emerald-100"
                          }`}>
                            {log.type === "export" ? "تصدير نسخة احتياطية" : "استيراد واستعادة"}
                          </span>
                          <span className="text-[9px] text-slate-400 font-semibold font-mono">
                            {new Date(log.timestamp).toLocaleString("ar-EG", {
                              year: 'numeric', month: 'short', day: 'numeric',
                              hour: '2-digit', minute: '2-digit'
                            })}
                          </span>
                        </div>
                        
                        <div className="flex justify-between items-center text-[10px] text-slate-600 font-bold">
                          <span>مدة العملية: {log.durationMs >= 1000 ? `${(log.durationMs / 1000).toFixed(1)} ث` : `${log.durationMs} مل ث`}</span>
                          <span>عدد السجلات: {log.recordsCount}</span>
                          <span className={`font-semibold flex items-center gap-1 ${
                            log.status === "success" ? "text-emerald-700" : "text-rose-700"
                          }`}>
                            ● {log.status === "success" ? "ناجحة" : "فشلت"}
                          </span>
                        </div>

                        {log.error && (
                          <p className="text-[9px] text-rose-600 bg-rose-50/50 p-1.5 rounded-lg border border-rose-100/40 leading-relaxed font-semibold">
                            السبب: {log.error}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

      </div>

      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-[28px] max-w-md w-full border border-slate-100 shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-right"
            dir="rtl"
          >
            {/* Modal Header */}
            <div className="bg-amber-50 border-b border-amber-100 p-5 flex gap-3 items-start">
              <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5 animate-pulse" />
              <div className="space-y-1">
                <h3 className="text-sm font-extrabold text-amber-900">تنبيه هام جداً واستعادة شاملة</h3>
                <p className="text-xs text-amber-800 font-semibold">
                  تحذير: سيتم حذف جميع البيانات الحالية بالكامل واستبدالها ببيانات الملف المختار!
                </p>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div className="bg-slate-50 rounded-2xl p-4 text-xs space-y-2 border border-slate-100 font-medium text-slate-600 leading-relaxed">
                <p>
                  عملية استيراد واستعادة البيانات من ملف <span className="text-[#0B1F3A] font-bold">ZIP</span> هي عملية حساسة وشاملة، حيث سيقوم التطبيق بـ:
                </p>
                <ul className="list-disc list-inside space-y-1 text-slate-700 pr-1">
                  <li>مسح كافة العملاء والأقساط المسجلين حالياً في هذا الجهاز.</li>
                  <li>حذف جميع المستندات وصور الكفلاء القديمة المخزنة.</li>
                  <li>استرجاع كافة سجلات وملفات وصور ملف الأرشيف <span className="font-bold text-emerald-700">"{pendingFile?.name}"</span> بنسبة 100%.</li>
                </ul>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={executeImport}
                  className="flex-1 h-11 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md active:scale-95 animate-pulse"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>نعم، امسح واستعد البيانات</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowConfirmModal(false);
                    setPendingFile(null);
                  }}
                  className="h-11 px-5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs transition-all cursor-pointer active:scale-95"
                >
                  <span>إلغاء</span>
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {importResultReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-[28px] max-w-md w-full border border-slate-100 shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-right"
            dir="rtl"
          >
            {/* Modal Header */}
            {importResultReport && (importResultReport.includes("الصور المفقودة:") && !importResultReport.includes("الصور المفقودة: 0")) ? (
              <div className="bg-amber-50 border-b border-amber-100 p-5 flex gap-3 items-start">
                <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5 animate-pulse" />
                <div className="space-y-1">
                  <h3 className="text-sm font-extrabold text-amber-900">تقرير استعادة النسخة الاحتياطية (تنبيه)</h3>
                  <p className="text-xs text-amber-800 font-semibold">
                    تمت استعادة البيانات بنجاح، ولكن توجد صور مفقودة غير موجودة في الأرشيف!
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-emerald-50 border-b border-emerald-100 p-5 flex gap-3 items-start">
                <ShieldCheck className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="text-sm font-extrabold text-emerald-900">تقرير استعادة النسخة الاحتياطية</h3>
                  <p className="text-xs text-emerald-800 font-semibold">
                    تمت استعادة كافة البيانات والملفات بنجاح تام بنسبة 100%!
                  </p>
                </div>
              </div>
            )}

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div className="bg-slate-50 rounded-2xl p-4 text-xs space-y-3 border border-slate-100 font-semibold text-slate-700 leading-relaxed">
                {importResultReport.split("\n").map((line, idx) => {
                  const colonIndex = line.indexOf(":");
                  if (colonIndex === -1) {
                    return <p key={idx} className="text-slate-800 font-extrabold text-center border-b border-slate-200/50 pb-2 last:border-b-0">{line}</p>;
                  }
                  const label = line.substring(0, colonIndex);
                  const val = line.substring(colonIndex + 1);
                  return (
                    <p key={idx} className="flex justify-between items-center py-1 border-b border-slate-200/50 last:border-b-0">
                      <span>{label}:</span>
                      <span className="font-extrabold text-[#0B1F3A] font-mono text-sm">{val}</span>
                    </p>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={() => setImportResultReport(null)}
                className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md active:scale-95"
              >
                <span>موافق، رائع!</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}
