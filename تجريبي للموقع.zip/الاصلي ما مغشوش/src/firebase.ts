
import JSZip from "jszip";

export interface Payment {
  date: string;
  amount: number;
}

export interface CustomerImages {
  personal?: string;
  resFront?: string;
  resBack?: string;
  idFront?: string;
  idBack?: string;
}

export interface GuarantorImages {
  personal?: string;
  idFront?: string;
  idBack?: string;
  resFront?: string;
  resBack?: string;
}

export interface Guarantor {
  name: string;
  phone: string;
  address: string;
  nationalId?: string;
  images?: GuarantorImages;
  profession?: string;
  relationship?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  nationalId?: string;
  productName: string;
  productSerial: string;
  totalAmount: number;
  upfront: number;
  monthlyAmount: number;
  remainingAmount: number;
  dueDay: number;
  images?: CustomerImages;
  payments: Payment[];
  status: 'active' | 'done';
  dateAdded: string;
  hasGuarantor?: boolean;
  guarantor?: Guarantor;
  governorate?: string;
  nearestLandmark?: string;
  profession?: string;
  productDetails?: string;
  installmentCount?: number;
  firstInstallmentDate?: string;
}

export interface SystemCredentials {
  username?: string;
  password?: string;
  fullName?: string;
  age?: string;
  phone?: string;
}

// --- INDEXEDDB DATA SERVICE ENGINGE ---

const DB_NAME = "AlAqsatOfflineDb";
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbInstance) return Promise.resolve(dbInstance);

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("customers")) {
        db.createObjectStore("customers", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("system")) {
        db.createObjectStore("system", { keyPath: "id" });
      }
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

// --- LOCAL DATA ACCESS OPERATIONS ---

export async function getAllCustomersFromIndexedDB(): Promise<Customer[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readonly");
    const store = transaction.objectStore("customers");
    const request = store.getAll();

    request.onsuccess = () => {
      resolve(request.result || []);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

export async function saveCustomerToIndexedDB(customer: Customer): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    const request = store.put(customer);

    request.onsuccess = () => {
      resolve();
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

export async function deleteCustomerFromIndexedDB(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    const request = store.delete(id);

    request.onsuccess = () => {
      resolve();
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

export async function overwriteAllCustomersInIndexedDB(newCustomers: Customer[]): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    
    transaction.oncomplete = () => {
      resolve();
    };
    
    transaction.onerror = () => {
      reject(transaction.error);
    };

    store.clear();
    for (const cust of newCustomers) {
      store.put(cust);
    }
  });
}

async function getSystemCredentialsFromIndexedDB(): Promise<SystemCredentials | null> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("system", "readonly");
    const store = transaction.objectStore("system");
    const request = store.get("credentials");

    request.onsuccess = () => {
      const result = request.result;
      if (result && result.creds) {
        resolve(result.creds);
      } else {
        resolve(null);
      }
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

async function saveSystemCredentialsToIndexedDB(creds: SystemCredentials): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("system", "readwrite");
    const store = transaction.objectStore("system");
    const request = store.put({ id: "credentials", creds });

    request.onsuccess = () => {
      resolve();
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

// --- PUBSUB STATE MANANGEMENT ---

const customersListeners: ((customers: Customer[]) => void)[] = [];
const credentialsListeners: ((creds: SystemCredentials | null) => void)[] = [];

async function notifyCustomersListeners() {
  try {
    const list = await getAllCustomersFromIndexedDB();
    
    // Map to a lightweight list to prevent massive base64 strings in the React global list state
    const lightList = list.map(cust => {
      const lightCust = { ...cust };
      if (lightCust.images) {
        lightCust.images = { personal: lightCust.images.personal };
      }
      if (lightCust.guarantor) {
        lightCust.guarantor = { ...lightCust.guarantor };
        if (lightCust.guarantor.images) {
          lightCust.guarantor.images = { personal: lightCust.guarantor.images.personal };
        }
      }
      return lightCust;
    });

    for (const callback of customersListeners) {
      callback(lightList);
    }
  } catch (err) {
    console.error("Error notifying customers listeners:", err);
  }
}

async function notifyCredentialsListeners() {
  try {
    const creds = await getSystemCredentialsFromIndexedDB();
    for (const callback of credentialsListeners) {
      callback(creds);
    }
  } catch (err) {
    console.error("Error notifying credentials listeners:", err);
  }
}

/**
 * Completely clears all customers in IndexedDB local database store
 */
export async function clearAllLocalDatabaseData(): Promise<void> {
  const db = await getDB();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
  await notifyCustomersListeners();
}

/**
 * Saves or updates a customer in IndexedDB local store
 */
export async function saveCustomer(customer: Customer): Promise<void> {
  await saveCustomerToIndexedDB(customer);
  await notifyCustomersListeners();
}

/**
 * Deletes a customer from IndexedDB local store
 */
export async function deleteCustomerFromDb(id: string): Promise<void> {
  await deleteCustomerFromIndexedDB(id);
  await notifyCustomersListeners();
}

/**
 * Subscribes to real-time changes of the customers list in IndexedDB
 */
export function subscribeToCustomers(callback: (customers: Customer[]) => void): () => void {
  customersListeners.push(callback);
  
  // Call immediately with current data
  getAllCustomersFromIndexedDB()
    .then((list) => {
      // Map to lightweight list to keep React super fast and lightweight
      const lightList = list.map(cust => {
        const lightCust = { ...cust };
        if (lightCust.images) {
          lightCust.images = { personal: lightCust.images.personal };
        }
        if (lightCust.guarantor) {
          lightCust.guarantor = { ...lightCust.guarantor };
          if (lightCust.guarantor.images) {
            lightCust.guarantor.images = { personal: lightCust.guarantor.images.personal };
          }
        }
        return lightCust;
      });
      if (customersListeners.includes(callback)) {
        callback(lightList);
      }
    })
    .catch((err) => console.error("Error fetching customers for subscription:", err));

  return () => {
    const index = customersListeners.indexOf(callback);
    if (index !== -1) {
      customersListeners.splice(index, 1);
    }
  };
}

/**
 * Saves or updates system credentials in IndexedDB local store
 */
export async function saveSystemCredentials(creds: SystemCredentials): Promise<void> {
  await saveSystemCredentialsToIndexedDB(creds);
  await notifyCredentialsListeners();
}

/**
 * Subscribes to real-time changes of system credentials in IndexedDB
 */
export function subscribeToSystemCredentials(callback: (creds: SystemCredentials | null) => void): () => void {
  credentialsListeners.push(callback);

  // Call immediately with current data
  getSystemCredentialsFromIndexedDB()
    .then((creds) => {
      if (credentialsListeners.includes(callback)) {
        callback(creds);
      }
    })
    .catch((err) => console.error("Error fetching credentials for subscription:", err));

  return () => {
    const index = credentialsListeners.indexOf(callback);
    if (index !== -1) {
      credentialsListeners.splice(index, 1);
    }
  };
}

// --- BACKUP & RESTORE SYSTEM ---

export interface BackupData {
  version: number;
  exportDate: string;
  customers: Customer[];
  credentials: SystemCredentials | null;
}

const CUSTOMER_IMAGE_LABELS: Record<keyof CustomerImages, string> = {
  personal: "صورة_شخصية",
  idFront: "هوية_وجه",
  idBack: "هوية_ظهر",
  resFront: "بطاقة_سكن_وجه",
  resBack: "بطاقة_سكن_ظهر"
};

const GUARANTOR_IMAGE_LABELS: Record<keyof GuarantorImages, string> = {
  personal: "صورة_شخصية",
  idFront: "هوية_وجه",
  idBack: "هوية_ظهر",
  resFront: "بطاقة_سكن_وجه",
  resBack: "بطاقة_سكن_ظهر"
};

function parseBase64Image(dataUrl: string) {
  if (!dataUrl || typeof dataUrl !== "string") return null;
  const parts = dataUrl.split(",");
  if (parts.length < 2) return null;
  const mimeMatch = parts[0].match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : "image/jpeg";
  let extension = mime.split("/")[1] || "jpg";
  if (extension === "jpeg") extension = "jpg";
  return {
    mime,
    extension,
    base64: parts[1]
  };
}

function sanitizeFileName(name: string): string {
  return name.replace(/[\/\\?%*:|"<>\s]/g, "_");
}

/**
 * Exports all IndexedDB data into a single JSON backup string (for backward compatibility)
 */
export async function exportBackupData(): Promise<string> {
  const customers = await getAllCustomersFromIndexedDB();
  const credentials = await getSystemCredentialsFromIndexedDB();
  
  const backup: BackupData = {
    version: 1,
    exportDate: new Date().toISOString(),
    customers,
    credentials
  };
  
  return JSON.stringify(backup);
}

/**
 * Restores data from a JSON backup string into local IndexedDB (for backward compatibility)
 */
export async function importBackupData(jsonString: string): Promise<void> {
  const data = JSON.parse(jsonString) as BackupData;
  if (!data || typeof data !== "object") {
    throw new Error("تنسيق ملف النسخ الاحتياطي غير صالح");
  }
  
  if (!Array.isArray(data.customers)) {
    throw new Error("ملف النسخ الاحتياطي لا يحتوي على قائمة عملاء صالحة");
  }

  const db = await getDB();
  
  // 1. Clear existing customers
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });

  // 2. Clear existing system credentials
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("system", "readwrite");
    const store = transaction.objectStore("system");
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });

  // 3. Write imported customers
  if (data.customers.length > 0) {
    const customerTx = db.transaction("customers", "readwrite");
    const customerStore = customerTx.objectStore("customers");
    for (const customer of data.customers) {
      customerStore.put(customer);
    }
    await new Promise<void>((resolve, reject) => {
      customerTx.oncomplete = () => resolve();
      customerTx.onerror = () => reject(customerTx.error);
    });
  }

  // 4. Write imported credentials if present
  if (data.credentials) {
    await saveSystemCredentialsToIndexedDB(data.credentials);
  }

  // 5. Notify all listeners to update current screens immediately
  await notifyCustomersListeners();
  await notifyCredentialsListeners();
}

/**
 * Exports all IndexedDB data including raw pictures inside a structured ZIP archive
 */
export interface BackupLog {
  id: string;
  type: "export" | "import";
  timestamp: string;
  durationMs: number;
  recordsCount: number;
  status: "success" | "failed";
  error?: string;
  failedRecords?: string[];
}

export async function getBackupLogs(): Promise<BackupLog[]> {
  const db = await getDB();
  return new Promise((resolve) => {
    try {
      const transaction = db.transaction("system", "readonly");
      const store = transaction.objectStore("system");
      const request = store.get("backup_logs");
      request.onsuccess = () => {
        const res = request.result;
        resolve(res && Array.isArray(res.logs) ? res.logs : []);
      };
      request.onerror = () => {
        resolve([]);
      };
    } catch (e) {
      resolve([]);
    }
  });
}

export async function addBackupLog(log: Omit<BackupLog, "id">): Promise<void> {
  const db = await getDB();
  const currentLogs = await getBackupLogs();
  const newLog: BackupLog = {
    ...log,
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`
  };
  // Keep last 50 entries
  const updatedLogs = [newLog, ...currentLogs].slice(0, 50);
  return new Promise((resolve, reject) => {
    try {
      const transaction = db.transaction("system", "readwrite");
      const store = transaction.objectStore("system");
      const request = store.put({ id: "backup_logs", logs: updatedLogs });
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    } catch (e) {
      reject(e);
    }
  });
}

/**
 * Helper to compute an offline-safe lightweight string hash as a data validation checksum
 */
function generateSimpleChecksum(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(16);
}

/**
 * Dynamic walker that extracts and isolates base64 image strings into a separate images ZIP directory
 */
function extractBase64Images(data: any, pathPrefix: string, zip: JSZip, imageFilesList: string[]): any {
  if (data === null || data === undefined) return data;

  if (Array.isArray(data)) {
    return data.map((item, index) => extractBase64Images(item, `${pathPrefix}/${index}`, zip, imageFilesList));
  }

  if (typeof data === "object") {
    const cloned = { ...data };
    for (const key of Object.keys(cloned)) {
      const val = cloned[key];
      if (typeof val === "string" && val.startsWith("data:image/")) {
        const parsed = parseBase64Image(val);
        if (parsed) {
          const recordId = data.id || data.username || "item";
          const label = key;
          const filePath = `images/${pathPrefix}/${recordId}_${label}.${parsed.extension}`;
          zip.file(filePath, parsed.base64, { base64: true });
          imageFilesList.push(filePath);
          cloned[key] = filePath;
        }
      } else if (typeof val === "object") {
        cloned[key] = extractBase64Images(val, `${pathPrefix}/${key}`, zip, imageFilesList);
      }
    }
    return cloned;
  }

  return data;
}

/**
 * Re-integrates separate ZIP images into their original base64 format in database records
 */
async function restoreBase64Images(data: any, loadedZip: JSZip): Promise<any> {
  if (data === null || data === undefined) return data;

  if (Array.isArray(data)) {
    const restoredArray = [];
    for (const item of data) {
      restoredArray.push(await restoreBase64Images(item, loadedZip));
    }
    return restoredArray;
  }

  if (typeof data === "object") {
    const cloned = { ...data };
    for (const key of Object.keys(cloned)) {
      const val = cloned[key];
      if (typeof val === "string" && val.startsWith("images/")) {
        const imgFile = loadedZip.file(val);
        if (imgFile) {
          const ext = val.split(".").pop()?.toLowerCase() || "jpg";
          const mime = ext === "png" ? "image/png" : "image/jpeg";
          const base64Content = await imgFile.async("base64");
          cloned[key] = `data:${mime};base64,${base64Content}`;
        }
      } else if (typeof val === "object") {
        cloned[key] = await restoreBase64Images(val, loadedZip);
      }
    }
    return cloned;
  }

  return data;
}

/**
 * Legacy path resolver with fuzzy search for images inside ZIP backup files
 */
async function resolveImageFromZip(originalPath: string, customerId: string, fieldName: string, loadedZip: JSZip): Promise<string | undefined> {
  if (!originalPath || typeof originalPath !== "string") return undefined;
  if (originalPath.startsWith("data:")) return originalPath;

  let imgFile = loadedZip.file(originalPath);
  if (!imgFile) {
    imgFile = loadedZip.file(originalPath.replace(/\\/g, "/"));
  }

  if (!imgFile) {
    const fileKeys = Object.keys(loadedZip.files);
    const targetId = customerId.trim();
    const lowerKey = fieldName.toLowerCase();
    const arabicLabel = CUSTOMER_IMAGE_LABELS[fieldName as keyof CustomerImages] || 
                        GUARANTOR_IMAGE_LABELS[fieldName as keyof GuarantorImages] || 
                        fieldName;

    for (const zipPath of fileKeys) {
      if (loadedZip.files[zipPath].dir) continue;
      const normalizedZipPath = zipPath.replace(/\\/g, "/");
      if (normalizedZipPath.includes(targetId)) {
        if (normalizedZipPath.includes(arabicLabel) || normalizedZipPath.toLowerCase().includes(lowerKey)) {
          imgFile = loadedZip.file(zipPath);
          break;
        }
      }
    }
  }

  if (imgFile) {
    const ext = originalPath.split(".").pop()?.toLowerCase() || "jpg";
    const mime = ext === "png" ? "image/png" : "image/jpeg";
    const base64Content = await imgFile.async("base64");
    return `data:${mime};base64,${base64Content}`;
  }

  return undefined;
}

/**
 * Writes records to IndexedDB in sequential chunked batches to keep browser fluid and unfrozen
 */
async function writeStoreInBatches(storeName: string, items: any[], onProgress?: (msg: string) => void) {
  const db = await getDB();
  const BATCH_SIZE = 500;
  const total = items.length;

  for (let i = 0; i < total; i += BATCH_SIZE) {
    const batch = items.slice(i, i + BATCH_SIZE);

    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      for (const item of batch) {
        store.put(item);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });

    if (onProgress) {
      const written = Math.min(i + BATCH_SIZE, total);
      const pct = Math.round((written / total) * 100);
      onProgress(`جاري كتابة جدول ${storeName}: ${pct}% (${written}/${total})`);
    }

    // Give breathing room to the browser rendering loop
    await new Promise(r => setTimeout(r, 1));
  }
}

/**
 * Exports all IndexedDB data including raw pictures inside a structured ZIP archive
 */
export async function exportBackupZip(
  onProgress?: (percent: number, message: string) => void
): Promise<Blob> {
  const startTime = Date.now();
  onProgress?.(5, "جاري فتح قاعدة البيانات وقراءة الجداول تلقائياً...");

  const db = await getDB();
  const storeNames = Array.from(db.objectStoreNames);
  const rawData: Record<string, any[]> = {};
  let totalRecordsCount = 0;

  for (let i = 0; i < storeNames.length; i++) {
    const storeName = storeNames[i];
    onProgress?.(10 + i * 5, `جاري استخراج السجلات من الجدول: ${storeName}...`);

    const tx = db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    const items = await new Promise<any[]>((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    rawData[storeName] = items;
    totalRecordsCount += items.length;
  }

  onProgress?.(30, "جاري عزل وتوليد مجلدات الصور المنفصلة لزيادة الكفاءة...");
  const zip = new JSZip();
  const imageFilesList: string[] = [];

  const processedData: Record<string, any[]> = {};
  for (const storeName of storeNames) {
    processedData[storeName] = rawData[storeName].map((item, index) => {
      return extractBase64Images(item, `${storeName}/${index}`, zip, imageFilesList);
    });
  }

  onProgress?.(55, "جاري توليد ملفات التحقق والأمان والبيانات الوصفية...");
  const backupJsonStr = JSON.stringify(processedData, null, 2);
  zip.file("backup.json", backupJsonStr);

  const checksum = generateSimpleChecksum(backupJsonStr);
  zip.file("checksum.json", JSON.stringify({ checksum, recordsCount: totalRecordsCount }, null, 2));

  const versionData = {
    backupFormatVersion: 2,
    dbVersion: DB_VERSION,
    appVersion: "1.0.0"
  };
  zip.file("version.json", JSON.stringify(versionData, null, 2));

  const metadata = {
    createdAt: new Date().toISOString(),
    appVersion: "1.0.0",
    dbVersion: DB_VERSION,
    backupFormatVersion: 2,
    stores: storeNames.reduce((acc, name) => {
      acc[name] = rawData[name].length;
      return acc;
    }, {} as Record<string, number>),
    totalRecords: totalRecordsCount,
    imagesCount: imageFilesList.length,
    estimatedSize: backupJsonStr.length
  };
  zip.file("metadata.json", JSON.stringify(metadata, null, 2));

  // Legacy format files for backward compatibility:
  if (rawData["customers"]) {
    const customersList = rawData["customers"] as Customer[];
    
    // Customers human-friendly TXT summary reports
    for (const customer of customersList) {
      const safeCustomerName = sanitizeFileName(customer.name || "عميل_بلا_اسم");
      const customerDirName = `${safeCustomerName}_${customer.id}`;
      const infoText = `=== معلومات عميل القسط ===
الاسم: ${customer.name || ""}
الهاتف: ${customer.phone || ""}
الهوية الوطنية: ${customer.nationalId || "غير محدد"}
المحافظة: ${customer.governorate || "غير محدد"}
أقرب نقطة دالة: ${customer.nearestLandmark || "غير محدد"}
تاريخ الإضافة: ${customer.dateAdded || ""}

=== تفاصيل المنتج والأقساط ===
اسم المنتج: ${customer.productName || ""}
الرقم التسلسلي: ${customer.productSerial || ""}
إجمالي مبلغ القسط: ${customer.totalAmount || 0} د.ع
المقدم المدفوع: ${customer.upfront || 0} د.ع
المبلغ المتبقي: ${customer.remainingAmount || 0} د.ع
القسط الشهري: ${customer.monthlyAmount || 0} د.ع
يوم الاستحقاق الشهري: يوم ${customer.dueDay || ""} من كل شهر
حالة القسط: ${customer.status === "active" ? "نشط" : "مكتمل"}

=== تفاصيل الكفيل ===
${customer.hasGuarantor ? `اسم الكفيل: ${customer.guarantor?.name || ""}
هاتف الكفيل: ${customer.guarantor?.phone || ""}
عنوان الكفيل: ${customer.guarantor?.address || ""}
الهوية الوطنية للكفيل: ${customer.guarantor?.nationalId || ""}` : "لا يوجد كفيل"}

=== سجل الدفعات ===
${customer.payments && customer.payments.length > 0 
  ? customer.payments.map((p, idx) => `${idx + 1}. التاريخ: ${p.date} | المبلغ: ${p.amount} د.ع`).join("\n")
  : "لا توجد دفعات مسجلة حتى الآن"
}
`;
      zip.file(`معلومات_العملاء/${customerDirName}.txt`, infoText);
    }

    // Create backup_database.json (cloned base64 for legacy raw restore)
    const rawBackupJson = {
      version: 2,
      exportDate: new Date().toISOString(),
      customers: rawData["customers"],
      credentials: rawData["system"]?.find(i => i.id === "credentials")?.creds || null
    };
    zip.file("backup_database.json", JSON.stringify(rawBackupJson, null, 2));

    // Legacy data.json
    const clonedCustomers = JSON.parse(JSON.stringify(rawData["customers"])) as Customer[];
    for (const customer of clonedCustomers) {
      const safeCustomerName = sanitizeFileName(customer.name || "عميل_بلا_اسم");
      const customerDirName = `${safeCustomerName}_${customer.id}`;

      if (customer.images) {
        const keys = Object.keys(customer.images) as (keyof CustomerImages)[];
        for (const key of keys) {
          const val = customer.images[key];
          if (val && val.startsWith("data:")) {
            const parsed = parseBase64Image(val);
            if (parsed) {
              const label = CUSTOMER_IMAGE_LABELS[key] || key;
              const filePath = `صور_اصحاب_الاقساط/${customerDirName}/${label}.${parsed.extension}`;
              zip.file(filePath, parsed.base64, { base64: true });
              customer.images[key] = filePath;
            }
          }
        }
      }

      if (customer.guarantor && customer.guarantor.images) {
        const keys = Object.keys(customer.guarantor.images) as (keyof GuarantorImages)[];
        for (const key of keys) {
          const val = customer.guarantor.images[key];
          if (val && val.startsWith("data:")) {
            const parsed = parseBase64Image(val);
            if (parsed) {
              const label = GUARANTOR_IMAGE_LABELS[key] || key;
              const filePath = `صور_الكفلاء/${customerDirName}/${label}.${parsed.extension}`;
              zip.file(filePath, parsed.base64, { base64: true });
              customer.guarantor.images[key] = filePath;
            }
          }
        }
      }
    }

    const legacyBackupJson = {
      version: 2,
      exportDate: new Date().toISOString(),
      customers: clonedCustomers,
      credentials: rawData["system"]?.find(i => i.id === "credentials")?.creds || null
    };
    zip.file("data.json", JSON.stringify(legacyBackupJson, null, 2));
  }

  onProgress?.(75, "جاري ضغط الملفات بأقصى ترميز وضغط DEFLATE...");
  const zipBlob = await zip.generateAsync({
    type: "blob",
    compression: "DEFLATE",
    compressionOptions: { level: 9 }
  });

  const durationMs = Date.now() - startTime;
  await addBackupLog({
    type: "export",
    timestamp: new Date().toISOString(),
    durationMs,
    recordsCount: totalRecordsCount,
    status: "success"
  });

  onProgress?.(100, "تم تصدير النسخة الاحتياطية وتوليد الملف بنجاح!");
  return zipBlob;
}

/**
 * Retrieves a customer by their ID directly from IndexedDB (with complete full-size images)
 */
export async function getCustomerById(id: string): Promise<Customer | null> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readonly");
    const store = transaction.objectStore("customers");
    const request = store.get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Helper to normalize and convert customer schema fields to ensure 100% correctness and backward-compatibility
 */
export function normalizeCustomer(cust: any): Customer {
  const cleanNum = (val: any, fallback = 0): number => {
    if (val === undefined || val === null) return fallback;
    const parsed = Number(val);
    return isNaN(parsed) ? fallback : parsed;
  };

  const id = typeof cust.id === "string" && cust.id.trim() !== "" 
    ? cust.id.trim() 
    : `cust-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

  // Normalize payments
  const payments = Array.isArray(cust.payments)
    ? cust.payments.map((p: any) => ({
        id: typeof p.id === "string" ? p.id : `pay-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        amount: cleanNum(p.amount),
        date: typeof p.date === "string" ? p.date : new Date().toISOString().split("T")[0],
        notes: typeof p.notes === "string" ? p.notes : ""
      }))
    : [];

  // Normalize guarantor
  let guarantor: Guarantor | undefined = undefined;
  if (cust.guarantor && typeof cust.guarantor === "object") {
    guarantor = {
      name: typeof cust.guarantor.name === "string" ? cust.guarantor.name : "",
      phone: typeof cust.guarantor.phone === "string" ? cust.guarantor.phone : "",
      address: typeof cust.guarantor.address === "string" ? cust.guarantor.address : "",
      nationalId: typeof cust.guarantor.nationalId === "string" ? cust.guarantor.nationalId : "",
      images: cust.guarantor.images && typeof cust.guarantor.images === "object" ? {
        personal: typeof cust.guarantor.images.personal === "string" ? cust.guarantor.images.personal : undefined,
        idFront: typeof cust.guarantor.images.idFront === "string" ? cust.guarantor.images.idFront : undefined,
        idBack: typeof cust.guarantor.images.idBack === "string" ? cust.guarantor.images.idBack : undefined,
        resFront: typeof cust.guarantor.images.resFront === "string" ? cust.guarantor.images.resFront : undefined,
        resBack: typeof cust.guarantor.images.resBack === "string" ? cust.guarantor.images.resBack : undefined,
      } : undefined
    };
  }

  // Normalize images
  let images: CustomerImages | undefined = undefined;
  if (cust.images && typeof cust.images === "object") {
    images = {
      personal: typeof cust.images.personal === "string" ? cust.images.personal : undefined,
      resFront: typeof cust.images.resFront === "string" ? cust.images.resFront : undefined,
      resBack: typeof cust.images.resBack === "string" ? cust.images.resBack : undefined,
      idFront: typeof cust.images.idFront === "string" ? cust.images.idFront : undefined,
      idBack: typeof cust.images.idBack === "string" ? cust.images.idBack : undefined,
    };
  }

  return {
    id,
    name: typeof cust.name === "string" ? cust.name : "عميل بلا اسم",
    phone: typeof cust.phone === "string" ? cust.phone : "",
    nationalId: typeof cust.nationalId === "string" ? cust.nationalId : "",
    productName: typeof cust.productName === "string" ? cust.productName : "",
    productSerial: typeof cust.productSerial === "string" ? cust.productSerial : "",
    totalAmount: cleanNum(cust.totalAmount),
    upfront: cleanNum(cust.upfront),
    monthlyAmount: cleanNum(cust.monthlyAmount),
    remainingAmount: cleanNum(cust.remainingAmount),
    dueDay: cleanNum(cust.dueDay, 1),
    images,
    payments,
    status: cust.status === "done" ? "done" : "active",
    dateAdded: typeof cust.dateAdded === "string" ? cust.dateAdded : new Date().toISOString().split("T")[0],
    hasGuarantor: cust.hasGuarantor !== undefined ? Boolean(cust.hasGuarantor) : Boolean(guarantor),
    guarantor,
    governorate: typeof cust.governorate === "string" ? cust.governorate : "",
    nearestLandmark: typeof cust.nearestLandmark === "string" ? cust.nearestLandmark : ""
  };
}

const IMAGE_FIELD_ALIASES: Record<string, string[]> = {
  personal: ["personal", "صورة_شخصية", "صوره_شخصيه", "الشخصية", "الشخصيه"],
  resFront: ["resfront", "res_front", "بطاقة_سكن_وجه", "سكن_وجه", "بطاقه_سكن_وجه"],
  resBack: ["resback", "res_back", "بطاقة_سكن_ظهر", "سكن_ظهر", "بطاقه_سكن_ظهر"],
  idFront: ["idfront", "id_front", "هوية_وجه", "هويه_وجه", "الوجه"],
  idBack: ["idback", "id_back", "هوية_ظهر", "هويه_ظهر", "الظهر"]
};

function normalizeArabicString(str: string): string {
  if (!str) return "";
  return str
    .replace(/[أإآا]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/\s+/g, "")
    .trim()
    .toLowerCase();
}

function convertToBase64DataUrl(val: any): string | undefined {
  if (!val) return undefined;
  if (typeof val === "string" && val.startsWith("data:image/")) {
    return val;
  }
  if (typeof val === "string" && /^[A-Za-z0-9+/=]+$/.test(val.trim().replace(/\s/g, ""))) {
    return `data:image/jpeg;base64,${val.trim()}`;
  }
  if (val instanceof ArrayBuffer) {
    const bytes = new Uint8Array(val);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return `data:image/jpeg;base64,${btoa(binary)}`;
  }
  if (val instanceof Uint8Array) {
    let binary = "";
    for (let i = 0; i < val.byteLength; i++) {
      binary += String.fromCharCode(val[i]);
    }
    return `data:image/jpeg;base64,${btoa(binary)}`;
  }
  if (typeof val === "object" && val.type === "Buffer" && Array.isArray(val.data)) {
    const bytes = new Uint8Array(val.data);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return `data:image/jpeg;base64,${btoa(binary)}`;
  }
  return undefined;
}

async function convertToBase64DataUrlAsync(val: any): Promise<string | undefined> {
  if (!val) return undefined;
  const syncConverted = convertToBase64DataUrl(val);
  if (syncConverted) return syncConverted;
  if (val instanceof Blob) {
    return new Promise<string | undefined>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result as string || undefined);
      };
      reader.onerror = () => {
        resolve(undefined);
      };
      reader.readAsDataURL(val);
    });
  }
  return undefined;
}

/**
 * Restores all data from a ZIP archive, loading separate pictures back into base64 IndexedDB store
 */
export async function importBackupZip(
  file: File | Blob,
  onProgress?: (percent: number, message: string) => void
): Promise<string> {
  const startTime = Date.now();
  console.log("⚙️ [importBackupZip] بدأ فك ضغط ملف ZIP المرفق:", file);
  onProgress?.(5, "جاري تحميل وقراءة ملف الأرشيف المضغوط...");

  const zip = new JSZip();
  let loadedZip: JSZip;
  try {
    loadedZip = await zip.loadAsync(file);
    console.log("⚙️ [importBackupZip] تم فك ضغط ZIP بنجاح. قائمة الملفات الموجودة بالأرشيف:", Object.keys(loadedZip.files));
  } catch (err) {
    console.error("⚙️ [importBackupZip] خطأ فادح أثناء فك ضغط ZIP:", err);
    throw new Error("ملف ZIP تالف أو غير صالح. يرجى اختيار ملف أرشيف صالح.");
  }

  onProgress?.(15, "جاري تحديد مواقع ملفات البيانات والتحقق من سلامة الأرشيف...");
  
  // Find backup files anywhere inside the ZIP (supports nested folders)
  let backupJsonPath = "";
  let backupDbJsonPath = "";
  let legacyDataJsonPath = "";
  let versionJsonPath = "";
  let checksumJsonPath = "";
  let metadataJsonPath = "";

  for (const path of Object.keys(loadedZip.files)) {
    const lower = path.toLowerCase();
    if (lower.endsWith("backup_database.json")) {
      backupDbJsonPath = path;
    } else if (lower.endsWith("backup.json")) {
      backupJsonPath = path;
    } else if (lower.endsWith("data.json")) {
      legacyDataJsonPath = path;
    } else if (lower.endsWith("version.json")) {
      versionJsonPath = path;
    } else if (lower.endsWith("checksum.json")) {
      checksumJsonPath = path;
    } else if (lower.endsWith("metadata.json")) {
      metadataJsonPath = path;
    }
  }

  console.log("⚙️ [importBackupZip] مسارات ملفات البيانات والتحقق داخل الـ ZIP:", {
    backupJsonPath,
    backupDbJsonPath,
    legacyDataJsonPath,
    versionJsonPath,
    checksumJsonPath,
    metadataJsonPath
  });

  // Calculate total JSON files count
  let jsonFilesCount = 0;
  for (const path of Object.keys(loadedZip.files)) {
    if (!loadedZip.files[path].dir && path.toLowerCase().endsWith(".json")) {
      jsonFilesCount++;
    }
  }

  // Determine which JSON file to use based on priority
  let mainDataPath = "";
  if (backupDbJsonPath) {
    mainDataPath = backupDbJsonPath;
  } else if (backupJsonPath) {
    mainDataPath = backupJsonPath;
  } else if (legacyDataJsonPath) {
    mainDataPath = legacyDataJsonPath;
  }

  if (!mainDataPath) {
    console.error("⚙️ [importBackupZip] خطأ: لم يتم العثور على أي من ملفات البيانات الأساسية داخل الأرشيف.");
    throw new Error("ملف النسخ الاحتياطي غير صالح. لم يتم العثور على backup_database.json أو backup.json أو data.json داخل الأرشيف.");
  }

  // Check integrity with Checksum if available
  if (checksumJsonPath) {
    onProgress?.(25, "جاري التحقق من رمز الحماية وسلامة السجلات (Integrity Check)...");
    try {
      console.log("⚙️ [importBackupZip] جاري التحقق من ملف التوقيع الرقمي (checksum.json)...");
      const checksumText = await loadedZip.file(checksumJsonPath)!.async("text");
      const checksumData = JSON.parse(checksumText);
      const targetVerifyPath = backupJsonPath || mainDataPath;
      
      if (targetVerifyPath) {
        const backupJsonText = await loadedZip.file(targetVerifyPath)!.async("text");
        const calculated = generateSimpleChecksum(backupJsonText);
        console.log("⚙️ [importBackupZip] مقارنة الهاش:", { original: checksumData.checksum, calculated, targetVerifyPath });
        
        let isMatch = checksumData.checksum === calculated;
        if (!isMatch) {
          // Normalize line endings to see if it fixes Windows vs Linux line ending differences
          const normalizedText = backupJsonText.replace(/\r\n/g, "\n").trim();
          const calculatedNormalized = generateSimpleChecksum(normalizedText);
          isMatch = checksumData.checksum === calculatedNormalized;
        }

        if (!isMatch) {
          console.warn("⚙️ [importBackupZip] تحذير: رمز الحماية لا يتطابق. جاري التحقق من سلامة هيكل JSON كبديل مرن...");
          // Fallback: Validate JSON structure to ensure file is not corrupted
          try {
            JSON.parse(backupJsonText);
            console.log("⚙️ [importBackupZip] نجح التحقق من سلامة هيكل ملف البيانات بنجاح (الهيكل سليم). سنسمح بالاستيراد.");
          } catch (jsonErr) {
            throw new Error("فشل التحقق من رمز الأمان والتحقق. قد يكون الملف تالفاً أو تم تعديله.");
          }
        } else {
          console.log("⚙️ [importBackupZip] نجح التحقق من رمز التوقيع والتحقق 100%");
        }
      }
    } catch (err: any) {
      console.warn("⚙️ [importBackupZip] تخطي أو فشل التحقق من رمز الحماية:", err);
      if (err.message && err.message.includes("رمز")) throw err;
    }
  }

  onProgress?.(35, "جاري تحليل هيكل البيانات ووصف السجلات...");
  let restoredCustomers: any[] = [];
  let restoredSystem: any[] = [];

  try {
    console.log(`⚙️ [importBackupZip] جاري قراءة وتحليل ملف البيانات الرئيسي: ${mainDataPath}`);
    const text = await loadedZip.file(mainDataPath)!.async("text");
    const parsed = JSON.parse(text);

    if (parsed && typeof parsed === "object") {
      if (Array.isArray(parsed)) {
        restoredCustomers = parsed;
      } else {
        if (parsed.customers && Array.isArray(parsed.customers)) {
          restoredCustomers = parsed.customers;
        } else {
          // Fallback: search for any key containing array of objects that look like customers
          for (const k of Object.keys(parsed)) {
            if (Array.isArray(parsed[k]) && parsed[k].length > 0 && (parsed[k][0].name !== undefined || parsed[k][0].id !== undefined)) {
              restoredCustomers = parsed[k];
              break;
            }
          }
        }

        if (parsed.system && Array.isArray(parsed.system)) {
          restoredSystem = parsed.system;
        } else if (parsed.credentials) {
          restoredSystem = [{ id: "credentials", creds: parsed.credentials }];
        } else if (parsed.system_credentials) {
          restoredSystem = [{ id: "credentials", creds: parsed.system_credentials }];
        } else if (parsed.system && typeof parsed.system === "object") {
          restoredSystem = [{ id: "credentials", creds: parsed.system }];
        }
      }
    }
    console.log("⚙️ [importBackupZip] نجح تحليل هيكل جداول الأرشيف. عدد العملاء المكتشفين:", restoredCustomers.length);
  } catch (err) {
    console.error("⚙️ [importBackupZip] خطأ أثناء تحليل JSON الخاص بالبيانات:", err);
    throw new Error("فشل في تحليل ملفات البيانات من النسخة الاحتياطية. يرجى التأكد من سلامة ملف الـ JSON.");
  }

  // Build a map of all image files in the ZIP recursively from all folders (e.g., images/, صور_اصحاب_الاقساط/, etc.)
  onProgress?.(45, "جاري مسح وقراءة أرشيف الصور والملفات المرفقة...");
  const zipImageMap = new Map<string, { base64: string; mime: string; ext: string; path: string; name: string }>();
  let zipImagesCount = 0;
  let convertedImages = 0;
  const failedLogList: string[] = [];

  for (const path of Object.keys(loadedZip.files)) {
    if (loadedZip.files[path].dir) continue;

    const lowerPath = path.toLowerCase();
    const isImage = lowerPath.endsWith(".jpg") || 
                    lowerPath.endsWith(".jpeg") || 
                    lowerPath.endsWith(".png") || 
                    lowerPath.endsWith(".webp") || 
                    lowerPath.endsWith(".gif") || 
                    lowerPath.endsWith(".bmp");

    if (isImage) {
      zipImagesCount++;
      try {
        const fileEntry = loadedZip.file(path);
        if (fileEntry) {
          const parts = path.split("/");
          const fileName = parts[parts.length - 1];
          const ext = fileName.split(".").pop()?.toLowerCase() || "jpg";
          let mime = "image/jpeg";
          if (ext === "png") mime = "image/png";
          else if (ext === "webp") mime = "image/webp";
          else if (ext === "gif") mime = "image/gif";
          else if (ext === "bmp") mime = "image/bmp";

          const base64Data = await fileEntry.async("base64");
          const dataUrl = `data:${mime};base64,${base64Data}`;

          const normalizedPath = path.replace(/\\/g, "/");
          zipImageMap.set(normalizedPath.toLowerCase(), {
            base64: dataUrl,
            mime,
            ext,
            path: normalizedPath,
            name: fileName
          });
          convertedImages++;
        }
      } catch (err: any) {
        const fileName = path.split("/").pop() || path;
        const errMsg = err.message || "خطأ في فك الضغط وقراءة الصورة";
        console.error(`❌ [importBackupZip] فشل استيراد الصورة [${fileName}]: ${errMsg}`);
        failedLogList.push(`${fileName}: ${errMsg}`);
      }
    }
  }
  console.log(`⚙️ [importBackupZip] تم تحميل وتحويل ${convertedImages} صورة بنجاح من أصل ${zipImagesCount} داخل الـ ZIP.`);

  // Fuzzy-match and map helper for customer/guarantor images
  const matchedZipPaths = new Set<string>();

  const findImageInZip = (
    originalVal: string | undefined | null, 
    customerId: string, 
    customerName: string, 
    fieldKey: string,
    isGuarantor = false
  ): string | undefined => {
    // If we have an original value, check it first
    if (originalVal && typeof originalVal === "string") {
      if (originalVal.startsWith("data:image/")) {
        return originalVal;
      }
      
      // 1. Match by exact normalized path (lowercase)
      const normPath = originalVal.replace(/\\/g, "/").toLowerCase();
      let match = zipImageMap.get(normPath);
      if (match) {
        matchedZipPaths.add(match.path.toLowerCase());
        return match.base64;
      }
      
      // 2. Match by ending string of the path
      for (const [key, value] of zipImageMap.entries()) {
        if (key.endsWith(normPath) || normPath.endsWith(key)) {
          matchedZipPaths.add(value.path.toLowerCase());
          return value.base64;
        }
      }
      
      // 3. Match by filename (basename) of original value
      const baseName = originalVal.split(/[/\\]/).pop()?.toLowerCase();
      if (baseName) {
        for (const [key, value] of zipImageMap.entries()) {
          if (value.name.toLowerCase() === baseName) {
            matchedZipPaths.add(value.path.toLowerCase());
            return value.base64;
          }
        }
      }
    }
    
    // 4. Fuzzy match using customerId or name and field aliases
    const aliases = IMAGE_FIELD_ALIASES[fieldKey] || [fieldKey];
    const cleanId = customerId ? customerId.trim().toLowerCase() : "";
    const cleanName = customerName ? customerName.trim().toLowerCase() : "";
    const normalizedCleanName = cleanName ? normalizeArabicString(cleanName) : "";
    
    if (cleanId || normalizedCleanName) {
      for (const [key, value] of zipImageMap.entries()) {
        const lowerKey = key.toLowerCase();
        const normalizedZipKey = normalizeArabicString(lowerKey);
        
        // We want the image to belong to this customer
        const belongsToCust = (cleanId && lowerKey.includes(cleanId)) || 
                              (normalizedCleanName && normalizedZipKey.includes(normalizedCleanName));
        
        if (belongsToCust) {
          // Now check if it matches the field aliases
          const matchesField = aliases.some(alias => lowerKey.includes(alias.toLowerCase()));
          if (matchesField) {
            const isPathGuarantor = lowerKey.includes("guarantor") || lowerKey.includes("كفيل") || lowerKey.includes("guar");
            if (isGuarantor === isPathGuarantor) {
              matchedZipPaths.add(value.path.toLowerCase());
              return value.base64;
            }
          }
        }
      }
    }
    
    // 5. Hard fuzzy fallback: just match customerId/name and field key anywhere in the path
    if (cleanId || normalizedCleanName) {
      for (const [key, value] of zipImageMap.entries()) {
        const lowerKey = key.toLowerCase();
        const normalizedZipKey = normalizeArabicString(lowerKey);
        const hasIdOrName = (cleanId && lowerKey.includes(cleanId)) || 
                            (normalizedCleanName && normalizedZipKey.includes(normalizedCleanName));
        const hasField = lowerKey.includes(fieldKey.toLowerCase());
        if (hasIdOrName && hasField) {
          const isPathGuarantor = lowerKey.includes("guarantor") || lowerKey.includes("كفيل") || lowerKey.includes("guar");
          if (isGuarantor === isPathGuarantor) {
            matchedZipPaths.add(value.path.toLowerCase());
            return value.base64;
          }
        }
      }
    }
    
    return undefined;
  };

  onProgress?.(60, "جاري معالجة بيانات العملاء واستعادة وربط الصور بدقة...");
  const resolvedCustomersList: any[] = [];
  let linkedImagesCount = 0;
  const missingImagesList: string[] = [];

  const customerImageArabicNames: Record<string, string> = {
    personal: "الصورة الشخصية للزبون",
    idFront: "صورة الهوية (الوجه)",
    idBack: "صورة الهوية (الظهر)",
    resFront: "صورة بطاقة السكن (الوجه)",
    resBack: "صورة بطاقة السكن (الظهر)"
  };

  const guarantorImageArabicNames: Record<string, string> = {
    personal: "الصورة الشخصية للكفيل",
    idFront: "صورة هوية الكفيل (الوجه)",
    idBack: "صورة هوية الكفيل (الظهر)",
    resFront: "صورة بطاقة سكن الكفيل (الوجه)",
    resBack: "صورة بطاقة سكن الكفيل (الظهر)"
  };

  for (let r = 0; r < restoredCustomers.length; r++) {
    let resolvedItem = { ...restoredCustomers[r] };

    // Ensure customer images structure is initialized
    if (!resolvedItem.images) {
      resolvedItem.images = {};
    } else {
      resolvedItem.images = { ...resolvedItem.images };
    }

    // 1. Resolve customer images
    const customerImageFields: (keyof CustomerImages)[] = ["personal", "resFront", "resBack", "idFront", "idBack"];
    for (const key of customerImageFields) {
      const pathVal = resolvedItem.images[key];
      
      const dataUrl = await convertToBase64DataUrlAsync(pathVal);
      if (dataUrl) {
        resolvedItem.images[key] = dataUrl;
        linkedImagesCount++;
      } else {
        const matchedBase64 = findImageInZip(pathVal, resolvedItem.id, resolvedItem.name, key, false);
        if (matchedBase64) {
          resolvedItem.images[key] = matchedBase64;
          linkedImagesCount++;
        } else if (pathVal && typeof pathVal === "string" && pathVal.trim() !== "") {
          const labelAr = customerImageArabicNames[key] || key;
          missingImagesList.push(`❌ الزبون (${resolvedItem.name}) - ${labelAr}: غير موجودة في الأرشيف`);
        }
      }
    }

    // 2. Resolve guarantor images if present
    if (resolvedItem.guarantor) {
      resolvedItem.guarantor = { ...resolvedItem.guarantor };
      if (!resolvedItem.guarantor.images) {
        resolvedItem.guarantor.images = {};
      } else {
        resolvedItem.guarantor.images = { ...resolvedItem.guarantor.images };
      }

      const guarantorImageFields: (keyof GuarantorImages)[] = ["personal", "idFront", "idBack", "resFront", "resBack"];
      for (const key of guarantorImageFields) {
        const pathVal = resolvedItem.guarantor.images[key];
        
        const dataUrl = await convertToBase64DataUrlAsync(pathVal);
        if (dataUrl) {
          resolvedItem.guarantor.images[key] = dataUrl;
          linkedImagesCount++;
        } else {
          const matchedBase64 = findImageInZip(pathVal, resolvedItem.id, resolvedItem.guarantor.name, key, true);
          if (matchedBase64) {
            resolvedItem.guarantor.images[key] = matchedBase64;
            linkedImagesCount++;
          } else if (pathVal && typeof pathVal === "string" && pathVal.trim() !== "") {
            const labelAr = guarantorImageArabicNames[key] || key;
            missingImagesList.push(`❌ كفيل الزبون (${resolvedItem.name} - ${resolvedItem.guarantor.name}) - ${labelAr}: غير موجودة في الأرشيف`);
          }
        }
      }
    }

    resolvedItem = normalizeCustomer(resolvedItem);
    resolvedCustomersList.push(resolvedItem);
  }

  // Compile final resolved stores object
  const resolvedStores: Record<string, any[]> = {
    customers: resolvedCustomersList,
    system: restoredSystem
  };

  onProgress?.(70, "جاري مسح وحذف البيانات القديمة بعد نجاح التثبيت بالذاكرة...");
  console.log("⚙️ [importBackupZip] بدأ الحفظ في IndexedDB. جاري تنظيف الجداول القديمة أولاً...");
  const db = await getDB();
  const currentStoreNames = Array.from(db.objectStoreNames);

  for (const storeName of currentStoreNames) {
    console.log(`⚙️ [importBackupZip] جاري تصفية جدول: ${storeName}`);
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
  console.log("⚙️ [importBackupZip] تم مسح جميع الجداول القديمة بنجاح.");

  // Write stores sequentially in batches
  let totalRecords = 0;
  const targetStoreNames = Object.keys(resolvedStores);
  for (let s = 0; s < targetStoreNames.length; s++) {
    const storeName = targetStoreNames[s];
    const items = resolvedStores[storeName];

    onProgress?.(80 + s * 5, `جاري كتابة وحفظ جدول: ${storeName}...`);
    console.log(`⚙️ [importBackupZip] جاري حفظ جدول ${storeName}: كتابة ${items.length} سجلاً...`);
    await writeStoreInBatches(storeName, items, (subMsg) => {
      onProgress?.(80 + s * 5, subMsg);
    });
    totalRecords += items.length;
  }

  // Notify parent state listeners to update all pages smoothly and responsively (No location.reload)
  console.log("⚙️ [importBackupZip] جاري إخطار المستمعين وتحديث الكاش المحلي...");
  await notifyCustomersListeners();
  await notifyCredentialsListeners();

  // Re-synchronize fast local caches (lightweight) to avoid QuotaExceededError and slow downs
  try {
    const lightList = resolvedCustomersList.map(cust => {
      const lightCust = { ...cust };
      if (lightCust.images) {
        lightCust.images = {};
      }
      if (lightCust.guarantor) {
        lightCust.guarantor = { ...lightCust.guarantor };
        if (lightCust.guarantor.images) {
          lightCust.guarantor.images = {};
        }
      }
      return lightCust;
    });
    localStorage.setItem("cached_customers", JSON.stringify(lightList));
    console.log("⚙️ [importBackupZip] تم تحديث كاش localStorage بنجاح.");
  } catch (err) {
    console.error("⚙️ [importBackupZip] خطأ أثناء تحديث كاش localStorage:", err);
  }

  const credentialsRecord = resolvedStores["system"]?.find(i => i.id === "credentials");
  if (credentialsRecord && credentialsRecord.creds) {
    localStorage.setItem("cached_system_credentials", JSON.stringify(credentialsRecord.creds));
    console.log("⚙️ [importBackupZip] تم تحديث كاش بيانات الاعتماد في localStorage.");
  }

  const durationMs = Date.now() - startTime;
  await addBackupLog({
    type: "import",
    timestamp: new Date().toISOString(),
    durationMs,
    recordsCount: totalRecords,
    status: "success"
  });

  const savedImages = matchedZipPaths.size;
  const failedImagesCount = failedLogList.length;
  const missingCount = missingImagesList.length;

  console.log("==================================================");
  console.log("⚙️ [DEBUG] بدء الاستيراد الشامل من ملف الـ ZIP...");
  console.log(`⚙️ [DEBUG] عدد ملفات JSON المكتشفة داخل الأرشيف: ${jsonFilesCount}`);
  console.log(`⚙️ [DEBUG] عدد العملاء المكتشفين في ملف البيانات: ${restoredCustomers.length}`);
  console.log(`⚙️ [DEBUG] عدد ملفات الصور داخل ZIP: ${zipImagesCount}`);
  console.log(`⚙️ [DEBUG] عدد الصور التي تم تحويلها بنجاح إلى Base64: ${convertedImages}`);
  console.log(`⚙️ [DEBUG] عدد الصور الفريدة التي تم حفظها وربطها بالعملاء: ${savedImages}`);
  console.log(`⚙️ [DEBUG] عدد حقول الصور المرتبطة بالعملاء والكفلاء: ${linkedImagesCount}`);
  console.log(`⚙️ [DEBUG] عدد ملفات الصور التي فشل استيرادها: ${failedImagesCount}`);
  console.log(`⚙️ [DEBUG] عدد الصور المفقودة: ${missingCount}`);
  console.log(`⚙️ [DEBUG] مدة الاستيراد الإجمالية: ${durationMs} مللي ثانية`);
  if (failedLogList.length > 0) {
    console.error("⚙️ [DEBUG] تفاصيل أخطاء استيراد الصور:");
    failedLogList.forEach(log => console.error(`   - ${log}`));
  } else {
    console.log("⚙️ [DEBUG] لم تحدث أي أخطاء أثناء استيراد ومعالجة الصور! نجاح 100%.");
  }
  console.log("==================================================");

  console.log("⚙️ [importBackupZip] تم تحديث واجهة المستخدم بنجاح.");
  onProgress?.(100, "تمت عملية استيراد واستعادة البيانات بالكامل بنجاح 100%!");

  let reportStr = `تقرير الاستيراد الشامل: ناجح
عدد العملاء: ${restoredCustomers.length}
عدد الصور المستوردة: ${savedImages}
عدد الصور المرتبطة: ${linkedImagesCount}
عدد الصور التالفة: ${failedImagesCount}
الصور المفقودة: ${missingCount}`;

  if (missingCount > 0) {
    reportStr += `\n⚠️ صور مفقودة تم رصدها:\n` + missingImagesList.slice(0, 15).join("\n");
    if (missingCount > 15) {
      reportStr += `\n❌ و ${missingCount - 15} صور أخرى غير موجودة في الأرشيف`;
    }
  }

  return reportStr;
}
