export interface PrintTemplate {
  id: string;
  name: string;
  fontSizes: {
    shopName: number;
    shopPhone: number;
    title: number;
    customerName: number;
    customerPhone: number;
    productName: number;
    financialLabel: number;
    financialValue: number;
    dueBannerLabel: number;
    dueBannerValue: number;
    footer: number;
  };
  paddings: {
    shopNameBottom: number;
    shopPhoneBottom: number;
    titleBottom: number;
    customerCardBottom: number;
    productBottom: number;
    financialRowBottom: number;
    dueBannerBottom: number;
  };
}

export const DEFAULT_TEMPLATES: PrintTemplate[] = [
  {
    id: "standard",
    name: "الافتراضي الموصى به",
    fontSizes: {
      shopName: 38,
      shopPhone: 23,
      title: 32,
      customerName: 34,
      customerPhone: 28,
      productName: 24,
      financialLabel: 18,
      financialValue: 25,
      dueBannerLabel: 19,
      dueBannerValue: 24,
      footer: 18
    },
    paddings: {
      shopNameBottom: 52,
      shopPhoneBottom: 42,
      titleBottom: 50,
      customerCardBottom: 42,
      productBottom: 58,
      financialRowBottom: 42,
      dueBannerBottom: 60
    }
  },
  {
    id: "compact",
    name: "اقتصادي (توفير ورق حراري)",
    fontSizes: {
      shopName: 28,
      shopPhone: 18,
      title: 24,
      customerName: 26,
      customerPhone: 22,
      productName: 20,
      financialLabel: 15,
      financialValue: 20,
      dueBannerLabel: 16,
      dueBannerValue: 20,
      footer: 15
    },
    paddings: {
      shopNameBottom: 35,
      shopPhoneBottom: 30,
      titleBottom: 35,
      customerCardBottom: 30,
      productBottom: 40,
      financialRowBottom: 30,
      dueBannerBottom: 45
    }
  },
  {
    id: "large",
    name: "وضوح فائق (خطوط كبيرة)",
    fontSizes: {
      shopName: 46,
      shopPhone: 28,
      title: 38,
      customerName: 40,
      customerPhone: 34,
      productName: 30,
      financialLabel: 22,
      financialValue: 30,
      dueBannerLabel: 22,
      dueBannerValue: 28,
      footer: 22
    },
    paddings: {
      shopNameBottom: 65,
      shopPhoneBottom: 55,
      titleBottom: 65,
      customerCardBottom: 55,
      productBottom: 75,
      financialRowBottom: 55,
      dueBannerBottom: 75
    }
  }
];

